import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Calendar } from 'lucide-react';
import { getMeetingsForDate } from '@/lib/data-service';
import RaceCard from '@/components/racing/RaceCard';
import AdBanner from '@/components/ads/AdBanner';
import DemoBanner from '@/components/common/DemoBanner';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Programme des Courses Hippiques & Calendrier PMU | TurfJournal',
  description:
    'Consultez le programme officiel complet des courses du jour : réunions R1, R2, R3, horaires de départ, partants, cotes et conditions de course.',
  alternates: {
    canonical: '/programme',
  },
};

interface ProgrammePageProps {
  searchParams: Promise<{ date?: string }>;
}

export default async function ProgrammePage({ searchParams }: ProgrammePageProps) {
  const resolvedParams = await searchParams;
  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];

  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const selectedDate = resolvedParams?.date || todayStr;
  const { meetings, isDemo } = await getMeetingsForDate(selectedDate);

  const formattedDateTitle = new Date(selectedDate).toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Accueil',
        item: 'https://turfjournal.com',
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: `Programme PMU du ${formattedDateTitle}`,
        item: `https://turfjournal.com/programme?date=${selectedDate}`,
      },
    ],
  };

  const programmeItemListJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: `Programme des Réunions du ${formattedDateTitle}`,
    itemListElement: meetings.map((m, idx) => ({
      '@type': 'ListItem',
      position: idx + 1,
      name: `${m.code} - ${m.name} (${m.hippodromeName})`,
      description: `${m.races.length} courses disputées à ${m.city}`,
    })),
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      {meetings.length > 0 && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(programmeItemListJsonLd) }}
        />
      )}

      <DemoBanner show={isDemo} />

      {/* Modern Page Header & Easy Date Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center space-x-2 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
            <Calendar className="w-4 h-4" />
            <span>Calendrier Officiel</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black text-slate-900 capitalize">
            Programme du {formattedDateTitle}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Toutes les réunions avec partants officiels, cotes en direct et prédictions statistiques.
          </p>
        </div>

        {/* Easy 3-Day Quick Navigation */}
        <div className="flex items-center space-x-2 bg-white p-1.5 rounded-2xl border border-slate-200 text-xs shadow-xs">
          <Link
            href={`/programme?date=${yesterdayStr}`}
            className={`px-3 py-2 rounded-xl font-bold transition-all ${
              selectedDate === yesterdayStr ? 'bg-emerald-700 text-white' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Hier
          </Link>
          <Link
            href={`/programme?date=${todayStr}`}
            className={`px-4 py-2 rounded-xl font-black transition-all ${
              selectedDate === todayStr ? 'bg-emerald-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Aujourd&apos;hui
          </Link>
          <Link
            href={`/programme?date=${tomorrowStr}`}
            className={`px-3 py-2 rounded-xl font-bold transition-all ${
              selectedDate === tomorrowStr ? 'bg-emerald-700 text-white' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Demain
          </Link>
        </div>
      </div>

      <AdBanner format="horizontal" slotId="programme-top" />

      {/* Meetings List */}
      <div className="space-y-12">
        {meetings.length === 0 ? (
          <div className="card-modern p-12 text-center border border-slate-200">
            <Calendar className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-800">
              {isDemo ? 'Les données PMU sont temporairement indisponibles.' : 'Aucune réunion programmée pour cette date'}
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              {isDemo
                ? 'Veuillez vérifier la connexion aux serveurs officiels PMU ou réessayer ultérieurement.'
                : 'Revenez au calendrier du jour pour consulter les partants et analyses en cours.'}
            </p>
            <Link
              href="/programme"
              className="inline-block mt-4 px-5 py-2.5 rounded-xl bg-emerald-700 text-white text-xs font-black shadow-xs"
            >
              Programme d&apos;aujourd&apos;hui
            </Link>
          </div>
        ) : (
          meetings.map((meeting) => (
            <div key={meeting.id} className="space-y-4">
              {/* Meeting Header */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
                <div className="flex items-center space-x-3.5">
                  <span className="w-10 h-10 rounded-xl bg-emerald-700 text-white font-black text-base flex items-center justify-center shadow-xs">
                    {meeting.code}
                  </span>
                  <div>
                    <h2 className="text-base font-black text-slate-900">{meeting.name}</h2>
                    <p className="text-xs text-slate-500">
                      Hippodrome de {meeting.hippodromeName} • {meeting.city} • Piste {meeting.surface || 'Sable/Herbe'}
                    </p>
                  </div>
                </div>

                <div className="text-xs text-slate-600 font-bold">
                  {meeting.races.length} courses disputées
                </div>
              </div>

              {/* Races Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {meeting.races.map((race) => (
                  <RaceCard key={race.id} race={race} />
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      <AdBanner format="horizontal" slotId="programme-bottom" />
    </div>
  );
}

