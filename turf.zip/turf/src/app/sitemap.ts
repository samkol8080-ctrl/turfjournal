import { MetadataRoute } from 'next';
import { getMeetingsForDate, getArticles } from '@/lib/data-service';

export const dynamic = 'force-dynamic';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://turfjournal.com';
  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];

  const staticPages: MetadataRoute.Sitemap = [
    { url: `${baseUrl}`, lastModified: new Date(), changeFrequency: 'always', priority: 1.0 },
    { url: `${baseUrl}/pronostic-quinte-du-jour`, lastModified: new Date(), changeFrequency: 'hourly', priority: 1.0 },
    { url: `${baseUrl}/quinte-de-demain`, lastModified: new Date(), changeFrequency: 'hourly', priority: 0.95 },
    { url: `${baseUrl}/programme`, lastModified: new Date(), changeFrequency: 'hourly', priority: 0.95 },
    { url: `${baseUrl}/pronostics`, lastModified: new Date(), changeFrequency: 'hourly', priority: 0.95 },
    { url: `${baseUrl}/resultats`, lastModified: new Date(), changeFrequency: 'hourly', priority: 0.9 },
    { url: `${baseUrl}/actualites`, lastModified: new Date(), changeFrequency: 'daily', priority: 0.85 },
    { url: `${baseUrl}/guides`, lastModified: new Date(), changeFrequency: 'weekly', priority: 0.85 },
    { url: `${baseUrl}/faq`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.7 },
    { url: `${baseUrl}/a-propos`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.5 },
    { url: `${baseUrl}/contact`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.5 },
    { url: `${baseUrl}/jeu-responsable`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.6 },
    { url: `${baseUrl}/mentions-legales`, lastModified: new Date(), changeFrequency: 'yearly', priority: 0.3 },
    { url: `${baseUrl}/politique-confidentialite`, lastModified: new Date(), changeFrequency: 'yearly', priority: 0.3 },
    { url: `${baseUrl}/politique-cookies`, lastModified: new Date(), changeFrequency: 'yearly', priority: 0.3 },
  ];

  // Dynamic race pages (both /pronostic/[slug] and /courses/[slug])
  const { meetings } = await getMeetingsForDate(todayStr);
  const racePages: MetadataRoute.Sitemap = [];
  const seenSlugs = new Set<string>();

  meetings.forEach((m) => {
    m.races.forEach((r) => {
      if (!seenSlugs.has(r.slug)) {
        seenSlugs.add(r.slug);
        racePages.push({
          url: `${baseUrl}/pronostic/${r.slug}`,
          lastModified: new Date(),
          changeFrequency: 'hourly',
          priority: r.isQuinte ? 0.95 : 0.85,
        });
        racePages.push({
          url: `${baseUrl}/courses/${r.slug}`,
          lastModified: new Date(),
          changeFrequency: 'hourly',
          priority: r.isQuinte ? 0.9 : 0.8,
        });
      }
    });
  });

  // Dynamic articles and guides pages
  const articles = await getArticles();
  const articlePages: MetadataRoute.Sitemap = articles.map((a) => ({
    url: `${baseUrl}/${a.categorySlug === 'guides' ? 'guides' : 'actualites'}/${a.slug}`,
    lastModified: new Date(a.publishedAt),
    changeFrequency: 'weekly',
    priority: 0.75,
  }));

  return [...staticPages, ...racePages, ...articlePages];
}

