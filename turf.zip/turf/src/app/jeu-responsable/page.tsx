﻿import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { ShieldAlert, HeartHandshake, PhoneCall, ExternalLink, ChevronRight, CheckCircle2 } from 'lucide-react';
import AdBanner from '@/components/ads/AdBanner';

export const metadata: Metadata = {
  title: 'Jeu Responsable & Prévention de l\'Addiction | TurfJournal',
  description:
    'Conseils essentiels, numéros d\'assistance anonyme et démarches d\'auto-exclusion pour une pratique du turf saine, modérée et sans risque.',
  alternates: {
    canonical: '/jeu-responsable',
  },
};

export default function JeuResponsablePage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-amber-700 font-bold">Jeu Responsable</span>
      </nav>

      {/* Hero Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-50 to-white border border-amber-200 space-y-3">
        <div className="flex items-center space-x-2 text-xs font-bold text-amber-800 uppercase tracking-wider">
          <ShieldAlert className="w-5 h-5 text-amber-600" />
          <span>Prévention & Santé Publique</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
          Jouer Doit Rester un Plaisir : Guide du Jeu Responsable
        </h1>
        <p className="text-xs sm:text-sm text-amber-900/90 leading-relaxed max-w-2xl font-medium">
          Les paris hippiques comportent des risques avérés d&apos;endettement, d&apos;isolement social et de dépendance. TurfJournal s&apos;engage activement pour la protection des parieurs.
        </p>
      </div>

      {/* Emergency Helpline Box */}
      <div className="p-6 rounded-2xl bg-white border-2 border-amber-300 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-500 text-slate-900 flex items-center justify-center font-black flex-shrink-0 shadow-sm">
            <PhoneCall className="w-7 h-7 text-white" />
          </div>
          <div>
            <span className="text-xs text-amber-800 font-bold uppercase tracking-wider block">
              Besoin d&apos;aide ou envie de parler ?
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900">
              Joueurs Info Service : <strong className="text-amber-700 font-mono">09 74 75 13 13</strong>
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Appel anonyme, confidentiel et non surtaxé • 7 jours sur 7 de 8h à 2h du matin.
            </p>
          </div>
        </div>

        <a
          href="https://www.joueurs-info-service.fr"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center space-x-2 px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-all flex-shrink-0 shadow-sm"
        >
          <span>Visiter Joueurs-Info-Service.fr</span>
          <ExternalLink className="w-4 h-4 text-amber-400" />
        </a>
      </div>

      {/* 5 Golden Rules */}
      <div className="card-modern p-6 sm:p-8 space-y-6 border border-slate-200 bg-white">
        <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span>Nos 5 Recommandations pour Maîtriser Votre Pratique</span>
        </h2>

        <div className="space-y-4 text-xs sm:text-sm text-slate-700">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <strong className="text-slate-900 block text-sm font-bold">1. Fixez un budget strict et infranchissable</strong>
            <p className="text-slate-600">
              Ne jouez qu&apos;une somme que vous êtes prêt à perdre sans aucune conséquence pour votre foyer (loyer, alimentation, factures). Ne touchez jamais à vos économies vitales.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <strong className="text-slate-900 block text-sm font-bold">2. Ne cherchez jamais à &quot;vous refaire&quot;</strong>
            <p className="text-slate-600">
              Augmenter ses mises après une série de paris perdants pour compenser les pertes est la cause n°1 d&apos;endettement dans le jeu. Acceptez les séries négatives et sachez faire une pause.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <strong className="text-slate-900 block text-sm font-bold">3. Ne pariez jamais sous l&apos;influence de l&apos;alcool ou de la détresse émotionnelle</strong>
            <p className="text-slate-600">
              Le pari nécessite lucidité et objectivité. Ne pariez jamais pour fuir un problème personnel, un deuil ou un état dépressif.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <strong className="text-slate-900 block text-sm font-bold">4. Gardez le contrôle du temps passé</strong>
            <p className="text-slate-600">
              L&apos;étude des courses hippiques ne doit pas empiéter sur votre vie de famille, votre travail ou vos loisirs quotidiens.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <strong className="text-slate-900 block text-sm font-bold">5. Activez les outils d&apos;auto-limitation et d&apos;interdiction volontaire</strong>
            <p className="text-slate-600">
              Tous les opérateurs légaux proposent des plafonds de dépôt hebdomadaires et des mécanismes d&apos;auto-exclusion temporaire ou définitive.
            </p>
          </div>
        </div>
      </div>

      {/* Voluntary Exclusion Section */}
      <div className="card-modern p-6 sm:p-8 space-y-4 border border-slate-200 bg-white text-xs sm:text-sm text-slate-700">
        <h2 className="text-lg font-bold text-slate-900">Démarche d&apos;Interdiction Volontaire de Jeux</h2>
        <p className="leading-relaxed text-slate-600">
          Toute personne peut demander à être interdite de jeux auprès de l&apos;Autorité Nationale des Jeux (ANJ en France) ou des autorités de tutelle de son pays de résidence. Cette interdiction est valable dans les casinos, cercles de jeux et sur tous les sites de jeux et paris en ligne agréés.
        </p>
        <a
          href="https://interdictiondejeux.anj.fr"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center space-x-2 text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline pt-2"
        >
          <span>Accéder à la plateforme officielle d&apos;interdiction de jeux (ANJ)</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
}

