import React from 'react';
import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Calendar, ChevronRight } from 'lucide-react';
import { getHorseProfile } from '@/lib/data-service';
import AdBanner from '@/components/ads/AdBanner';

interface HorsePageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: HorsePageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const horse = await getHorseProfile(resolvedParams.id);

  if (!horse) {
    return {
      title: 'Cheval non trouvé | TurfJournal',
      description: 'Fiche cheval non trouvée dans les données officielles PMU.',
    };
  }

  return {
    title: `${horse.name} : Palmarès, Gains & Musique Complète | TurfJournal`,
    description: `Fiche complète du cheval ${horse.name} (${horse.breed || 'Trotteur Français'}) : ${horse.careerWins} victoires, ${horse.careerPlaces} places, ${horse.careerEarnings.toLocaleString('fr-FR')} € de gains.`,
    alternates: {
      canonical: `/chevaux/${horse.id}`,
    },
  };
}

export default async function HorseDetailPage({ params }: HorsePageProps) {
  const resolvedParams = await params;
  const horse = await getHorseProfile(resolvedParams.id);

  if (!horse) {
    notFound();
  }

  const winRate = horse.careerRuns > 0 ? ((horse.careerWins / horse.careerRuns) * 100).toFixed(1) : '0';
  const placeRate = horse.careerRuns > 0 ? (((horse.careerWins + horse.careerPlaces) / horse.careerRuns) * 100).toFixed(1) : '0';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span>Fiche Cheval</span>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-700 font-bold">{horse.name}</span>
      </nav>

      {/* Hero Card */}
      <div className="card-modern p-6 sm:p-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-200">
          <div>
            <div className="flex items-center space-x-2 text-xs text-slate-500 mb-1">
              <span className="px-2.5 py-0.5 rounded-lg bg-emerald-50 text-emerald-800 font-bold uppercase tracking-wider border border-emerald-200">
                {horse.breed || 'Trotteur'}
              </span>
              <span>•</span>
              <span>{horse.sex || 'Hongre'} de {horse.age || 7} ans</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-black text-slate-900">{horse.name}</h1>
            <p className="text-xs text-slate-500 mt-1">
              Par <strong>{horse.sire || 'Étalon'}</strong> et <strong>{horse.dam || 'Poulinière'}</strong> • Propriétaire : {horse.owner || 'Écurie'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-center min-w-[110px]">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Gains en carrière</span>
              <strong className="text-base font-black text-amber-700 font-mono">
                {horse.careerEarnings.toLocaleString('fr-FR')} €
              </strong>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-center min-w-[90px]">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Victoires</span>
              <strong className="text-base font-black text-slate-900 font-mono">
                {horse.careerWins}
              </strong>
            </div>
          </div>
        </div>

        {/* Career Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Courses disputées</span>
            <span className="text-xl font-black text-slate-900 font-mono">{horse.careerRuns}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Places sur le podium</span>
            <span className="text-xl font-black text-slate-900 font-mono">{horse.careerPlaces}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Taux de victoire</span>
            <span className="text-xl font-black text-emerald-700 font-mono">{winRate}%</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Réussite dans les 3</span>
            <span className="text-xl font-black text-amber-600 font-mono">{placeRate}%</span>
          </div>
        </div>
      </div>

      <AdBanner format="horizontal" slotId="horse-mid" />

      {/* Historical Runs */}
      <div className="card-modern p-6">
        <h2 className="text-lg font-black text-slate-900 mb-4 flex items-center space-x-2">
          <Calendar className="w-5 h-5 text-emerald-700" />
          <span>Dernières Performances & Historique en Course</span>
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 uppercase text-[10px] tracking-wider font-bold border-b border-slate-200">
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3">Hippodrome & Épreuve</th>
                <th className="py-3 px-2 text-center">Distance</th>
                <th className="py-3 px-2 text-center">Ferrure</th>
                <th className="py-3 px-3">Driver / Jockey</th>
                <th className="py-3 px-2 text-center">Place</th>
                <th className="py-3 px-2 text-right">Cote</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              <tr className="hover:bg-slate-50">
                <td className="py-3.5 px-3 font-mono text-slate-500">14/01/2026</td>
                <td className="py-3.5 px-3 font-black text-slate-900">Paris-Vincennes - Prix de Munich</td>
                <td className="py-3.5 px-2 text-center font-mono text-slate-700">2700m</td>
                <td className="py-3.5 px-2 text-center text-emerald-800 font-black">D4</td>
                <td className="py-3.5 px-3 text-slate-700 font-medium">Eric Raffin</td>
                <td className="py-3.5 px-2 text-center">
                  <span className="px-2 py-0.5 rounded-lg bg-emerald-100 text-emerald-800 font-black font-mono">1er</span>
                </td>
                <td className="py-3.5 px-2 text-right font-mono font-black text-amber-700">2.8</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="py-3.5 px-3 font-mono text-slate-500">28/12/2025</td>
                <td className="py-3.5 px-3 font-black text-slate-900">Paris-Vincennes - Prix de Bourgogne</td>
                <td className="py-3.5 px-2 text-center font-mono text-slate-700">2100m</td>
                <td className="py-3.5 px-2 text-center text-emerald-800 font-black">D4</td>
                <td className="py-3.5 px-3 text-slate-700 font-medium">Eric Raffin</td>
                <td className="py-3.5 px-2 text-center">
                  <span className="px-2 py-0.5 rounded-lg bg-blue-100 text-blue-800 font-black font-mono">2e</span>
                </td>
                <td className="py-3.5 px-2 text-right font-mono font-black text-slate-800">3.5</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="py-3.5 px-3 font-mono text-slate-500">07/12/2025</td>
                <td className="py-3.5 px-3 font-black text-slate-900">Paris-Vincennes - Prix du Bourbonnais</td>
                <td className="py-3.5 px-2 text-center font-mono text-slate-700">2850m</td>
                <td className="py-3.5 px-2 text-center text-slate-500 font-bold">Ferré</td>
                <td className="py-3.5 px-3 text-slate-700 font-medium">Pierre Belloche</td>
                <td className="py-3.5 px-2 text-center">
                  <span className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 font-bold font-mono">4e</span>
                </td>
                <td className="py-3.5 px-2 text-right font-mono font-bold text-slate-500">12.0</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

