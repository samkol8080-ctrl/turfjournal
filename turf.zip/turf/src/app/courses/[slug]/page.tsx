import React from 'react';
import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Clock, MapPin, Sparkles, ChevronRight, Award } from 'lucide-react';
import { getRaceBySlug } from '@/lib/data-service';
import ParticipantTable from '@/components/racing/ParticipantTable';
import PredictionBox from '@/components/racing/PredictionBox';
import AdBanner from '@/components/ads/AdBanner';
import DemoBanner from '@/components/common/DemoBanner';

export const dynamic = 'force-dynamic';

interface RacePageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: RacePageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const { race } = await getRaceBySlug(resolvedParams.slug);

  if (!race) {
    return {
      title: 'Course Hippique Introuvable | TurfJournal',
    };
  }

  const quinteLabel = race.isQuinte ? ' [Quinté+]' : '';
  return {
    title: `${race.name}${quinteLabel} - Partants, Cotes & Pronostic`,
    description: `Découvrez les partants officiels, cotes en direct, analyse statistique et pronostic pour la course ${race.name} (${race.meetingCode} - C${race.raceNumber}) à ${race.hippodromeName}.`,
    alternates: {
      canonical: `/pronostic/${race.slug}`,
    },
    openGraph: {
      title: `${race.name} - Partants & Pronostics TurfJournal`,
      description: `Analyse et classement mathématique des chevaux partants pour la course ${race.name}.`,
    },
  };
}

export default async function RaceDetailPage({ params }: RacePageProps) {
  const resolvedParams = await params;
  const { race, isDemo } = await getRaceBySlug(resolvedParams.slug);

  if (!race) {
    notFound();
  }

  const formatDateTime = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleDateString('fr-FR', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return 'Heure de départ à venir';
    }
  };

  const sportsEventJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SportsEvent',
    name: race.name,
    description: race.conditions || `Course hippique ${race.name} disputée à ${race.hippodromeName}`,
    startDate: race.scheduledAt,
    location: {
      '@type': 'Place',
      name: race.hippodromeName,
      address: {
        '@type': 'PostalAddress',
        addressLocality: race.hippodromeCity,
        addressCountry: 'FR',
      },
    },
    competitor: race.participants.map((p) => ({
      '@type': 'Person',
      name: p.horseName,
      identifier: p.horseNumber,
      description: `Jockey/Driver: ${p.jockeyName || 'Inconnu'} - Entraîneur: ${p.trainerName || 'Inconnu'}`,
    })),
  };

  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Accueil',
        item: 'https://turfjournal.com',
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'Programme des courses',
        item: 'https://turfjournal.com/programme',
      },
      {
        '@type': 'ListItem',
        position: 3,
        name: race.name,
        item: `https://turfjournal.com/courses/${race.slug}`,
      },
    ],
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(sportsEventJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />

      <DemoBanner show={isDemo} />

      {/* Modern Breadcrumb */}
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <Link href="/programme" className="hover:text-emerald-700 transition-colors">Programme</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-700 font-bold truncate max-w-xs">{race.name}</span>
      </nav>

      {/* Race Hero Card */}
      <div className="card-modern p-6 sm:p-8 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2.5">
            <span className="px-3.5 py-1.5 rounded-xl bg-emerald-700 text-white text-xs font-black tracking-wider shadow-xs">
              {race.meetingCode} - C{race.raceNumber}
            </span>
            <span className="px-3 py-1 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200">
              {race.discipline.replace('_', ' ')}
            </span>
            {race.isQuinte && (
              <span className="flex items-center space-x-1.5 px-3 py-1 rounded-xl bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider shadow-sm">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Quinté+ Événement</span>
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2 text-xs font-bold text-slate-700 bg-slate-100 px-3.5 py-1.5 rounded-xl border border-slate-200">
            <Clock className="w-4 h-4 text-emerald-700" />
            <span className="capitalize">{formatDateTime(race.scheduledAt)}</span>
          </div>
        </div>

        <h1 className="text-2xl sm:text-4xl font-black text-slate-900 leading-tight">
          {race.name}
        </h1>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-600 pb-3 border-b border-slate-200">
          <span className="flex items-center space-x-1.5">
            <MapPin className="w-3.5 h-3.5 text-emerald-700" />
            <strong className="text-slate-900">{race.hippodromeName}</strong> ({race.hippodromeCity})
          </span>
          <span>•</span>
          <span>Distance : <strong className="text-slate-900 font-mono">{race.distance} m</strong></span>
          {race.purse && (
            <>
              <span>•</span>
              <span>Allocation : <strong className="text-amber-700 font-mono">{race.purse.toLocaleString('fr-FR')} €</strong></span>
            </>
          )}
          {race.trackSurface && (
            <>
              <span>•</span>
              <span>Piste : <strong className="text-slate-900">{race.trackSurface}</strong></span>
            </>
          )}
          <span>•</span>
          <span><strong className="text-slate-900">{race.participants.length}</strong> partants</span>
        </div>

        {race.conditions && (
          <p className="text-xs text-slate-600 leading-relaxed italic bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <strong>Conditions officielles :</strong> {race.conditions}
          </p>
        )}
      </div>

      <AdBanner format="horizontal" slotId="race-detail-top" />

      {/* Prediction Section */}
      <section aria-labelledby="pronostic-heading">
        <h2 id="pronostic-heading" className="sr-only">Pronostics et Analyse Statistique</h2>
        <PredictionBox prediction={race.prediction} raceName={race.name} />
      </section>

      {/* Participants Table */}
      <section aria-labelledby="partants-heading">
        <h2 id="partants-heading" className="sr-only">Tableau des partants officiels</h2>
        <ParticipantTable participants={race.participants} />
      </section>

      {/* Official Results (if finished) */}
      {race.result && (
        <div className="card-modern p-6 sm:p-8 border border-emerald-300">
          <div className="flex items-center space-x-2 text-emerald-800 font-black mb-3">
            <Award className="w-5 h-5 text-emerald-600" />
            <h3 className="text-lg text-slate-950">Résultat & Arrivée Officielle Validée</h3>
          </div>
          <div className="p-4 rounded-2xl bg-emerald-50 text-center my-3 border border-emerald-200">
            <span className="text-xs text-emerald-800 block mb-1 font-bold">Combinaison gagnante officielle</span>
            <strong className="text-2xl sm:text-3xl font-mono font-black text-slate-950 tracking-widest">
              {race.result.arrivalOrder}
            </strong>
          </div>
          {race.result.comment && (
            <p className="text-xs text-slate-600 italic mt-3">
              <strong>Notes d&apos;après-course :</strong> {race.result.comment}
            </p>
          )}
        </div>
      )}

      <AdBanner format="horizontal" slotId="race-detail-bottom" />
    </div>
  );
}

