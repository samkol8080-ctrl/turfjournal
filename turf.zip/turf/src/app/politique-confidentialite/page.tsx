﻿import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { ShieldCheck, ChevronRight, Lock } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Politique de Confidentialité (RGPD) | TurfJournal',
  description:
    'Politique de protection des données personnelles et respect de la vie privée sur turfjournal.com, en stricte conformité avec le RGPD et Google AdSense.',
  alternates: {
    canonical: '/politique-confidentialite',
  },
};

export default function PolitiqueConfidentialitePage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-800 font-bold">Confidentialité RGPD</span>
      </nav>

      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center space-x-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
          <ShieldCheck className="w-4 h-4" />
          <span>Protection des Données Personnelles</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
          Politique de Confidentialité
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
          TurfJournal s&apos;engage à protéger votre vie privée et à traiter vos données dans le respect le plus strict du Règlement Général sur la Protection des Données (RGPD 2016/679).
        </p>
      </div>

      <div className="card-modern p-6 sm:p-8 space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed border border-slate-200 bg-white">
        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">1. Responsable du Traitement</h2>
          <p>
            Le responsable du traitement des données est TurfJournal Media Group. Pour toute question relative à vos données personnelles, vous pouvez joindre notre délégué à la protection des données (DPO) à : <span className="text-emerald-700 font-semibold">privacy@turfjournal.com</span>.
          </p>
        </section>

        <section className="space-y-2 pt-4 border-t border-slate-200">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">2. Données Collectées</h2>
          <p>Nous limitons la collecte de données au strict nécessaire :</p>
          <ul className="list-disc list-inside space-y-1 pl-2">
            <li><strong>Données de navigation technique :</strong> Adresse IP anonymisée, type de navigateur, pages consultées, durée de session.</li>
            <li><strong>Données de contact :</strong> Nom et adresse e-mail lorsque vous nous contactez volontairement via le formulaire de contact.</li>
            <li><strong>Cookies de consentement :</strong> Enregistrement de votre choix concernant les traceurs publicitaires.</li>
          </ul>
        </section>

        <section className="space-y-2 pt-4 border-t border-slate-200">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">3. Google AdSense et Publicité Ciblée</h2>
          <p>
            TurfJournal fait appel à des prestataires tiers, notamment <strong>Google AdSense</strong>, pour diffuser des annonces lors de votre navigation. Google utilise des cookies pour diffuser des annonces adaptées en fonction des visites antérieures des internautes.
          </p>
          <p>
            Dans l&apos;Espace Économique Européen (EEE) et au Royaume-Uni, aucune annonce personnalisée n&apos;est déclenchée sans le consentement explicite recueilli via notre bandeau de consentement (CMP). Vous pouvez révoquer votre consentement à tout moment en visitant notre page de gestion des cookies.
          </p>
        </section>

        <section className="space-y-2 pt-4 border-t border-slate-200">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">4. Vos Droits sous le RGPD</h2>
          <p>Conformément à la réglementation européenne, vous disposez des droits suivants :</p>
          <ul className="list-disc list-inside space-y-1 pl-2">
            <li>Droit d&apos;accès à vos données personnelles</li>
            <li>Droit de rectification ou d&apos;effacement (&quot;droit à l&apos;oubli&quot;)</li>
            <li>Droit à la limitation du traitement</li>
            <li>Droit d&apos;opposition au traitement à des fins publicitaires</li>
          </ul>
          <p className="mt-2">
            Pour exercer ces droits, adressez simplement votre demande à <strong>privacy@turfjournal.com</strong>.
          </p>
        </section>
      </div>
    </div>
  );
}

