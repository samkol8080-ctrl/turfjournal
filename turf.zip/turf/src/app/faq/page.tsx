﻿import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { HelpCircle, ChevronRight, Sparkles, ShieldCheck, ArrowRight } from 'lucide-react';
import AdBanner from '@/components/ads/AdBanner';

export const metadata: Metadata = {
  title: 'Foire Aux Questions (FAQ) Turf & Pronostics | TurfJournal',
  description:
    'Trouvez les réponses à toutes vos questions sur TurfJournal, les règles du Quinté+, notre algorithme de prédiction, la gestion de bankroll et notre indépendance.',
  alternates: {
    canonical: '/faq',
  },
};

const faqs = [
  {
    q: "Qu'est-ce que turfjournal.com et quelle est votre mission ?",
    a: "TurfJournal est un portail indépendant d'information hippique, de statistiques et d'analyse algorithmique. Notre mission est de fournir aux turfistes de France, du Maroc, de Belgique, de Suisse et du monde francophone des données fiables, vérifiées et transparentes pour éclairer leur lecture des courses sans jamais faire de promesses trompeuses de gains.",
  },
  {
    q: "TurfJournal est-il un site de paris d'argent en ligne ?",
    a: "Absolument pas. TurfJournal ne prend aucun pari, n'encaisse aucun fonds et n'est pas un bookmaker. Nous sommes un média de presse et d'analyse statistique gratuit. Si vous souhaitez parier, vous devez vous adresser exclusivement aux opérateurs légalement agréés par les autorités de régulation de votre pays (ex: ANJ en France, SOREC au Maroc).",
  },
  {
    q: "Comment fonctionne votre algorithme de pronostics ?",
    a: "Notre modèle statistique évalue chaque cheval en croisant plus de 20 variables objectives : régularité de la musique récente (pondérée selon la récence), configuration de ferrure (D4, DP, DA), indice de réussite du jockey et de l'entraîneur, historique sur le parcours et aptitude à la distance. Les résultats sont traduits en une note sur 100 et un indice d'étoiles de confiance.",
  },
  {
    q: "Vos pronostics garantissent-ils des gains d'argent ?",
    a: "Non, jamais. Aucun algorithme, aucune méthode mathématique et aucun expert humain ne peut prédire l'issue d'une course avec certitude. Les courses hippiques sont soumises à de nombreux aléas sportifs (fautes d'allures, incidents de parcours, météo, état de forme du jour). Nos pronostics sont fournis à titre purement indicatif.",
  },
  {
    q: "Quelle est la différence entre le Trot Attelé et le Galop Plat ?",
    a: "Au trot attelé, le cheval est attelé à un sulky et doit obligatoirement maintenir l'allure du trot ; toute accélération au galop entraîne une disqualification (indiquée par la lettre 'D' dans la musique). En plat, les chevaux galopent librement à vitesse maximale avec un jockey sur leur dos.",
  },
  {
    q: "Pourquoi le déferrage (D4) est-il si important dans les courses de trot ?",
    a: "Courir 'pieds nus' allège la masse des membres du cheval de trot et améliore l'amplitude de sa foulée. Les statistiques démontrent qu'un cheval déferré des 4 pieds (D4) améliore ses temps au kilomètre et augmente considérablement son taux de réussite à l'arrivée.",
  },
  {
    q: "Vos services sont-ils totalement gratuits ?",
    a: "Oui, la consultation des partants, cotes, classements algorithmiques et articles sur TurfJournal est 100% gratuite et sans abonnement payant. Le site est financé de manière éthique par des emplacements publicitaires partenaires conformes aux normes Google AdSense.",
  },
  {
    q: "Comment contacter l'équipe éditoriale ?",
    a: "Vous pouvez nous écrire directement via notre formulaire de contact ou à l'adresse contact@turfjournal.com pour toute remarque, suggestion d'amélioration ou partenariat éditorial.",
  },
];

export default function FAQPage() {
  // Schema.org FAQPage Structured Data
  const faqJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: {
        '@type': 'Answer',
        text: f.a,
      },
    })),
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-800 font-bold">Foire Aux Questions</span>
      </nav>

      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center space-x-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
          <HelpCircle className="w-4 h-4" />
          <span>Centre d&apos;Aide & Réponses</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
          Foire Aux Questions (FAQ) TurfJournal
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
          Tout ce que vous devez savoir sur le fonctionnement du site, notre méthodologie d&apos;analyse et nos engagements déontologiques.
        </p>
      </div>

      <AdBanner format="horizontal" slotId="faq-top" />

      {/* FAQs List */}
      <div className="space-y-4">
        {faqs.map((faq, i) => (
          <div key={i} className="card-modern p-6 border border-slate-200 bg-white">
            <h2 className="text-base font-bold text-slate-900 mb-2 flex items-start space-x-2">
              <span className="text-emerald-700 font-mono text-sm font-black">Q{i + 1}.</span>
              <span>{faq.q}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed pl-6">
              {faq.a}
            </p>
          </div>
        ))}
      </div>

      {/* Still have questions */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 text-center space-y-3 shadow-xs">
        <h3 className="text-base font-bold text-slate-900">Vous avez une autre question ?</h3>
        <p className="text-xs text-slate-600 max-w-md mx-auto">
          Notre équipe éditoriale se tient à votre entière disposition pour vous renseigner.
        </p>
        <Link
          href="/contact"
          className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-sm"
        >
          <span>Accéder au formulaire de contact</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>

      <AdBanner format="horizontal" slotId="faq-bottom" />
    </div>
  );
}

