import { redirect } from 'next/navigation';

export default function QuinteDuJourRedirect() {
  redirect('/pronostic-quinte-du-jour');
}
