'use client';

import React, { useEffect } from 'react';
import Link from 'next/link';
import { RefreshCw, Home, AlertTriangle } from 'lucide-react';
import Logo from '@/components/common/Logo';

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log unexpected client/server errors gracefully
    console.error('TurfJournal App Error:', error);
  }, [error]);

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
      <div className="max-w-md w-full text-center space-y-6 card-modern p-8 bg-white border border-slate-200 shadow-xl">
        <div className="flex justify-center mb-2">
          <Logo size="md" showTagline={false} />
        </div>

        <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto">
          <AlertTriangle className="w-6 h-6" />
        </div>

        <div className="space-y-2">
          <h1 className="text-xl sm:text-2xl font-black text-slate-950">
            Une interruption temporaire est survenue
          </h1>
          <p className="text-xs text-slate-600 leading-relaxed">
            Le chargement des données hippiques a rencontré un incident passager. Nos systèmes travaillent à rétablir la liaison.
          </p>
        </div>

        <div className="flex flex-col space-y-2.5 pt-2">
          <button
            onClick={() => reset()}
            className="w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black transition-colors shadow-sm cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Actualiser la page</span>
          </button>

          <Link
            href="/"
            className="w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors border border-slate-200"
          >
            <Home className="w-4 h-4" />
            <span>Retourner à l&apos;accueil</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
