﻿import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Trophy, ShieldCheck, HeartHandshake, Eye, Sparkles, ChevronRight, Globe } from 'lucide-react';
import AdBanner from '@/components/ads/AdBanner';

export const metadata: Metadata = {
  title: 'À Propos de TurfJournal | Notre Équipe, Déontologie & Méthodologie',
  description:
    'Découvrez l\'histoire de TurfJournal, notre équipe de passionnés de courses hippiques, notre charte éthique et notre approche mathématique et transparente.',
  alternates: {
    canonical: '/a-propos',
  },
};

export default function AProposPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-800 font-bold">À propos</span>
      </nav>

      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center space-x-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
          <Trophy className="w-4 h-4" />
          <span>Qui sommes-nous ?</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
          À Propos de TurfJournal
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
          Le média francophone de référence pour l&apos;information et l&apos;analyse statistique hippique indépendante.
        </p>
      </div>

      <div className="card-modern p-6 sm:p-8 space-y-6 text-sm text-slate-700 leading-relaxed border border-slate-200 bg-white">
        <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
          <Sparkles className="w-5 h-5 text-amber-500" />
          <span>Notre Vision du Turf</span>
        </h2>
        <p>
          Fondé par des passionnés de longue date du monde des courses et des ingénieurs de données, <strong>TurfJournal</strong> est né d&apos;un constat simple : l&apos;univers hippique est trop souvent pollué par des promesses chimériques de &quot;gains garantis&quot; et des prédictions opaques.
        </p>
        <p>
          Nous avons choisi la voie inverse : celle de la <strong>rigueur mathématique</strong>, de l&apos;<strong>honnêteté déontologique</strong> et de la <strong>pédagogie</strong>. Nous ne vendons aucun abonnement secret. Toutes nos synthèses, statistiques et fiches de chevaux sont offertes en libre accès.
        </p>

        <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2 pt-4 border-t border-slate-200">
          <Globe className="w-5 h-5 text-emerald-700" />
          <span>Un Média Dédié à la Francophonie</span>
        </h2>
        <p>
          TurfJournal s&apos;adresse à l&apos;ensemble de la communauté hippique francophone : en <strong>France</strong>, au <strong>Maroc</strong>, en <strong>Belgique</strong>, en <strong>Suisse</strong> ainsi qu&apos;aux turfistes internationaux. Nous couvrons l&apos;actualité des grands hippodromes (Vincennes, Chantilly, Deauville, Cagnes-sur-Mer, Auteuil, etc.) avec la même exigence de précision.
        </p>

        <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2 pt-4 border-t border-slate-200">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <span>Notre Charte Éthique</span>
        </h2>
        <ul className="list-disc list-inside space-y-2 pl-2">
          <li><strong>Transparence absolue :</strong> Aucun pronostic n&apos;est présenté comme certain. L&apos;aléa fait partie intégrante du sport équestre.</li>
          <li><strong>Protection des joueurs :</strong> Nous promouvons activement le jeu responsable et rappelons systématiquement les risques d&apos;endettement liés aux jeux d&apos;argent.</li>
          <li><strong>Indépendance éditoriale :</strong> Nous ne sommes liés à aucun opérateur de paris et ne percevons aucune commission sur les pertes de nos lecteurs.</li>
          <li><strong>Conformité publicitaire :</strong> Nos partenariats publicitaires respectent strictement les exigences de Google AdSense et la protection des données personnelles (RGPD).</li>
        </ul>
      </div>

      <AdBanner format="horizontal" slotId="apropos-bottom" />
    </div>
  );
}

