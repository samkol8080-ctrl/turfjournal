import { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://turfjournal.com';

  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/api/', '/admin/', '/backend/'],
      },
      {
        userAgent: 'Googlebot',
        allow: '/',
        disallow: ['/api/', '/admin/', '/backend/'],
      },
      {
        userAgent: 'Googlebot-News',
        allow: ['/', '/actualites/', '/guides/'],
        disallow: ['/api/', '/admin/', '/backend/'],
      },
      {
        userAgent: 'Mediapartners-Google', // AdSense crawler
        allow: '/',
      },
    ],
    sitemap: [
      `${baseUrl}/sitemap.xml`,
      `${baseUrl}/feed.xml`,
    ],
  };
}

