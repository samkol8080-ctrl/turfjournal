﻿import React from 'react';
import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ChevronRight, Calendar, User } from 'lucide-react';
import { getArticleBySlug } from '@/lib/data-service';
import AdBanner from '@/components/ads/AdBanner';

interface ArticlePageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: ArticlePageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const article = await getArticleBySlug(resolvedParams.slug);

  if (!article) {
    return { title: 'Article non trouvé | TurfJournal' };
  }

  return {
    title: article.metaTitle || `${article.title} | TurfJournal`,
    description: article.metaDescription || article.excerpt,
    alternates: {
      canonical: `/actualites/${article.slug}`,
    },
    openGraph: {
      type: 'article',
      title: article.title,
      description: article.excerpt,
      publishedTime: article.publishedAt,
    },
  };
}

export default async function ArticleDetailPage({ params }: ArticlePageProps) {
  const resolvedParams = await params;
  const article = await getArticleBySlug(resolvedParams.slug);

  if (!article) {
    notFound();
  }

  const articleJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'NewsArticle',
    headline: article.title,
    description: article.excerpt,
    datePublished: article.publishedAt,
    author: {
      '@type': 'Organization',
      name: 'TurfJournal Rédaction',
    },
    publisher: {
      '@type': 'Organization',
      name: 'TurfJournal',
    },
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleJsonLd) }}
      />

      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <Link href="/actualites" className="hover:text-emerald-700 transition-colors">Actualités</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-700 font-bold truncate max-w-xs">{article.title}</span>
      </nav>

      <article className="card-modern p-6 sm:p-10 border border-slate-200">
        <header className="border-b border-slate-200 pb-6 mb-8">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 mb-4">
            {article.categoryName}
          </span>
          <h1 className="text-2xl sm:text-4xl font-black text-slate-900 leading-tight mb-4">
            {article.title}
          </h1>

          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
            <span className="flex items-center space-x-1.5">
              <User className="w-4 h-4 text-emerald-700" />
              <span>Par la rédaction TurfJournal</span>
            </span>
            <span>•</span>
            <span className="flex items-center space-x-1.5">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Publié le {new Date(article.publishedAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
            </span>
          </div>
        </header>

        {/* Excerpt Lead */}
        <p className="text-base sm:text-lg text-slate-800 leading-relaxed font-medium mb-8 bg-slate-50 p-5 rounded-2xl border border-slate-200">
          {article.excerpt}
        </p>

        <AdBanner format="rectangle" slotId="in-article-1" className="my-8" />

        {/* Content Body */}
        <div className="text-slate-700 text-sm sm:text-base leading-relaxed space-y-6">
          {article.content.split('\n\n').map((paragraph, index) => {
            if (paragraph.startsWith('### ')) {
              return (
                <h3 key={index} className="text-lg sm:text-xl font-bold text-slate-900 pt-4 border-t border-slate-100">
                  {paragraph.replace('### ', '')}
                </h3>
              );
            }
            if (paragraph.startsWith('- ')) {
              const items = paragraph.split('\n- ');
              return (
                <ul key={index} className="list-disc list-inside space-y-2 text-slate-700">
                  {items.map((it, idx) => (
                    <li key={idx}>{it.replace(/^- /, '')}</li>
                  ))}
                </ul>
              );
            }
            return <p key={index}>{paragraph}</p>;
          })}
        </div>

        {/* Tags */}
        {article.tags && (
          <div className="mt-10 pt-6 border-t border-slate-200 flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Mots-clés :</span>
            {article.tags.map((tag) => (
              <span key={tag} className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs border border-slate-200 font-medium">
                #{tag}
              </span>
            ))}
          </div>
        )}
      </article>

      <AdBanner format="horizontal" slotId="article-bottom" />
    </div>
  );
}

