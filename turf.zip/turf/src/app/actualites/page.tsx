﻿import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { TrendingUp, Clock, ArrowRight } from 'lucide-react';
import { getArticles } from '@/lib/data-service';
import AdBanner from '@/components/ads/AdBanner';

export const metadata: Metadata = {
  title: 'Actualités Hippiques, Analyses & Grands Prix Turf | TurfJournal',
  description:
    'Suivez toute l\'actualité des courses de chevaux : interviews des entraîneurs, déclarations des drivers, analyses des épreuves de Groupe et coulisses des hippodromes.',
  alternates: {
    canonical: '/actualites',
  },
};

export default async function ActualitesPage() {
  const articles = await getArticles();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center space-x-2 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
          <TrendingUp className="w-4 h-4" />
          <span>Informations & Débriefings</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
          Actualités des Courses Hippiques & Grands Prix
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl leading-relaxed">
          Retrouvez les dernières informations du peloton, les interviews d&apos;entraîneurs et nos décryptages tactiques des épreuves majeures en France et à l&apos;international.
        </p>
      </div>

      <AdBanner format="horizontal" slotId="actualites-top" />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.map((article) => (
          <article key={article.id} className="card-modern p-6 flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 mb-3">
                <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200">
                  {article.categoryName}
                </span>
                <span className="flex items-center space-x-1 text-[11px] font-medium text-slate-400">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{new Date(article.publishedAt).toLocaleDateString('fr-FR')}</span>
                </span>
              </div>

              <h2 className="text-base font-black text-slate-900 group-hover:text-emerald-700 transition-colors leading-snug mb-3">
                <Link href={`/actualites/${article.slug}`}>{article.title}</Link>
              </h2>

              <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-6">
                {article.excerpt}
              </p>
            </div>

            <Link
              href={`/actualites/${article.slug}`}
              className="inline-flex items-center space-x-2 text-xs font-bold text-emerald-700 hover:text-emerald-800 transition-colors pt-4 border-t border-slate-100"
            >
              <span>Lire l&apos;article complet</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </article>
        ))}
      </div>

      <AdBanner format="horizontal" slotId="actualites-bottom" />
    </div>
  );
}

