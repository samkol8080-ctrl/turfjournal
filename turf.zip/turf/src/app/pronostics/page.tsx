import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Sparkles, Trophy, ArrowRight, ShieldAlert } from 'lucide-react';
import { getMeetingsForDate, getTodayQuinte } from '@/lib/data-service';
import { computeHistoricalAccuracy } from '@/lib/accuracy-tracker';
import QuinteSpecial from '@/components/racing/QuinteSpecial';
import PredictionBox from '@/components/racing/PredictionBox';
import QuinteTicketGenerator from '@/components/racing/QuinteTicketGenerator';
import AdBanner from '@/components/ads/AdBanner';
import DemoBanner from '@/components/common/DemoBanner';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Pronostics Hippiques & Synthèse Quinté+ du Jour | TurfJournal',
  description:
    'Retrouvez chaque jour nos pronostics turf gratuits, indices de confiance et synthèses mathématiques pour le Quinté+ et toutes les courses des réunions PMU.',
  alternates: {
    canonical: '/pronostics',
  },
};

export default async function PronosticsPage() {
  const todayStr = new Date().toISOString().split('T')[0];
  const [{ meetings, isDemo }, { race: quinteRace }] = await Promise.all([
    getMeetingsForDate(todayStr),
    getTodayQuinte(todayStr),
  ]);

  const allRaces = meetings.flatMap((m) => m.races);
  const accuracy = computeHistoricalAccuracy(allRaces);

  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Accueil',
        item: 'https://turfjournal.com',
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'Pronostics Quinté+ & Réunions PMU',
        item: 'https://turfjournal.com/pronostics',
      },
    ],
  };

  const quintePicksJsonLd = quinteRace?.prediction ? {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: `Pronostic Quinté+ TurfJournal - ${quinteRace.name}`,
    description: quinteRace.prediction.summaryText,
    itemListElement: quinteRace.prediction.topPicks.slice(0, 8).map((p, idx) => ({
      '@type': 'ListItem',
      position: idx + 1,
      name: `N°${p.number} ${p.horseName}`,
      description: `Note: ${p.overallScore}/100 - Driver: ${p.jockeyName || 'Inconnu'}`,
    })),
  } : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      {quintePicksJsonLd && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(quintePicksJsonLd) }}
        />
      )}

      <DemoBanner show={isDemo} />

      {/* Header */}
      <div className="border-b border-slate-200 pb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Analyses Algorithmiques & Synthèses</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
            Pronostics Turf & Quinté+ du Jour
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl leading-relaxed">
            Notre modèle statistique classe les partants en analysant la musique récente, la régularité, le déferrage et la synergie jockey-entraîneur en toute transparence.
          </p>
        </div>

        {/* Quick Hub Badges */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <Link
            href="/pronostic-quinte-du-jour"
            className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black shadow-xs transition-colors"
          >
            <Trophy className="w-4 h-4 text-amber-300" />
            <span>Quinté+ Permanent</span>
          </Link>
          <Link
            href="/quinte-de-demain"
            className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black shadow-xs transition-colors"
          >
            <Sparkles className="w-4 h-4 text-slate-950" />
            <span>Quinté de Demain</span>
          </Link>
        </div>
      </div>

      {/* Accuracy Tracker Metrics Card */}
      <div className="card-modern p-5 sm:p-6 bg-gradient-to-r from-emerald-50 via-teal-50 to-white border border-emerald-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 block">
              Audit de Performance & Rigueur Mathématique
            </span>
            <h3 className="text-base sm:text-lg font-black text-slate-900">
              Précision Historique de l&apos;Algorithme TurfJournal
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-bold self-start sm:self-auto bg-white px-3 py-1 rounded-full border border-slate-200">
            {accuracy.totalEvaluatedRaces} courses auditées
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="p-3.5 rounded-xl bg-white border border-emerald-200 shadow-xs">
            <span className="text-[11px] text-slate-500 font-semibold block">Favori Placé (Top 3)</span>
            <span className="text-2xl font-black text-emerald-700 font-mono">{accuracy.top1PlaceRate}%</span>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-emerald-200 shadow-xs">
            <span className="text-[11px] text-slate-500 font-semibold block">Favori Gagnant</span>
            <span className="text-2xl font-black text-slate-900 font-mono">{accuracy.top1WinRate}%</span>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-emerald-200 shadow-xs">
            <span className="text-[11px] text-slate-500 font-semibold block">Top 3 Placé (≥2)</span>
            <span className="text-2xl font-black text-teal-700 font-mono">{accuracy.top3PlaceRate}%</span>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-emerald-200 shadow-xs">
            <span className="text-[11px] text-slate-500 font-semibold block">Quinté Réussi (≥3)</span>
            <span className="text-2xl font-black text-amber-600 font-mono">{accuracy.top5QuinteRate}%</span>
          </div>
        </div>
      </div>

      <AdBanner format="horizontal" slotId="pronostics-top" />

      {/* Quinté Spotlight */}
      {quinteRace && (
        <section aria-labelledby="quinte-heading">
          <h2 id="quinte-heading" className="sr-only">Pronostic Quinté+ du Jour</h2>
          <QuinteSpecial race={quinteRace} />
        </section>
      )}

      {/* Detailed Analysis of Quinté */}
      {quinteRace && quinteRace.prediction && (
        <section className="space-y-4">
          <h2 className="text-xl font-black text-slate-900 flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span>Détail Mathématique pour le Quinté+</span>
          </h2>
          <PredictionBox prediction={quinteRace.prediction} raceName={quinteRace.name} />
        </section>
      )}

      {/* Interactive Quinté+ Ticket Generator & Stake Simulator */}
      {quinteRace && (
        <section aria-labelledby="simulateur-heading" className="space-y-4">
          <h2 id="simulateur-heading" className="sr-only">Calculateur & Simulateur de Ticket Quinté+</h2>
          <QuinteTicketGenerator
            participants={quinteRace.participants || []}
            defaultPicks={quinteRace.prediction?.topPicks.map((p) => p.number) || []}
            raceName={quinteRace.name}
          />
        </section>
      )}

      {/* Other Races Pronostics by Meeting */}
      <section className="space-y-8 pt-4">
        <h2 className="text-2xl font-black text-slate-900">
          Pronostics pour toutes les Réunions du Jour
        </h2>

        <div className="space-y-8">
          {meetings.length === 0 ? (
            <div className="card-modern p-12 text-center border border-slate-200">
              <Sparkles className="w-12 h-12 text-slate-400 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">
                {isDemo
                  ? 'Les données PMU sont temporairement indisponibles.'
                  : 'Aucun pronostic disponible pour cette date.'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {isDemo
                  ? 'Nos serveurs tentent de rétablir la connexion avec le flux officiel PMU.'
                  : 'Consultez les réunions du jour dans le programme officiel.'}
              </p>
            </div>
          ) : (
            meetings.map((meeting) => (
            <div key={meeting.id} className="space-y-4">
              <div className="p-4 rounded-2xl bg-white border border-slate-200 flex items-center justify-between shadow-xs">
                <span className="font-black text-slate-900 text-base">
                  {meeting.code} - {meeting.name} ({meeting.hippodromeName})
                </span>
                <span className="text-xs text-slate-500 font-bold">{meeting.races.length} courses analysées</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {meeting.races.map((race) => (
                  <div key={race.id} className="card-modern p-5 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="font-black text-emerald-800 px-2.5 py-0.5 rounded-lg bg-emerald-50 border border-emerald-200">
                          {race.meetingCode} - C{race.raceNumber}
                        </span>
                        <span className="text-slate-500 font-medium">{race.discipline.replace('_', ' ')}</span>
                      </div>
                      <h4 className="text-base font-black text-slate-900 line-clamp-1 mb-2">
                        {race.name}
                      </h4>

                      {/* Top 3 Picks */}
                      {race.prediction && race.prediction.topPicks.length > 0 && (
                        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs mb-4">
                          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block">
                            Sélection prioritaire
                          </span>
                          <div className="flex items-center space-x-2">
                            {race.prediction.topPicks.slice(0, 3).map((p) => (
                              <Link
                                key={p.number}
                                href={`/chevaux/${encodeURIComponent(p.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                                className="flex items-center space-x-1.5 px-2 py-1 rounded-lg bg-white border border-slate-200 text-xs shadow-xs hover:border-emerald-500 hover:text-emerald-700 transition-colors"
                              >
                                <span className="w-5 h-5 rounded-md bg-emerald-700 text-white font-black text-[10px] flex items-center justify-center">
                                  {p.number}
                                </span>
                                <span className="font-bold text-slate-900 truncate max-w-[70px]">{p.horseName}</span>
                              </Link>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <Link
                      href={`/pronostic/${race.slug}`}
                      className="inline-flex items-center justify-center space-x-1.5 w-full py-2.5 rounded-xl bg-slate-100 hover:bg-emerald-700 hover:text-white text-xs font-black transition-all border border-slate-200 hover:border-emerald-700"
                    >
                      <span>Voir le pronostic complet</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
        </div>
      </section>

      {/* Statutory Disclaimer */}
      <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 flex items-start space-x-3 text-xs text-amber-900">
        <ShieldAlert className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <strong>Avertissement Risque :</strong> Les prédictions et indices proposés sur TurfJournal sont purement statistiques et informatifs. TurfJournal décline toute responsabilité quant aux résultats des courses réelles et aux conséquences financières des paris.
        </div>
      </div>

      <AdBanner format="horizontal" slotId="pronostics-bottom" />
    </div>
  );
}

