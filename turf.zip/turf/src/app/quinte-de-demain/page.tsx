import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { 
  Trophy, 
  Sparkles, 
  ArrowRight, 
  Calendar, 
  ChevronRight, 
  Flame, 
  Clock, 
  ShieldCheck, 
  HelpCircle,
  TrendingUp,
  MapPin,
  AlertCircle
} from 'lucide-react';
import { getTodayQuinte } from '@/lib/data-service';
import { generateQuinteEditorial } from '@/lib/editorial-generator';
import QuinteSpecial from '@/components/racing/QuinteSpecial';
import PredictionBox from '@/components/racing/PredictionBox';
import QuinteTicketGenerator from '@/components/racing/QuinteTicketGenerator';
import QuinteEditorialSection from '@/components/racing/QuinteEditorialSection';
import QuinteFaq from '@/components/racing/QuinteFaq';
import AdBanner from '@/components/ads/AdBanner';
import DemoBanner from '@/components/common/DemoBanner';

export const dynamic = 'force-dynamic';

export async function generateMetadata(): Promise<Metadata> {
  const tomorrow = new Date(Date.now() + 86400000);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];
  const { race } = await getTodayQuinte(tomorrowStr);

  const dateFormatted = tomorrow.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  if (!race) {
    return {
      title: `Pronostic Quinté de Demain (${dateFormatted}) | TurfJournal`,
      description: `Découvrez en avant-première le pronostic du Quinté de demain (${dateFormatted}) : partants probables, hippodrome, cotes matinales et premières tendances mathématiques.`,
      alternates: {
        canonical: '/quinte-de-demain',
      },
    };
  }

  const editorial = generateQuinteEditorial(race);

  return {
    title: `Pronostic Quinté de Demain - ${race.name} (${dateFormatted}) | TurfJournal`,
    description: `Pronostic Quinté+ de demain en avant-première : base solide, tocard repéré et sélection de 8 chevaux pour le ${race.name} à ${race.hippodromeName} (${dateFormatted}).`,
    keywords: [
      'Quinte de demain',
      'Pronostic Quinte de demain',
      `Quinte de demain ${race.hippodromeName}`,
      `Pronostic ${race.name}`,
      'Partants Quinte demain',
      'Base solide Quinte demain',
      'Tocard de demain Quinte',
    ],
    alternates: {
      canonical: '/quinte-de-demain',
    },
    openGraph: {
      title: `Pronostic Quinté de Demain - ${race.name} | TurfJournal`,
      description: `Pronostic complet et partants officiels du Quinté de demain pour le ${race.name}.`,
      url: 'https://turfjournal.com/quinte-de-demain',
      type: 'article',
    },
  };
}

export default async function QuinteDeDemainPage() {
  const tomorrow = new Date(Date.now() + 86400000);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];
  const { race, isDemo, isAvailable } = await getTodayQuinte(tomorrowStr);

  const dateFormatted = tomorrow.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Accueil',
        item: 'https://turfjournal.com',
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'Pronostics',
        item: 'https://turfjournal.com/pronostics',
      },
      {
        '@type': 'ListItem',
        position: 3,
        name: 'Quinté de Demain',
        item: 'https://turfjournal.com/quinte-de-demain',
      },
    ],
  };

  if (!race) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
        />

        {/* Breadcrumb */}
        <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium pb-2 border-b border-slate-200">
          <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <Link href="/pronostics" className="hover:text-emerald-700 transition-colors">Pronostics</Link>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <span className="font-bold text-slate-800">Quinté de Demain</span>
        </nav>

        <div className="card-modern p-10 sm:p-14 text-center border border-slate-200 space-y-4 max-w-2xl mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center mx-auto">
            <Clock className="w-8 h-8" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
            Pronostic Quinté de Demain ({dateFormatted})
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Les partants officiels et les cotes PMU du Quinté de demain sont publiés chaque jour par le PMU entre <strong>12h30 et 14h00</strong> la veille de la course.
          </p>
          <p className="text-xs text-slate-500">
            Dès validation par France Galop ou la SECF, notre algorithme génère immédiatement la synthèse mathématique, la base solide et le tocard repéré.
          </p>
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              href="/pronostic-quinte-du-jour"
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs shadow-xs transition-colors flex items-center justify-center space-x-2"
            >
              <Flame className="w-4 h-4 text-amber-300" />
              <span>Consulter le Quinté d&apos;Aujourd&apos;hui</span>
            </Link>
            <Link
              href="/programme"
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-white border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-50 shadow-xs"
            >
              Voir le Programme Officiel
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const editorial = generateQuinteEditorial(race);

  const sportsEventJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SportsEvent',
    name: `Quinté de Demain - ${race.name}`,
    description: editorial.metaDescription,
    startDate: race.scheduledAt,
    location: {
      '@type': 'Place',
      name: `Hippodrome de ${race.hippodromeName}`,
      address: {
        '@type': 'PostalAddress',
        addressLocality: race.hippodromeName,
        addressCountry: 'FR',
      },
    },
    competitor: race.participants?.map((p) => ({
      '@type': 'SportsTeam',
      name: `${p.horseNumber}. ${p.horseName}`,
      athlete: {
        '@type': 'Person',
        name: p.jockeyName,
      },
    })),
  };

  const faqPageJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: editorial.faqItems.map((item) => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.answer,
      },
    })),
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Schema Markup for Google */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(sportsEventJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqPageJsonLd) }}
      />

      {/* Demo Banner */}
      <DemoBanner show={isDemo} />

      {/* Top Breadcrumb & Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
          <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <Link href="/pronostics" className="hover:text-emerald-700 transition-colors">Pronostics</Link>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <span className="font-bold text-slate-800">Quinté de Demain</span>
        </nav>

        {/* Quick Link to Today's Quinté */}
        <Link
          href="/pronostic-quinte-du-jour"
          className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-black transition-all shadow-xs"
        >
          <Flame className="w-3.5 h-3.5 text-emerald-700" />
          <span>Quinté d&apos;Aujourd&apos;hui</span>
          <ArrowRight className="w-3.5 h-3.5 text-emerald-700" />
        </Link>
      </div>

      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center space-x-3">
          <span className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 font-black text-sm flex items-center justify-center shrink-0">
            J-1
          </span>
          <div>
            <h1 className="text-base sm:text-lg font-black text-slate-900">
              Pronostic Quinté de Demain - {race.name}
            </h1>
            <p className="text-xs text-slate-600">
              Course programmée le <strong>{dateFormatted}</strong> à {race.hippodromeName} • Première sélection statistique.
            </p>
          </div>
        </div>

        <span className="px-3 py-1 rounded-xl bg-white text-amber-900 text-xs font-bold border border-amber-300 self-start sm:self-auto">
          Publication Anticipée
        </span>
      </div>

      {/* Main Quinté Display */}
      <QuinteSpecial race={race} />

      {/* Editorial Content */}
      <QuinteEditorialSection race={race} editorial={editorial} />

      {/* Prediction Details */}
      {race.prediction && (
        <section className="space-y-4">
          <h2 className="text-xl font-black text-slate-900 flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span>Synthèse Mathématique Quinté de Demain</span>
          </h2>
          <PredictionBox prediction={race.prediction} raceName={race.name} />
        </section>
      )}

      {/* Stake Simulator */}
      <section aria-labelledby="simulateur-heading" className="space-y-4">
        <h2 id="simulateur-heading" className="sr-only">Simulateur de Mises Quinté de Demain</h2>
        <QuinteTicketGenerator
          participants={race.participants || []}
          defaultPicks={race.prediction?.topPicks.map((p) => p.number) || []}
          raceName={race.name}
        />
      </section>

      {/* FAQ */}
      <QuinteFaq items={editorial.faqItems} raceName={race.name} />
    </div>
  );
}
