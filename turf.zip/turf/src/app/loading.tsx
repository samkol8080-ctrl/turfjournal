import React from 'react';

export default function Loading() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-pulse">
      {/* Top Banner Skeleton */}
      <div className="h-28 rounded-3xl bg-slate-200/70 border border-slate-200" />

      {/* Hero Skeleton */}
      <div className="h-64 rounded-3xl bg-slate-200/60 border border-slate-200" />

      {/* Grid Skeleton */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="h-48 rounded-2xl bg-white border border-slate-200/80 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="w-20 h-6 bg-slate-200 rounded-lg" />
              <div className="w-16 h-6 bg-slate-200 rounded-lg" />
            </div>
            <div className="w-3/4 h-5 bg-slate-200 rounded-md" />
            <div className="w-1/2 h-4 bg-slate-100 rounded-md" />
            <div className="w-full h-8 bg-slate-100 rounded-xl mt-4" />
          </div>
        ))}
      </div>
    </div>
  );
}
