import React from 'react';
import Link from 'next/link';
import { Home, Calendar, Sparkles, ArrowLeft } from 'lucide-react';
import Logo from '@/components/common/Logo';

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
      <div className="max-w-md w-full text-center space-y-6 card-modern p-8 bg-white border border-slate-200 shadow-xl">
        <div className="flex justify-center mb-2">
          <Logo size="md" showTagline={false} />
        </div>

        <div className="space-y-2">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300">
            Erreur 404 • Page introuvable
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950">
            Course ou Page Non Trouvée
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            La page, la course ou la fiche que vous recherchez n&apos;existe pas ou a été déplacée dans le programme officiel.
          </p>
        </div>

        <div className="flex flex-col space-y-2.5 pt-2">
          <Link
            href="/"
            className="w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black transition-colors shadow-sm"
          >
            <Home className="w-4 h-4" />
            <span>Retour à l&apos;accueil TurfJournal</span>
          </Link>

          <Link
            href="/programme"
            className="w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors border border-slate-200"
          >
            <Calendar className="w-4 h-4 text-emerald-700" />
            <span>Consulter le programme du jour</span>
          </Link>

          <Link
            href="/pronostics"
            className="w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors border border-slate-200"
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Voir les pronostics Quinté+</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
