import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { 
  Trophy, 
  Sparkles, 
  ArrowRight, 
  Calendar, 
  ChevronRight, 
  Flame, 
  Clock, 
  ShieldCheck, 
  HelpCircle,
  TrendingUp,
  MapPin
} from 'lucide-react';
import { getTodayQuinte } from '@/lib/data-service';
import { generateQuinteEditorial } from '@/lib/editorial-generator';
import QuinteSpecial from '@/components/racing/QuinteSpecial';
import PredictionBox from '@/components/racing/PredictionBox';
import QuinteTicketGenerator from '@/components/racing/QuinteTicketGenerator';
import QuinteEditorialSection from '@/components/racing/QuinteEditorialSection';
import QuinteFaq from '@/components/racing/QuinteFaq';
import AdBanner from '@/components/ads/AdBanner';
import DemoBanner from '@/components/common/DemoBanner';

export const dynamic = 'force-dynamic';

export async function generateMetadata(): Promise<Metadata> {
  const todayStr = new Date().toISOString().split('T')[0];
  const { race } = await getTodayQuinte(todayStr);

  const dateFormatted = new Date().toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  if (!race) {
    return {
      title: `Pronostic Quinté+ du Jour (${dateFormatted}) | TurfJournal`,
      description: `Pronostic Quinté+ officiel du jour, partants PMU, cotes en direct et base solide pour les courses hippiques du ${dateFormatted}.`,
      alternates: {
        canonical: '/pronostic-quinte-du-jour',
      },
    };
  }

  const editorial = generateQuinteEditorial(race);

  return {
    title: editorial.metaTitle,
    description: editorial.metaDescription,
    keywords: [
      `Pronostic ${race.name}`,
      `Quinte du jour ${race.hippodromeName}`,
      'Base solide Quinte',
      'Tocard du jour Quinte',
      'Derniere minute Quinte',
      'Arrivee et rapports Quinte du jour',
      `Partants Quinte ${dateFormatted}`,
      'Pronostic hippique gratuit',
    ],
    alternates: {
      canonical: '/pronostic-quinte-du-jour',
    },
    openGraph: {
      title: editorial.metaTitle,
      description: editorial.metaDescription,
      url: 'https://turfjournal.com/pronostic-quinte-du-jour',
      type: 'article',
    },
  };
}

export default async function PronosticQuinteDuJourPage() {
  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  const { race, isDemo, isAvailable } = await getTodayQuinte(todayStr);

  const dateFormatted = new Date().toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  if (!race) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
        <DemoBanner show={isDemo} />
        <div className="card-modern p-12 text-center border border-slate-200">
          <Trophy className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <h1 className="text-2xl font-black text-slate-900">
            Pronostic Quinté+ du Jour ({dateFormatted})
          </h1>
          <p className="text-sm text-slate-500 mt-2 max-w-lg mx-auto">
            {isDemo
              ? 'Les données officielles PMU sont temporairement indisponibles. Reconnexion automatique en cours.'
              : 'La course support du Quinté+ pour aujourd\'hui est en cours de validation par le PMU.'}
          </p>
          <div className="pt-6 flex justify-center gap-3">
            <Link
              href="/programme"
              className="px-5 py-2.5 rounded-xl bg-emerald-700 text-white font-bold text-xs shadow-xs"
            >
              Consulter le Programme du Jour
            </Link>
            <Link
              href="/quinte-de-demain"
              className="px-5 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-50 shadow-xs"
            >
              Voir le Quinté de Demain
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const editorial = generateQuinteEditorial(race);

  // JSON-LD Schemas
  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Accueil',
        item: 'https://turfjournal.com',
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'Pronostic Quinté+ du Jour',
        item: 'https://turfjournal.com/pronostic-quinte-du-jour',
      },
    ],
  };

  const sportsEventJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SportsEvent',
    name: `Quinté+ - ${race.name}`,
    description: editorial.metaDescription,
    startDate: race.scheduledAt,
    location: {
      '@type': 'Place',
      name: `Hippodrome de ${race.hippodromeName}`,
      address: {
        '@type': 'PostalAddress',
        addressLocality: race.hippodromeName,
        addressCountry: 'FR',
      },
    },
    competitor: race.participants?.map((p) => ({
      '@type': 'SportsTeam',
      name: `${p.horseNumber}. ${p.horseName}`,
      athlete: {
        '@type': 'Person',
        name: p.jockeyName,
      },
    })),
  };

  const faqPageJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: editorial.faqItems.map((item) => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.answer,
      },
    })),
  };

  const picksItemListJsonLd = race.prediction ? {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: `Sélection Quinté+ TurfJournal - ${race.name}`,
    description: race.prediction.summaryText,
    itemListElement: race.prediction.topPicks.slice(0, 8).map((p, idx) => ({
      '@type': 'ListItem',
      position: idx + 1,
      name: `${p.number}. ${p.horseName}`,
      description: `Classé #${p.rank} (${p.category}) avec un score global de ${p.overallScore}/100. Driver : ${p.jockeyName}.`,
    })),
  } : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Schema Markup for Google */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(sportsEventJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqPageJsonLd) }}
      />
      {picksItemListJsonLd && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(picksItemListJsonLd) }}
        />
      )}

      {/* Demo Banner */}
      <DemoBanner show={isDemo} />

      {/* Breadcrumb & Navigation Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
          <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <Link href="/pronostics" className="hover:text-emerald-700 transition-colors">Pronostics</Link>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <span className="font-bold text-slate-800">Quinté+ du Jour</span>
        </nav>

        {/* Quick Link to Tomorrow's Quinté */}
        <div className="flex items-center space-x-2 shrink-0">
          <Link
            href="/quinte-de-demain"
            className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-black transition-all shadow-xs"
          >
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>Quinté de Demain</span>
            <ArrowRight className="w-3.5 h-3.5 text-amber-700" />
          </Link>
        </div>
      </div>

      {/* Main Quinté+ Hero Display */}
      <section aria-labelledby="quinte-main-heading">
        <h1 id="quinte-main-heading" className="sr-only">
          Pronostic Quinté+ du Jour - {race.name} ({dateFormatted})
        </h1>
        <QuinteSpecial race={race} />
      </section>

      {/* Top Banner Ad */}
      <AdBanner format="horizontal" slotId="quinte-top" />

      {/* Supporting Editorial Analysis Section (300 to 500 words) with H2 Headings */}
      <QuinteEditorialSection race={race} editorial={editorial} />

      {/* Mathematical Detail Box */}
      {race.prediction && (
        <section className="space-y-4">
          <h2 className="text-xl font-black text-slate-900 flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span>Analyse Mathématique Complète des Partants</span>
          </h2>
          <PredictionBox prediction={race.prediction} raceName={race.name} />
        </section>
      )}

      {/* Interactive Ticket Generator & Stake Calculator */}
      <section aria-labelledby="simulateur-heading" className="space-y-4">
        <h2 id="simulateur-heading" className="sr-only">Calculateur & Simulateur de Ticket Quinté+</h2>
        <QuinteTicketGenerator
          participants={race.participants || []}
          defaultPicks={race.prediction?.topPicks.map((p) => p.number) || []}
          raceName={race.name}
        />
      </section>

      {/* Rich FAQ Accordion Section */}
      <QuinteFaq items={editorial.faqItems} raceName={race.name} />

      {/* Bottom Ad */}
      <AdBanner format="horizontal" slotId="quinte-bottom" />
    </div>
  );
}
