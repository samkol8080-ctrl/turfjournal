import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Calendar, Sparkles, Award, BookOpen, ArrowRight, ShieldCheck, Trophy } from 'lucide-react';
import { getMeetingsForDate, getTodayQuinte, getArticles, getRecentResults } from '@/lib/data-service';
import QuinteSpecial from '@/components/racing/QuinteSpecial';
import RaceCard from '@/components/racing/RaceCard';
import AdBanner from '@/components/ads/AdBanner';
import DemoBanner from '@/components/common/DemoBanner';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'TurfJournal | Pronostics Quinté+, Partants PMU & Résultats en Direct',
  description:
    'Découvrez les pronostics du Quinté+ du jour, les partants officiels PMU, les cotes en direct et les résultats des courses hippiques à Vincennes, Chantilly et dans toute la France.',
  alternates: {
    canonical: '/',
  },
  openGraph: {
    title: 'TurfJournal | Pronostics Quinté+, Partants PMU & Résultats en Direct',
    description: 'Analyses statistiques pointues, partants officiels, cotes et résultats des courses hippiques en direct.',
    url: 'https://turfjournal.com',
    type: 'website',
  },
};

export default async function HomePage() {
  const todayStr = new Date().toISOString().split('T')[0];
  const [{ meetings, isDemo }, { race: quinteRace }, { races: recentResults }, articles] = await Promise.all([
    getMeetingsForDate(todayStr),
    getTodayQuinte(todayStr),
    getRecentResults(todayStr),
    getArticles(),
  ]);

  const websiteJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'TurfJournal',
    url: 'https://turfjournal.com',
    potentialAction: {
      '@type': 'SearchAction',
      target: 'https://turfjournal.com/programme?q={search_term_string}',
      'query-input': 'required name=search_term_string',
    },
  };

  const meetingsItemListJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: 'Réunions PMU du Jour',
    itemListElement: meetings.map((m, idx) => ({
      '@type': 'ListItem',
      position: idx + 1,
      name: `${m.code} - ${m.name} (${m.hippodromeName})`,
      url: `https://turfjournal.com/programme#meeting-${m.id}`,
    })),
  };

  return (
    <div className="pb-20 space-y-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }}
      />
      {meetings.length > 0 && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(meetingsItemListJsonLd) }}
        />
      )}

      {/* Informative Header Banner */}
      <DemoBanner show={isDemo} />

      {/* Top Header Leaderboard Ad */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-2">
        <AdBanner format="horizontal" slotId="home-leaderboard" label="Espace Partenaire" />
      </div>

      {/* Hero Quinté+ du Jour */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {quinteRace ? (
          <QuinteSpecial race={quinteRace} />
        ) : (
          <div className="card-modern p-10 text-center border border-slate-200">
            <Trophy className="w-12 h-12 text-emerald-700 mx-auto mb-3" />
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900">
              Programme et Pronostics Hippiques
            </h1>
            <p className="text-slate-600 text-sm max-w-xl mx-auto mt-2">
              Retrouvez toutes les réunions du jour, les partants officiels et les analyses statistiques de nos experts.
            </p>
          </div>
        )}
      </section>

      {/* Today's Meetings & Races */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
          <div>
            <div className="flex items-center space-x-2 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
              <Calendar className="w-4 h-4" />
              <span>Programme & Réunions</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              Toutes les Courses du Jour
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Sélectionnez une course pour découvrir les partants officiels, les cotes en direct et les pronostics.
            </p>
          </div>

          <Link
            href="/programme"
            className="inline-flex items-center space-x-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-100 text-xs font-bold text-slate-700 border border-slate-200 transition-colors self-start sm:self-auto shadow-xs"
          >
            <span>Calendrier complet</span>
            <ArrowRight className="w-3.5 h-3.5 text-emerald-700" />
          </Link>
        </div>

        {/* Quick Meeting Jump Pills Menu */}
        {meetings.length > 0 && (
          <nav aria-label="Accès rapide aux réunions" className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-xs font-black text-slate-400 uppercase tracking-wider shrink-0 mr-1">
              Réunions :
            </span>
            {meetings.map((m) => (
              <a
                key={m.id}
                href={`#reunion-${m.code.toLowerCase()}`}
                className="shrink-0 inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-xl bg-white hover:bg-emerald-50 text-slate-800 hover:text-emerald-900 border border-slate-200 hover:border-emerald-300 text-xs font-bold shadow-xs transition-all"
              >
                <span className="w-5 h-5 rounded-md bg-emerald-700 text-white font-black text-[11px] flex items-center justify-center">
                  {m.code}
                </span>
                <span>{m.name}</span>
                <span className="text-[11px] font-semibold text-slate-400">({m.races.length})</span>
              </a>
            ))}
          </nav>
        )}

        {/* Meetings Loop */}
        <div className="space-y-10">
          {meetings.length === 0 ? (
            <div className="card-modern p-12 text-center border border-slate-200">
              <Calendar className="w-12 h-12 text-slate-400 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">
                {isDemo
                  ? 'Les données PMU sont temporairement indisponibles.'
                  : 'Aucune réunion enregistrée pour cette date.'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {isDemo
                  ? 'Veuillez vérifier votre connexion ou réessayer dans quelques instants.'
                  : 'Consultez le calendrier complet pour voir les prochaines courses programmées.'}
              </p>
            </div>
          ) : (
            meetings.map((meeting) => (
              <div key={meeting.id} id={`reunion-${meeting.code.toLowerCase()}`} className="space-y-4 scroll-mt-24">
                {/* Meeting Header Capsule */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
                  <div className="flex items-center space-x-3.5">
                    <span className="w-10 h-10 rounded-xl bg-emerald-700 text-white font-black text-base flex items-center justify-center shadow-xs">
                      {meeting.code}
                    </span>
                    <div>
                      <h3 className="text-base font-black text-slate-900">{meeting.name}</h3>
                      <p className="text-xs text-slate-500">
                        Hippodrome de {meeting.hippodromeName} • {meeting.city} • Piste {meeting.surface || 'Standard'} ({meeting.trackType || 'Corde à gauche'})
                      </p>
                    </div>
                  </div>

                  <span className="px-3 py-1 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 self-start sm:self-auto">
                    {meeting.races.length} courses
                  </span>
                </div>

                {/* Races Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {meeting.races.map((race) => (
                    <RaceCard key={race.id} race={race} />
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* Mid Ad */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <AdBanner format="horizontal" slotId="home-mid" label="Partenaire Officiel" />
      </div>

      {/* Latest Official Results */}
      {recentResults.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div>
              <div className="flex items-center space-x-2 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
                <Award className="w-4 h-4" />
                <span>Arrivées Homologuées</span>
              </div>
              <h2 className="text-2xl font-black text-slate-900">
                Derniers Résultats & Rapports
              </h2>
            </div>
            <Link
              href="/resultats"
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 transition-colors flex items-center space-x-1"
            >
              <span>Tous les résultats</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {recentResults.slice(0, 3).map((r) => (
              <div key={r.id} className="card-modern p-5 border border-slate-200">
                <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                  <span className="font-bold text-emerald-700">{r.meetingCode} - C{r.raceNumber}</span>
                  <span className="font-medium text-slate-800 truncate max-w-[150px]">{r.name}</span>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-center my-3">
                  <span className="text-[10px] text-emerald-800 uppercase tracking-widest block font-bold mb-1">
                    Arrivée officielle
                  </span>
                  <strong className="text-xl text-slate-950 font-mono font-black tracking-widest">
                    {r.result?.arrivalOrder}
                  </strong>
                </div>
                {r.result?.comment && (
                  <p className="text-xs text-slate-500 line-clamp-2 mt-2 italic">
                    {r.result.comment}
                  </p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Educational Guides */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <div className="flex items-center space-x-2 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
              <BookOpen className="w-4 h-4" />
              <span>Apprentissage & Méthodes</span>
            </div>
            <h2 className="text-2xl font-black text-slate-900">
              Guides Pratiques pour Turfistes
            </h2>
          </div>
          <Link
            href="/guides"
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 transition-colors flex items-center space-x-1"
          >
            <span>Tous les guides</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {articles.slice(0, 3).map((article) => {
            const articleHref = article.categorySlug === 'guides' ? `/guides/${article.slug}` : `/actualites/${article.slug}`;
            return (
              <article key={article.id} className="card-modern p-6 flex flex-col justify-between group">
                <div>
                  <span className="inline-block px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 mb-3">
                    {article.categoryName}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 group-hover:text-emerald-700 transition-colors leading-snug mb-2">
                    <Link href={articleHref}>{article.title}</Link>
                  </h3>
                  <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed mb-4">
                    {article.excerpt}
                  </p>
                </div>

                <Link
                  href={articleHref}
                  className="inline-flex items-center space-x-1.5 text-xs font-bold text-emerald-700 group-hover:underline pt-3 border-t border-slate-100"
                >
                  <span>Lire l&apos;article complet</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </article>
            );
          })}
        </div>
      </section>

      {/* Responsible Gaming Footer Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <div className="p-6 rounded-3xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Jouer avec modération et discernement
              </h3>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                Le turf est un sport et un divertissement. Ne misez jamais d&apos;argent dont vous avez besoin pour vivre.
              </p>
            </div>
          </div>
          <Link
            href="/jeu-responsable"
            className="px-5 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold border border-slate-200 transition-colors whitespace-nowrap shadow-xs"
          >
            En savoir plus
          </Link>
        </div>
      </section>
    </div>
  );
}
