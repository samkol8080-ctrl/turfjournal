import type { Metadata } from 'next';
import Script from 'next/script';
import './globals.css';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import CookieConsent from '@/components/ads/CookieConsent';
import { getSiteSettings } from '@/lib/settings-service';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://turfjournal.com'),
  title: {
    default: 'TurfJournal | Pronostics Hippiques, Quinté+ du Jour & Résultats PMU',
    template: '%s | TurfJournal',
  },
  description:
    'Site d\'information hippique gratuit : découvrez les pronostics du Quinté+, partants, cotes en direct, résultats officiels, analyses de courses et guides turf pour la France, le Maroc, la Belgique et la Suisse.',
  keywords: [
    'pronostic quinte',
    'quinte du jour',
    'courses hippiques',
    'partants pmu',
    'resultats pmu',
    'trot attelé',
    'pronostics turf',
    'hippodrome de vincennes',
    'turf maroc',
    'pmu suisse',
    'turf belgique',
  ],
  authors: [{ name: 'TurfJournal Rédaction', url: 'https://turfjournal.com' }],
  creator: 'TurfJournal',
  publisher: 'TurfJournal Media',
  alternates: {
    canonical: '/',
  },
  openGraph: {
    type: 'website',
    locale: 'fr_FR',
    url: 'https://turfjournal.com',
    title: 'TurfJournal | Pronostics Hippiques & Quinté+ du Jour',
    description: 'Analyses statistiques pointues, partants officiels, cotes et résultats des courses hippiques.',
    siteName: 'TurfJournal',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'TurfJournal | Analyses et Pronostics Hippiques',
    description: 'Les pronostics statistiques et arrivées officielles des courses PMU.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/icon.svg',
    shortcut: '/icon.svg',
    apple: '/icon.svg',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const settings = getSiteSettings();

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SportsOrganization',
    name: settings.siteName || 'TurfJournal',
    url: settings.siteUrl || 'https://turfjournal.com',
    description: settings.brandTagline || 'Média d\'information et d\'analyse statistique sur les courses hippiques.',
    logo: 'https://turfjournal.com/logo.svg',
    areaServed: ['FR', 'MA', 'BE', 'CH'],
    knowsLanguage: ['fr'],
  };

  const gscTag = settings.seoAndAnalytics?.googleSearchConsoleTag;
  const gaId = settings.seoAndAnalytics?.googleAnalyticsId;
  const announcement = settings.announcement;

  return (
    <html lang="fr">
      <head>
        {/* Google Search Console Verification Meta Tag */}
        {gscTag && <meta name="google-site-verification" content={gscTag} />}

        {/* RSS News & Podcast Feeds */}
        <link rel="alternate" type="application/rss+xml" title="TurfJournal - Actualités & Pronostics Hippiques" href="/feed.xml" />
        <link rel="alternate" type="application/rss+xml" title="TurfJournal Flux RSS" href="/rss.xml" />

        {/* Performance Preconnect & DNS-Prefetch */}
        <link rel="preconnect" href="https://offline.turfinfo.api.pmu.fr" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="https://offline.turfinfo.api.pmu.fr" />
        <link rel="dns-prefetch" href="https://pagead2.googlesyndication.com" />
        <link rel="dns-prefetch" href="https://www.googletagmanager.com" />

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        {/* Google Analytics 4 (GA4) Script */}
        {gaId && (
          <>
            <Script
              src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`}
              strategy="afterInteractive"
            />
            <Script id="ga4-init" strategy="afterInteractive">
              {`
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', '${gaId}', {
                  page_path: window.location.pathname,
                });
              `}
            </Script>
          </>
        )}
      </head>
      <body className="bg-[#F8FAFC] text-slate-900 flex flex-col min-h-screen antialiased selection:bg-[#FDE68A] selection:text-slate-900">
        {/* Dynamic Top Announcement Bar (Configurable in Admin) */}
        {announcement?.isEnabled && announcement.text && (
          <aside aria-label="Annonce officielle" className="bg-emerald-800 text-white text-xs font-semibold py-2 px-4 text-center border-b border-emerald-900 flex items-center justify-center space-x-2">
            <span>{announcement.text}</span>
            {announcement.linkUrl && announcement.linkText && (
              <a
                href={announcement.linkUrl}
                className="underline hover:text-amber-300 font-bold ml-1 transition-colors"
              >
                {announcement.linkText} →
              </a>
            )}
          </aside>
        )}

        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
        <CookieConsent />
      </body>
    </html>
  );
}

