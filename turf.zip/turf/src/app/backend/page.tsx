import { redirect } from 'next/navigation';

export default function BackendRedirect() {
  redirect('/admin');
}
