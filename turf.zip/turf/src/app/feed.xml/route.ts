import { NextResponse } from 'next/server';
import { getArticles, getTodayQuinte } from '@/lib/data-service';

export const dynamic = 'force-dynamic';

export async function GET() {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://turfjournal.com';
  const todayStr = new Date().toISOString().split('T')[0];

  const [articles, { race: quinteRace }] = await Promise.all([
    getArticles(),
    getTodayQuinte(todayStr),
  ]);

  const items: string[] = [];

  // Quinté+ of the day item
  if (quinteRace) {
    items.push(`
    <item>
      <title><![CDATA[Pronostic Quinté+ du Jour : ${quinteRace.name} à ${quinteRace.hippodromeName}]]></title>
      <link>${baseUrl}/courses/${quinteRace.slug}</link>
      <guid isPermaLink="true">${baseUrl}/courses/${quinteRace.slug}</guid>
      <description><![CDATA[Partants officiels, cotes en direct et synthèse mathématique pour le Quinté+ ${quinteRace.name} disputé à ${quinteRace.hippodromeName}.]]></description>
      <category>Pronostics Quinté+</category>
      <pubDate>${new Date(quinteRace.scheduledAt).toUTCString()}</pubDate>
    </item>`);
  }

  // Articles items
  articles.forEach((art) => {
    const artUrl = `${baseUrl}/${art.categorySlug === 'guides' ? 'guides' : 'actualites'}/${art.slug}`;
    items.push(`
    <item>
      <title><![CDATA[${art.title}]]></title>
      <link>${artUrl}</link>
      <guid isPermaLink="true">${artUrl}</guid>
      <description><![CDATA[${art.excerpt || art.title}]]></description>
      <category>${art.categoryName || 'Actualités'}</category>
      <pubDate>${new Date(art.publishedAt).toUTCString()}</pubDate>
    </item>`);
  });

  const rssXml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>TurfJournal | Média des Courses Hippiques &amp; Pronostics PMU</title>
    <link>${baseUrl}</link>
    <description>Actualités officielles des courses hippiques, partants du Quinté+, cotes en direct et analyses statistiques TurfJournal.</description>
    <language>fr-FR</language>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
    <atom:link href="${baseUrl}/feed.xml" rel="self" type="application/rss+xml"/>
    ${items.join('\n')}
  </channel>
</rss>`;

  return new NextResponse(rssXml, {
    headers: {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, s-maxage=1200, stale-while-revalidate=600',
    },
  });
}
