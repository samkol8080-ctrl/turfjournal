﻿'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Mail, MessageSquare, Send, CheckCircle2, ChevronRight, MapPin, Globe } from 'lucide-react';
import AdBanner from '@/components/ads/AdBanner';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'Question générale',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simuler l'envoi vers l'API de contact
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 800);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-800 font-bold">Contact</span>
      </nav>

      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center space-x-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
          <Mail className="w-4 h-4" />
          <span>Nous Contacter</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
          Contactez la Rédaction de TurfJournal
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
          Une suggestion, une remarque sur nos données ou une demande de partenariat éditorial ? Écrivez-nous.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Contact Info Sidebar */}
        <div className="space-y-4">
          <div className="card-modern p-5 space-y-4 border border-slate-200 bg-white text-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-2">Coordonnées</h3>
            <div className="flex items-start space-x-3">
              <Mail className="w-4 h-4 text-emerald-700 flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-slate-500 block">Courriel de contact</span>
                <span className="text-slate-900 font-semibold">contact@turfjournal.com</span>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Globe className="w-4 h-4 text-emerald-700 flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-slate-500 block">Couverture</span>
                <span className="text-slate-900 font-semibold">France, Maroc, Belgique, Suisse</span>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <MessageSquare className="w-4 h-4 text-emerald-700 flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-slate-500 block">Délai de réponse moyen</span>
                <span className="text-slate-900 font-semibold">Sous 24 à 48 heures ouvrées</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 leading-relaxed font-medium">
            <strong>Rappel important :</strong> TurfJournal n&apos;est pas un opérateur de jeux et ne gère aucun compte de pari ni réclamation financière.
          </div>
        </div>

        {/* Form Container */}
        <div className="md:col-span-2">
          <div className="card-modern p-6 sm:p-8 border border-slate-200 bg-white">
            {submitted ? (
              <div className="p-8 text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                <h3 className="text-lg font-bold text-slate-900">Message envoyé avec succès !</h3>
                <p className="text-xs text-slate-600 max-w-sm mx-auto">
                  Merci de nous avoir contactés. Notre équipe éditoriale prendra connaissance de votre message dans les meilleurs délais.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-4 px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs text-slate-800 font-bold transition-colors"
                >
                  Envoyer un autre message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div>
                  <label htmlFor="name" className="block font-bold text-slate-800 mb-1">
                    Votre Nom ou Pseudonyme <span className="text-emerald-700">*</span>
                  </label>
                  <input
                    type="text"
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white transition-colors"
                    placeholder="ex: Jean Dupont"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block font-bold text-slate-800 mb-1">
                    Adresse Courriel <span className="text-emerald-700">*</span>
                  </label>
                  <input
                    type="email"
                    id="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white transition-colors"
                    placeholder="jean.dupont@exemple.com"
                  />
                </div>

                <div>
                  <label htmlFor="subject" className="block font-bold text-slate-800 mb-1">
                    Objet de la demande
                  </label>
                  <select
                    id="subject"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white transition-colors"
                  >
                    <option value="Question générale">Question générale</option>
                    <option value="Remarque sur un pronostic">Remarque sur un pronostic ou une course</option>
                    <option value="Partenariat & Presse">Partenariat & Presse</option>
                    <option value="Signalement technique">Signalement technique</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block font-bold text-slate-800 mb-1">
                    Votre Message <span className="text-emerald-700">*</span>
                  </label>
                  <textarea
                    id="message"
                    required
                    rows={5}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white transition-colors leading-relaxed"
                    placeholder="Détaillez votre message ici..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full inline-flex items-center justify-center space-x-2 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-sm transition-all disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{loading ? 'Envoi en cours...' : 'Envoyer mon message'}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      <AdBanner format="horizontal" slotId="contact-bottom" />
    </div>
  );
}

