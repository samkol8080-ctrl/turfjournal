import React from 'react';
import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Clock, MapPin, Sparkles, ChevronRight, Award, Trophy, Compass } from 'lucide-react';
import { getRaceBySlug } from '@/lib/data-service';
import { generateQuinteEditorial } from '@/lib/editorial-generator';
import ParticipantTable from '@/components/racing/ParticipantTable';
import PredictionBox from '@/components/racing/PredictionBox';
import QuinteEditorialSection from '@/components/racing/QuinteEditorialSection';
import QuinteTicketGenerator from '@/components/racing/QuinteTicketGenerator';
import QuinteFaq from '@/components/racing/QuinteFaq';
import AdBanner from '@/components/ads/AdBanner';
import DemoBanner from '@/components/common/DemoBanner';

export const dynamic = 'force-dynamic';

interface PronosticPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PronosticPageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const { race } = await getRaceBySlug(resolvedParams.slug);

  if (!race) {
    return {
      title: 'Pronostic Course Hippique Introuvable | TurfJournal',
    };
  }

  const quinteLabel = race.isQuinte ? ' [Quinté+]' : '';
  const dateFormatted = new Date(race.scheduledAt || Date.now()).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return {
    title: `Pronostic ${race.name}${quinteLabel} (${dateFormatted}) - Partants, Cotes & Base`,
    description: `Pronostic pour le ${race.name} (${race.meetingCode}-C${race.raceNumber}) à ${race.hippodromeName} du ${dateFormatted}. Analyse des partants officiels PMU, cotes en direct et base solide.`,
    alternates: {
      canonical: `/pronostic/${race.slug}`,
    },
    openGraph: {
      title: `Pronostic ${race.name} - TurfJournal`,
      description: `Découvrez la sélection mathématique et les cotes en direct pour le ${race.name}.`,
      url: `https://turfjournal.com/pronostic/${race.slug}`,
      type: 'article',
    },
  };
}

export default async function StandaloneRacePronosticPage({ params }: PronosticPageProps) {
  const resolvedParams = await params;
  const { race, isDemo } = await getRaceBySlug(resolvedParams.slug);

  if (!race) {
    notFound();
  }

  const formatDateTime = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleDateString('fr-FR', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return iso;
    }
  };

  const editorial = generateQuinteEditorial(race);

  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Accueil',
        item: 'https://turfjournal.com',
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'Programme PMU',
        item: 'https://turfjournal.com/programme',
      },
      {
        '@type': 'ListItem',
        position: 3,
        name: `${race.meetingCode} - C${race.raceNumber} : ${race.name}`,
        item: `https://turfjournal.com/pronostic/${race.slug}`,
      },
    ],
  };

  const sportsEventJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SportsEvent',
    name: race.name,
    description: `Course ${race.discipline} sur ${race.distance}m à ${race.hippodromeName}.`,
    startDate: race.scheduledAt,
    location: {
      '@type': 'Place',
      name: `Hippodrome de ${race.hippodromeName}`,
      address: {
        '@type': 'PostalAddress',
        addressLocality: race.hippodromeName,
        addressCountry: 'FR',
      },
    },
    competitor: race.participants?.map((p) => ({
      '@type': 'SportsTeam',
      name: `${p.horseNumber}. ${p.horseName}`,
      athlete: {
        '@type': 'Person',
        name: p.jockeyName,
      },
    })),
  };

  const faqPageJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: editorial.faqItems.map((item) => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.answer,
      },
    })),
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Google Schemas */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(sportsEventJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqPageJsonLd) }}
      />

      <DemoBanner show={isDemo} />

      {/* Fil d'Ariane */}
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <Link href="/programme" className="hover:text-emerald-700 transition-colors">Programme</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="font-bold text-slate-800">{race.meetingCode} - C{race.raceNumber}</span>
      </nav>

      {/* Hero Course Header */}
      <div className="card-modern p-6 sm:p-8 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="px-3.5 py-1.5 rounded-xl bg-emerald-700 text-white font-black text-xs shadow-xs">
              {race.meetingCode} - C{race.raceNumber}
            </span>
            <span className="px-3 py-1 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200">
              {race.discipline.replace(/_/g, ' ')}
            </span>
            {race.isQuinte && (
              <span className="flex items-center space-x-1.5 px-3 py-1 rounded-xl bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider shadow-xs">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Support Quinté+</span>
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2 text-xs font-bold text-slate-600 bg-slate-50 px-3.5 py-1.5 rounded-xl border border-slate-200">
            <Clock className="w-4 h-4 text-emerald-700" />
            <span>Départ : {formatDateTime(race.scheduledAt)}</span>
          </div>
        </div>

        <h1 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Pronostic {race.name}
        </h1>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs sm:text-sm text-slate-600">
          <span className="flex items-center space-x-1 text-slate-800 font-semibold">
            <MapPin className="w-4 h-4 text-emerald-700" />
            <span>Hippodrome de {race.hippodromeName}</span>
          </span>
          <span>•</span>
          <span className="font-mono">{race.distance} mètres</span>
          {race.purse && (
            <>
              <span>•</span>
              <span className="text-amber-800 font-black font-mono">
                Allocation : {race.purse.toLocaleString('fr-FR')} €
              </span>
            </>
          )}
          <span>•</span>
          <span className="font-bold text-slate-700">{race.participants?.length || 0} Partants Officiels</span>
        </div>
      </div>

      <AdBanner format="horizontal" slotId="race-top" />

      {/* Tableau des partants avec liens internes */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black text-slate-900">
            Partants Officiels & Cotes PMU en Direct
          </h2>
          <span className="text-xs text-slate-500 font-semibold">
            Cliquez sur un cheval pour consulter son palmarès complet
          </span>
        </div>
        <ParticipantTable participants={race.participants || []} />
      </section>

      {/* Editorial Section (300 to 500 words) with H2 Headings */}
      <QuinteEditorialSection race={race} editorial={editorial} />

      {/* Algorithmic Prediction Box */}
      {race.prediction && (
        <section className="space-y-4">
          <h2 className="text-xl font-black text-slate-900 flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span>Synthèse Statistique & Indices de Performance</span>
          </h2>
          <PredictionBox prediction={race.prediction} raceName={race.name} />
        </section>
      )}

      {/* Stake Simulator */}
      <section aria-labelledby="simulateur-heading" className="space-y-4">
        <h2 id="simulateur-heading" className="sr-only">Simulateur de Mises</h2>
        <QuinteTicketGenerator
          participants={race.participants || []}
          defaultPicks={race.prediction?.topPicks.map((p) => p.number) || []}
          raceName={race.name}
        />
      </section>

      {/* FAQ */}
      <QuinteFaq items={editorial.faqItems} raceName={race.name} />

      <AdBanner format="horizontal" slotId="race-bottom" />
    </div>
  );
}
