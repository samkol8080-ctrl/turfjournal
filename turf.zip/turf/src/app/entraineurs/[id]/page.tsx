import React from 'react';
import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ChevronRight } from 'lucide-react';
import { getTrainerProfile } from '@/lib/data-service';
import AdBanner from '@/components/ads/AdBanner';

interface TrainerPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: TrainerPageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const trainer = await getTrainerProfile(resolvedParams.id);

  if (!trainer) {
    return {
      title: 'Entraîneur non trouvé | TurfJournal',
      description: 'Fiche entraîneur non trouvée dans les données officielles PMU.',
    };
  }

  return {
    title: `${trainer.name} : Entraîneur Hippique, Effectif & Statistiques | TurfJournal`,
    description: `Fiche de l'entraîneur hippique ${trainer.name} : ${trainer.wins} victoires, ${trainer.runners} partants engagés, taux de réussite.`,
    alternates: {
      canonical: `/entraineurs/${trainer.id}`,
    },
  };
}

export default async function TrainerDetailPage({ params }: TrainerPageProps) {
  const resolvedParams = await params;
  const trainer = await getTrainerProfile(resolvedParams.id);

  if (!trainer) {
    notFound();
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span>Entraîneurs</span>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-700 font-bold">{trainer.name}</span>
      </nav>

      <div className="card-modern p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <span className="text-xs uppercase font-bold text-emerald-700 tracking-wider block mb-1">
              Fiche Écurie & Entraîneur
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900">{trainer.name}</h1>
            <p className="text-xs text-slate-500 mt-1">
              Responsable de préparation et entraînement pour chevaux de compétition hippique.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-center min-w-[100px]">
              <span className="text-[10px] text-emerald-800 uppercase font-bold block">Taux Victoire</span>
              <strong className="text-xl font-black text-emerald-800 font-mono">{trainer.winRate}%</strong>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Victoires</span>
            <span className="text-xl font-black text-slate-900 font-mono">{trainer.wins}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Places sur le podium</span>
            <span className="text-xl font-black text-slate-900 font-mono">{trainer.places}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Partants engagés</span>
            <span className="text-xl font-black text-slate-700 font-mono">{trainer.runners}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Réussite dans les 3</span>
            <span className="text-xl font-black text-emerald-700 font-mono">
              {(((trainer.wins + trainer.places) / trainer.runners) * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      <AdBanner format="horizontal" slotId="trainer-bottom" />
    </div>
  );
}

