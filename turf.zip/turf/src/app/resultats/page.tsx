import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Award, Clock, ChevronRight, FileText } from 'lucide-react';
import { getRecentResults } from '@/lib/data-service';
import AdBanner from '@/components/ads/AdBanner';
import DemoBanner from '@/components/common/DemoBanner';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Résultats des Courses & Arrivées Officielles PMU | TurfJournal',
  description:
    'Consultez en direct les arrivées officielles, rapports du Quinté+, rapports simples gagnants/placés et notes des commissaires pour toutes les courses disputées.',
  alternates: {
    canonical: '/resultats',
  },
};

export default async function ResultatsPage() {
  const todayStr = new Date().toISOString().split('T')[0];
  const { races: finishedRaces, isDemo } = await getRecentResults(todayStr);

  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Accueil',
        item: 'https://turfjournal.com',
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'Résultats & Rapports PMU',
        item: 'https://turfjournal.com/resultats',
      },
    ],
  };

  const resultsItemListJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: 'Résultats Officiels des Courses PMU',
    itemListElement: finishedRaces.map((r, idx) => ({
      '@type': 'ListItem',
      position: idx + 1,
      name: `${r.meetingCode} C${r.raceNumber} - ${r.name}`,
      description: `Arrivée officielle : ${r.result?.arrivalOrder || 'En cours'}`,
      url: `https://turfjournal.com/courses/${r.slug}`,
    })),
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      {finishedRaces.length > 0 && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(resultsItemListJsonLd) }}
        />
      )}

      <DemoBanner show={isDemo} />

      {/* Header */}
      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center space-x-2 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
          <Award className="w-4 h-4" />
          <span>Arrivées & Rapports Homologués</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
          Résultats Officiels des Courses
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl leading-relaxed">
          Toutes les arrivées officielles, numéros gagnants dans l&apos;ordre, rapports payés aux parieurs et débriefs techniques validés par les commissaires.
        </p>
      </div>

      <AdBanner format="horizontal" slotId="resultats-top" />

      {/* Results Feed */}
      <div className="space-y-6">
        {finishedRaces.length === 0 ? (
          <div className="card-modern p-12 text-center border border-slate-200">
            <Clock className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">
              {isDemo ? 'Les données PMU sont temporairement indisponibles.' : 'Aucun résultat définitif pour le moment'}
            </h3>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              {isDemo
                ? 'Nos serveurs tentent de rétablir la connexion avec le flux officiel PMU.'
                : 'Les arrivées et rapports officiels sont publiés immédiatement après validation par les juges à l\'arrivée.'}
            </p>
            <Link
              href="/programme"
              className="inline-block mt-4 px-5 py-2.5 rounded-xl bg-emerald-700 text-white text-xs font-black shadow-xs"
            >
              Consulter les courses à venir
            </Link>
          </div>
        ) : (
          finishedRaces.map((race) => (
            <div key={race.id} className="card-modern p-6 border border-slate-200 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                <div className="flex items-center space-x-3">
                  <span className="px-3 py-1 rounded-xl bg-emerald-100 text-emerald-800 font-black text-xs border border-emerald-300">
                    {race.meetingCode} - C{race.raceNumber}
                  </span>
                  <div>
                    <h2 className="text-base font-black text-slate-900">{race.name}</h2>
                    <p className="text-xs text-slate-500">
                      {race.hippodromeName} • {race.distance}m • {race.discipline.replace('_', ' ')}
                    </p>
                  </div>
                </div>

                <Link
                  href={`/courses/${race.slug}`}
                  className="text-xs font-bold text-slate-600 hover:text-emerald-700 flex items-center space-x-1"
                >
                  <span>Revoir les partants</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </Link>
              </div>

              {/* Arrival Order Banner */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-black tracking-wider block">
                    Ordre d&apos;arrivée homologué
                  </span>
                  <strong className="text-2xl sm:text-3xl font-mono font-black text-slate-950 tracking-widest">
                    {race.result?.arrivalOrder}
                  </strong>
                </div>

                {/* Reports Dividends */}
                <div className="flex flex-wrap items-center gap-3 text-xs">
                  {race.result?.reportSimpleGagnant && (
                    <div className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 shadow-xs">
                      <span className="text-slate-500 block text-[10px]">Simple Gagnant (1€)</span>
                      <strong className="text-emerald-700 font-mono text-base font-bold">{race.result.reportSimpleGagnant.toFixed(2)} €</strong>
                    </div>
                  )}
                  {race.result?.reportSimplePlace && (
                    <div className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 shadow-xs">
                      <span className="text-slate-500 block text-[10px]">Simple Placé (1€)</span>
                      <strong className="text-slate-800 font-mono text-base font-bold">{race.result.reportSimplePlace.toFixed(2)} €</strong>
                    </div>
                  )}
                  {race.result?.reportQuinte && (
                    <div className="px-3.5 py-2 rounded-xl bg-amber-50 border border-amber-200 shadow-xs">
                      <span className="text-amber-800 block text-[10px] font-bold">Rapport Quinté Désordre</span>
                      <strong className="text-amber-950 font-mono text-base font-black">{race.result.reportQuinte.toLocaleString('fr-FR')} €</strong>
                    </div>
                  )}
                </div>
              </div>

              {/* Debrief / Commentary */}
              {race.result?.comment && (
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 flex items-start space-x-2.5">
                  <FileText className="w-4 h-4 text-slate-500 flex-shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong>Débriefing de l&apos;épreuve :</strong> {race.result.comment}
                  </p>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      <AdBanner format="horizontal" slotId="resultats-bottom" />
    </div>
  );
}

