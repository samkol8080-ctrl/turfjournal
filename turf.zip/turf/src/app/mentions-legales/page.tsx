﻿import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { ShieldCheck, ChevronRight } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Mentions Légales | TurfJournal',
  description: 'Mentions légales, éditeur du site, hébergement et conditions d\'utilisation de turfjournal.com.',
  alternates: {
    canonical: '/mentions-legales',
  },
};

export default function MentionsLegalesPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-800 font-bold">Mentions Légales</span>
      </nav>

      <div className="border-b border-slate-200 pb-6">
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">Mentions Légales</h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2">
          Conformément aux dispositions des lois pour la confiance dans l&apos;économie numérique.
        </p>
      </div>

      <div className="card-modern p-6 sm:p-8 space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed border border-slate-200 bg-white">
        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">1. Éditeur du Site</h2>
          <p>
            Le site <strong>turfjournal.com</strong> est édité par la société <strong>TurfJournal Media Group</strong>, société spécialisée dans l&apos;édition de contenus numériques et d&apos;analyses de données sportives.
          </p>
          <p>
            Courriel de contact : <span className="text-emerald-700 font-semibold">contact@turfjournal.com</span>
          </p>
          <p>Directeur de la publication : Équipe éditoriale TurfJournal.</p>
        </section>

        <section className="space-y-2 pt-4 border-t border-slate-200">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">2. Hébergement de la Plateforme</h2>
          <p>
            Le site est hébergé sur des serveurs sécurisés situés dans l&apos;Union Européenne, assurant une conformité rigoureuse avec les standards de haute disponibilité et la réglementation RGPD.
          </p>
        </section>

        <section className="space-y-2 pt-4 border-t border-slate-200">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">3. Propriété Intellectuelle</h2>
          <p>
            L&apos;ensemble des éléments composant le site turfjournal.com (charte graphique, algorithmes de classement, textes, analyses, structure des bases de données et logos) sont la propriété exclusive de TurfJournal Media Group, protégés par le droit d&apos;auteur international. Toute reproduction non autorisée sans accord écrit préalable est formellement interdite.
          </p>
        </section>

        <section className="space-y-2 pt-4 border-t border-slate-200">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">4. Nature du Service et Limitation de Responsabilité</h2>
          <p>
            turfjournal.com est un portail de presse et d&apos;information statistique indépendant. En aucun cas le site ne constitue un service de paris d&apos;argent ni un intermédiaire de jeu. Les analyses sont fournies à titre indicatif et ne comportent aucune garantie de résultat. TurfJournal ne saurait être tenu responsable des pertes financières directes ou indirectes résultant de l&apos;utilisation des informations publiées.
          </p>
        </section>
      </div>
    </div>
  );
}

