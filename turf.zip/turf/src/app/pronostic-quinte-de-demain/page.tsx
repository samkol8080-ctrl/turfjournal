import { redirect } from 'next/navigation';

export default function PronosticQuinteDeDemainRedirect() {
  redirect('/quinte-de-demain');
}
