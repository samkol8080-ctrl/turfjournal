import { NextRequest, NextResponse } from 'next/server';
import { getSiteSettings } from '@/lib/settings-service';

export const dynamic = 'force-dynamic';

const SESSION_COOKIE_NAME = 'turfjournal_admin_session';

// Simple token generator based on secret + date signature
function createSessionToken(password: string): string {
  const secret = process.env.CRON_SECRET || 'turfjournal_secret_session_2026';
  const data = `${password}-${secret}-${new Date().toISOString().slice(0, 10)}`;
  return Buffer.from(data).toString('base64');
}

function isValidSessionToken(token: string, expectedPassword: string): boolean {
  try {
    const decoded = Buffer.from(token, 'base64').toString('utf-8');
    const secret = process.env.CRON_SECRET || 'turfjournal_secret_session_2026';
    return decoded.startsWith(`${expectedPassword}-${secret}`);
  } catch {
    return false;
  }
}

export async function GET(req: NextRequest) {
  try {
    const sessionCookie = req.cookies.get(SESSION_COOKIE_NAME)?.value;
    const settings = getSiteSettings();

    if (!sessionCookie) {
      return NextResponse.json({ authenticated: false });
    }

    const valid = isValidSessionToken(sessionCookie, settings.adminPassword);
    return NextResponse.json({ authenticated: valid });
  } catch {
    return NextResponse.json({ authenticated: false });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { password } = body;

    const settings = getSiteSettings();

    if (!password || password !== settings.adminPassword) {
      return NextResponse.json(
        { success: false, message: 'Mot de passe incorrect' },
        { status: 401 }
      );
    }

    const token = createSessionToken(password);
    const response = NextResponse.json({
      success: true,
      message: 'Authentification réussie',
    });

    // HTTP-Only Secure Cookie
    response.cookies.set({
      name: SESSION_COOKIE_NAME,
      value: token,
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24 * 7, // 7 jours
    });

    return response;
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Erreur d\'authentification' },
      { status: 500 }
    );
  }
}

export async function DELETE() {
  const response = NextResponse.json({
    success: true,
    message: 'Déconnexion effectuée',
  });

  response.cookies.delete(SESSION_COOKIE_NAME);
  return response;
}
