import { NextRequest, NextResponse } from 'next/server';
import {
  getAllArticles,
  getArticleBySlug,
  saveArticle,
  deleteArticle,
} from '@/lib/article-service';
import { getSiteSettings } from '@/lib/settings-service';

/**
 * Vérifie l'autorisation d'accès pour écrire / modifier des articles :
 * 1. Cookie de session administrateur (panneau /admin)
 * 2. Token Bearer HTTP (ex: Authorization: Bearer <password_or_key>)
 * 3. En-tête X-API-KEY (ex: X-API-KEY: <password_or_key>)
 */
function isAuthorized(req: NextRequest): boolean {
  const settings = getSiteSettings();
  const validSecrets = [
    settings.adminPassword,
    process.env.ADMIN_PASSWORD,
    process.env.RACING_API_KEY,
    process.env.CRON_SECRET,
  ].filter(Boolean) as string[];

  // 1. Cookie session admin
  const sessionCookie = req.cookies.get('turfjournal_admin_session')?.value;
  if (sessionCookie && validSecrets.some((s) => sessionCookie === `auth_${s}`)) {
    return true;
  }

  // 2. Authorization Bearer header
  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.toLowerCase().startsWith('bearer ')) {
    const token = authHeader.substring(7).trim();
    if (token && validSecrets.includes(token)) {
      return true;
    }
  }

  // 3. X-API-KEY header
  const apiKeyHeader = req.headers.get('x-api-key');
  if (apiKeyHeader && validSecrets.includes(apiKeyHeader.trim())) {
    return true;
  }

  return false;
}

/**
 * GET /api/articles : Récupération des articles et actualités
 * Paramètres optionnels :
 * - category : slug de la catégorie (ex: actualites, quinte, guides)
 * - limit : nombre maximal d'articles à retourner
 * - slug : récupérer un article unique par son slug
 */
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const slug = searchParams.get('slug');
    const category = searchParams.get('category') || undefined;
    const limit = searchParams.get('limit') ? parseInt(searchParams.get('limit')!, 10) : undefined;
    const all = searchParams.get('all') === 'true';

    // Récupération d'un article spécifique
    if (slug) {
      const article = await getArticleBySlug(slug);
      if (!article) {
        return NextResponse.json({ success: false, message: 'Article non trouvé' }, { status: 404 });
      }
      return NextResponse.json({ success: true, article });
    }

    // Autoriser l'affichage des brouillons si administrateur
    const onlyPublished = all && isAuthorized(req) ? false : true;

    const articles = await getAllArticles({
      categorySlug: category,
      limit,
      onlyPublished,
    });

    return NextResponse.json({
      success: true,
      count: articles.length,
      articles,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, message: 'Erreur lors de la récupération des articles', error: err.message },
      { status: 500 }
    );
  }
}

/**
 * POST /api/articles : Création d'un nouvel article d'actualité
 * Accessible via l'espace admin ou par script externe / API (Bearer token ou X-API-KEY)
 */
export async function POST(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json(
      {
        success: false,
        message: 'Accès non autorisé. Fournissez un cookie de session admin ou un token Bearer valide.',
      },
      { status: 401 }
    );
  }

  try {
    const body = await req.json();

    if (!body.title || !body.title.trim()) {
      return NextResponse.json(
        { success: false, message: 'Le titre de l\'article est obligatoire.' },
        { status: 400 }
      );
    }

    if (!body.content || !body.content.trim()) {
      return NextResponse.json(
        { success: false, message: 'Le contenu de l\'article est obligatoire.' },
        { status: 400 }
      );
    }

    const saved = await saveArticle({
      title: body.title.trim(),
      slug: body.slug ? body.slug.trim() : undefined,
      excerpt: body.excerpt ? body.excerpt.trim() : undefined,
      content: body.content.trim(),
      categorySlug: body.categorySlug || 'actualites',
      categoryName: body.categoryName,
      featuredImage: body.featuredImage,
      isPublished: body.isPublished !== undefined ? Boolean(body.isPublished) : true,
      publishedAt: body.publishedAt || new Date().toISOString(),
      metaTitle: body.metaTitle,
      metaDescription: body.metaDescription,
      tags: Array.isArray(body.tags) ? body.tags : body.tags ? body.tags.split(',').map((t: string) => t.trim()) : undefined,
    });

    return NextResponse.json({
      success: true,
      message: 'Article d\'actualité publié avec succès !',
      article: saved,
      url: `/actualites/${saved.slug}`,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, message: 'Erreur lors de la création de l\'article', error: err.message },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/articles : Mise à jour d'un article existant
 */
export async function PUT(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ success: false, message: 'Accès non autorisé.' }, { status: 401 });
  }

  try {
    const body = await req.json();

    if (!body.id && !body.slug) {
      return NextResponse.json(
        { success: false, message: 'Identifiant (id ou slug) obligatoire pour la mise à jour.' },
        { status: 400 }
      );
    }

    const saved = await saveArticle(body);

    return NextResponse.json({
      success: true,
      message: 'Article mis à jour avec succès.',
      article: saved,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, message: 'Erreur lors de la mise à jour de l\'article', error: err.message },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/articles : Suppression d'un article
 */
export async function DELETE(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ success: false, message: 'Accès non autorisé.' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id') || searchParams.get('slug');

    if (!id) {
      return NextResponse.json(
        { success: false, message: 'Paramètre id ou slug obligatoire.' },
        { status: 400 }
      );
    }

    const deleted = await deleteArticle(id);

    if (!deleted) {
      return NextResponse.json(
        { success: false, message: 'Article non trouvé ou déjà supprimé.' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Article supprimé avec succès.',
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, message: 'Erreur lors de la suppression', error: err.message },
      { status: 500 }
    );
  }
}
