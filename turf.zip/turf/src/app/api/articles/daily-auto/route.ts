import { NextRequest, NextResponse } from 'next/server';
import { getTodayQuinte } from '@/lib/data-service';
import { generateActualityWithGemini } from '@/lib/gemini-service';
import { getSiteSettings } from '@/lib/settings-service';

function isAuthorized(req: NextRequest): boolean {
  const settings = getSiteSettings();
  const validSecrets = [
    settings.adminPassword,
    process.env.ADMIN_PASSWORD,
    process.env.RACING_API_KEY,
    process.env.CRON_SECRET,
  ].filter(Boolean) as string[];

  // 1. Cookie session admin
  const sessionCookie = req.cookies.get('turfjournal_admin_session')?.value;
  if (sessionCookie && validSecrets.some((s) => sessionCookie === `auth_${s}`)) {
    return true;
  }

  // 2. Authorization Bearer header
  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.toLowerCase().startsWith('bearer ')) {
    const token = authHeader.substring(7).trim();
    if (token && validSecrets.includes(token)) {
      return true;
    }
  }

  // 3. X-API-KEY header
  const apiKeyHeader = req.headers.get('x-api-key');
  if (apiKeyHeader && validSecrets.includes(apiKeyHeader.trim())) {
    return true;
  }

  // 4. Secret query param (pour appel cron automatisé facile)
  const url = new URL(req.url);
  const secretParam = url.searchParams.get('secret') || url.searchParams.get('key');
  if (secretParam && validSecrets.includes(secretParam)) {
    return true;
  }

  return false;
}

/**
 * GET ou POST /api/articles/daily-auto
 * Génère automatiquement l'actualité hippique officielle du Quinté+ du jour
 * à partir des données en temps réel PMU.
 */
export async function POST(req: NextRequest) {
  return handleGenerateDailyNews(req);
}

export async function GET(req: NextRequest) {
  return handleGenerateDailyNews(req);
}

async function handleGenerateDailyNews(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json(
      {
        success: false,
        message: 'Accès non autorisé. Fournissez un cookie admin, une clé API ou le secret cron.',
      },
      { status: 401 }
    );
  }

  try {
    const url = new URL(req.url);
    const dateParam = url.searchParams.get('date') || undefined;

    // Récupérer la course phare du Quinté+ du jour (ou de la date demandée)
    const { race: quinteRace } = await getTodayQuinte(dateParam);

    // Générer l'article d'actualité enrichi avec Google Gemini AI
    const result = await generateActualityWithGemini(quinteRace, dateParam);

    return NextResponse.json({
      success: true,
      isNew: result.isNew,
      message: result.message,
      source: result.source,
      modelUsed: result.modelUsed,
      durationMs: result.latencyMs,
      article: result.article,
      url: `/actualites/${result.article.slug}`,
    });
  } catch (err: any) {
    return NextResponse.json(
      {
        success: false,
        message: 'Erreur lors de la génération automatique de l\'actualité',
        error: err.message,
      },
      { status: 500 }
    );
  }
}
