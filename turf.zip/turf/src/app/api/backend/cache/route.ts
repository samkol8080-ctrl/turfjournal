import { NextRequest, NextResponse } from 'next/server';
import { revalidatePath } from 'next/cache';
import { RacingApiClient } from '@/lib/racing-api';
import { clearArticlesMemoryCache } from '@/lib/article-service';
import { clearSettingsMemoryCache, getSiteSettings } from '@/lib/settings-service';

function isAuthorized(req: NextRequest): boolean {
  const settings = getSiteSettings();
  const validSecrets = [settings.adminPassword, process.env.ADMIN_PASSWORD].filter(Boolean) as string[];

  const sessionCookie = req.cookies.get('turfjournal_admin_session')?.value;
  if (sessionCookie && validSecrets.some((s) => sessionCookie === `auth_${s}`)) {
    return true;
  }

  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.toLowerCase().startsWith('bearer ')) {
    const token = authHeader.substring(7).trim();
    if (token && validSecrets.includes(token)) return true;
  }

  const apiKeyHeader = req.headers.get('x-api-key');
  if (apiKeyHeader && validSecrets.includes(apiKeyHeader.trim())) return true;

  const url = new URL(req.url);
  const secretParam = url.searchParams.get('key') || url.searchParams.get('secret');
  if (secretParam && validSecrets.includes(secretParam)) return true;

  return false;
}

export async function POST(req: NextRequest) {
  return handleClearCache(req);
}

export async function GET(req: NextRequest) {
  return handleClearCache(req);
}

async function handleClearCache(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ success: false, message: 'Accès non autorisé' }, { status: 401 });
  }

  const start = Date.now();

  try {
    // 1. Vider le cache de l'API PMU et courses en mémoire
    RacingApiClient.clearCache();

    // 2. Vider le cache des articles et guides
    clearArticlesMemoryCache();

    // 3. Vider le cache des paramètres du site
    clearSettingsMemoryCache();

    // 4. Invalider les chemins du cache Next.js (ISR & SSR)
    const routesToRevalidate = [
      '/',
      '/programme',
      '/pronostics',
      '/resultats',
      '/actualites',
      '/guides',
      '/sitemap.xml',
    ];

    try {
      revalidatePath('/', 'layout');
      for (const route of routesToRevalidate) {
        revalidatePath(route);
      }
    } catch (e) {
      console.warn('Revalidation Next.js partielle :', e);
    }

    const durationMs = Date.now() - start;

    return NextResponse.json({
      success: true,
      message: 'Cache du site vidé avec succès ! Données fraîches actives sur mobile et ordinateur.',
      durationMs,
      timestamp: new Date().toISOString(),
      cleared: {
        racingApiCache: true,
        articlesCache: true,
        settingsCache: true,
        nextPagesRevalidated: routesToRevalidate,
      },
    });
  } catch (err: any) {
    return NextResponse.json(
      {
        success: false,
        message: 'Erreur lors de la purge du cache',
        error: err.message,
      },
      { status: 500 }
    );
  }
}
