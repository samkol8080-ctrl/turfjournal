import { NextRequest, NextResponse } from 'next/server';
import { getSiteSettings, saveSiteSettings } from '@/lib/settings-service';
import { testGeminiConnection, generateActualityWithGemini } from '@/lib/gemini-service';
import { getTodayQuinte } from '@/lib/data-service';

function isAuthorized(req: NextRequest): boolean {
  const settings = getSiteSettings();
  const validSecrets = [settings.adminPassword, process.env.ADMIN_PASSWORD].filter(Boolean) as string[];

  const sessionCookie = req.cookies.get('turfjournal_admin_session')?.value;
  if (sessionCookie && validSecrets.some((s) => sessionCookie === `auth_${s}`)) {
    return true;
  }

  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.toLowerCase().startsWith('bearer ')) {
    const token = authHeader.substring(7).trim();
    if (token && validSecrets.includes(token)) return true;
  }

  const apiKeyHeader = req.headers.get('x-api-key');
  if (apiKeyHeader && validSecrets.includes(apiKeyHeader.trim())) return true;

  return false;
}

export async function GET(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ success: false, message: 'Accès non autorisé' }, { status: 401 });
  }

  const settings = getSiteSettings();
  const geminiConfig = settings.gemini || {
    apiKey: '',
    model: 'gemini-1.5-flash',
    autoUpdateDaily: true,
  };

  const rawKey = geminiConfig.apiKey || process.env.GEMINI_API_KEY || '';
  const maskedKey = rawKey.length > 8 ? `${rawKey.substring(0, 6)}...${rawKey.substring(rawKey.length - 4)}` : rawKey ? 'Configurée' : '';

  return NextResponse.json({
    success: true,
    isConfigured: !!rawKey,
    apiKey: rawKey,
    maskedApiKey: maskedKey,
    model: geminiConfig.model || 'gemini-1.5-flash',
    autoUpdateDaily: geminiConfig.autoUpdateDaily ?? true,
  });
}

export async function POST(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ success: false, message: 'Accès non autorisé' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const action = body.action || 'save_config';

    // 1. Tester la connexion à l'API Gemini
    if (action === 'test') {
      const result = await testGeminiConnection(body.apiKey, body.model);
      return NextResponse.json(result);
    }

    // 2. Déclencher immédiatement la rédaction avec Gemini
    if (action === 'generate_now') {
      const { race: quinteRace } = await getTodayQuinte();
      const result = await generateActualityWithGemini(quinteRace);
      return NextResponse.json(result);
    }

    // 3. Sauvegarder la configuration Gemini
    const current = getSiteSettings();
    const updated = saveSiteSettings({
      gemini: {
        apiKey: body.apiKey !== undefined ? body.apiKey.trim() : current.gemini?.apiKey || '',
        model: body.model || current.gemini?.model || 'gemini-1.5-flash',
        autoUpdateDaily: body.autoUpdateDaily !== undefined ? Boolean(body.autoUpdateDaily) : true,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Configuration Google Gemini API enregistrée avec succès !',
      gemini: {
        isConfigured: !!updated.gemini.apiKey,
        model: updated.gemini.model,
        autoUpdateDaily: updated.gemini.autoUpdateDaily,
      },
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, message: 'Erreur lors de la configuration de Gemini', error: err.message },
      { status: 500 }
    );
  }
}
