import { NextRequest, NextResponse } from 'next/server';
import { getSiteSettings, saveSiteSettings } from '@/lib/settings-service';

function isAuthorized(req: NextRequest): boolean {
  const settings = getSiteSettings();
  const validSecrets = [settings.adminPassword, process.env.ADMIN_PASSWORD].filter(Boolean) as string[];

  const sessionCookie = req.cookies.get('turfjournal_admin_session')?.value;
  if (sessionCookie && validSecrets.some((s) => sessionCookie === `auth_${s}`)) {
    return true;
  }

  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.toLowerCase().startsWith('bearer ')) {
    const token = authHeader.substring(7).trim();
    if (token && validSecrets.includes(token)) return true;
  }

  const apiKeyHeader = req.headers.get('x-api-key');
  if (apiKeyHeader && validSecrets.includes(apiKeyHeader.trim())) return true;

  return false;
}

export async function GET() {
  const settings = getSiteSettings();
  return NextResponse.json({
    success: true,
    partnerSpace: settings.partnerSpace || {
      isEnabled: false,
      customBannerText: '',
      customBannerLink: '',
      badgeLabel: 'Espace Partenaire',
    },
  });
}

export async function POST(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ success: false, message: 'Accès non autorisé' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const current = getSiteSettings();

    const updated = saveSiteSettings({
      partnerSpace: {
        isEnabled: body.isEnabled !== undefined ? Boolean(body.isEnabled) : current.partnerSpace?.isEnabled ?? false,
        customBannerText: body.customBannerText !== undefined ? String(body.customBannerText) : current.partnerSpace?.customBannerText,
        customBannerLink: body.customBannerLink !== undefined ? String(body.customBannerLink) : current.partnerSpace?.customBannerLink,
        badgeLabel: body.badgeLabel !== undefined ? String(body.badgeLabel) : current.partnerSpace?.badgeLabel || 'Espace Partenaire',
      },
    });

    return NextResponse.json({
      success: true,
      message: updated.partnerSpace.isEnabled
        ? 'Espace Partenaire activé sur le site'
        : 'Espace Partenaire désactivé (aucun bloc publicitaire affiché)',
      partnerSpace: updated.partnerSpace,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, message: 'Erreur lors de la mise à jour de l\'Espace Partenaire', error: err.message },
      { status: 500 }
    );
  }
}
