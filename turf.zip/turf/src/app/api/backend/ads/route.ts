import { NextRequest, NextResponse } from 'next/server';
import {
  getAdSenseConfig,
  updateAdSenseConfig,
  deleteAdSense,
  addAdPlacement,
  removeAdPlacement,
} from '@/lib/settings-service';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const config = getAdSenseConfig();
    return NextResponse.json({ success: true, config });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Erreur lecture configuration' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Cas 1 : Ajout d'un nouvel emplacement publicitaire
    if (body.action === 'add_placement') {
      const { name, slotId, format, location } = body;
      if (!name || !slotId) {
        return NextResponse.json(
          { success: false, message: 'Nom et identifiant de slot requis' },
          { status: 400 }
        );
      }
      const newPlacement = addAdPlacement({
        name,
        slotId,
        format: format || 'horizontal',
        location: location || 'custom',
        isEnabled: true,
      });
      return NextResponse.json({
        success: true,
        message: 'Emplacement publicitaire ajouté',
        placement: newPlacement,
        config: getAdSenseConfig(),
      });
    }

    // Cas 2 : Mise à jour globale de la configuration AdSense (activer, désactiver, changer le clientId)
    const { isEnabled, clientId, autoAdsEnabled } = body;
    const updated = updateAdSenseConfig({
      ...(typeof isEnabled === 'boolean' ? { isEnabled } : {}),
      ...(typeof clientId === 'string' ? { clientId: clientId.trim() } : {}),
      ...(typeof autoAdsEnabled === 'boolean' ? { autoAdsEnabled } : {}),
    });

    return NextResponse.json({
      success: true,
      message: 'Configuration AdSense mise à jour avec succès',
      config: updated,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Erreur mise à jour configuration' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const placementId = searchParams.get('placementId');

    // Cas 1 : Supprimer un emplacement spécifique
    if (placementId) {
      const ok = removeAdPlacement(placementId);
      if (!ok) {
        return NextResponse.json(
          { success: false, message: 'Emplacement introuvable' },
          { status: 404 }
        );
      }
      return NextResponse.json({
        success: true,
        message: 'Emplacement publicitaire supprimé',
        config: getAdSenseConfig(),
      });
    }

    // Cas 2 : Supprimer / désactiver AdSense complètement
    const cleared = deleteAdSense();
    return NextResponse.json({
      success: true,
      message: 'Google AdSense a été complètement supprimé et désactivé du site',
      config: cleared,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Erreur suppression' },
      { status: 500 }
    );
  }
}
