import { NextRequest, NextResponse } from 'next/server';
import { getSiteSettings, saveSiteSettings } from '@/lib/settings-service';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const settings = getSiteSettings();
    // Ne pas exposer le mot de passe en clair dans la réponse
    const safeSettings = {
      ...settings,
      hasAdminPassword: !!settings.adminPassword,
    };
    return NextResponse.json({ success: true, settings: safeSettings });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Erreur lecture paramètres' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { seoAndAnalytics, announcement, socialLinks, partnerSpace, gemini, adminPassword, siteName, contactEmail } = body;

    const updated = saveSiteSettings({
      ...(siteName ? { siteName } : {}),
      ...(contactEmail ? { contactEmail } : {}),
      ...(seoAndAnalytics ? { seoAndAnalytics } : {}),
      ...(announcement ? { announcement } : {}),
      ...(socialLinks ? { socialLinks } : {}),
      ...(partnerSpace ? { partnerSpace } : {}),
      ...(gemini ? { gemini } : {}),
      ...(adminPassword && adminPassword.trim().length >= 6 ? { adminPassword: adminPassword.trim() } : {}),
    });

    return NextResponse.json({
      success: true,
      message: 'Paramètres enregistrés avec succès',
      settings: {
        ...updated,
        hasAdminPassword: !!updated.adminPassword,
      },
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Erreur mise à jour paramètres' },
      { status: 500 }
    );
  }
}
