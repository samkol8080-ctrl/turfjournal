import { NextRequest, NextResponse } from 'next/server';
import { getMeetingsForDate, getRecentResults, getTodayQuinte } from '@/lib/data-service';
import { RacingApiClient, formatDateToPmu } from '@/lib/racing-api';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const dateParam = searchParams.get('date') || new Date().toISOString().split('T')[0];
    const meetingFilter = searchParams.get('meeting')?.toUpperCase(); // e.g. "R1"
    const quinteOnly = searchParams.get('quinte') === 'true';

    // 1. Si on demande uniquement le Quinté+
    if (quinteOnly) {
      const { race: quinte, isDemo } = await getTodayQuinte(dateParam);
      if (!quinte) {
        return NextResponse.json(
          { success: false, message: 'Aucun Quinté+ trouvé pour cette date' },
          { status: 404 }
        );
      }

      return NextResponse.json({
        success: true,
        date: dateParam,
        isDemo,
        quinte: {
          id: quinte.id,
          meetingCode: quinte.meetingCode,
          meetingName: quinte.meetingName,
          raceNumber: quinte.raceNumber,
          name: quinte.name,
          discipline: quinte.discipline,
          distance: quinte.distance,
          purse: quinte.purse,
          status: quinte.status,
          scheduledAt: quinte.scheduledAt,
          arrivalOrder: quinte.result?.arrivalOrder || null,
          dividends: quinte.result
            ? {
                simpleGagnant: quinte.result.reportSimpleGagnant || null,
                simplePlace: quinte.result.reportSimplePlace || null,
                quinte: quinte.result.reportQuinte || null,
              }
            : null,
          participantsCount: quinte.participants.length,
          topPicks: quinte.prediction?.topPicks.slice(0, 5) || [],
        },
      });
    }

    // 2. Récupération de tous les résultats pour la date spécifiée
    const { meetings, isDemo } = await getMeetingsForDate(dateParam);

    const finishedRaces = [];

    for (const m of meetings) {
      if (meetingFilter && m.code !== meetingFilter) continue;

      for (const r of m.races) {
        if (r.result || r.status === 'FINISHED') {
          finishedRaces.push({
            raceId: r.id,
            slug: r.slug,
            meetingCode: m.code,
            meetingName: m.name,
            hippodrome: m.hippodromeName,
            raceNumber: r.raceNumber,
            name: r.name,
            discipline: r.discipline,
            distance: r.distance,
            purse: r.purse,
            status: r.status,
            scheduledAt: r.scheduledAt,
            isQuinte: r.isQuinte,
            isPick5: r.isPick5,
            arrivalOrder: r.result?.arrivalOrder || null,
            dividends: r.result
              ? {
                  simpleGagnant: r.result.reportSimpleGagnant || null,
                  simplePlace: r.result.reportSimplePlace || null,
                  quinte: r.result.reportQuinte || null,
                }
              : null,
          });
        }
      }
    }

    return NextResponse.json({
      success: true,
      provider: isDemo ? 'Démonstration' : 'API Libre PMU (Turfinfo)',
      date: dateParam,
      totalFinishedRaces: finishedRaces.length,
      filters: {
        meeting: meetingFilter || 'Toutes',
        quinteOnly: false,
      },
      results: finishedRaces,
    });
  } catch (error: any) {
    console.error('Erreur dans /api/results :', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Erreur interne du serveur' },
      { status: 500 }
    );
  }
}
