import { NextRequest, NextResponse } from 'next/server';
import { getMeetingsForDate } from '@/lib/data-service';
import { computeHistoricalAccuracy } from '@/lib/accuracy-tracker';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const dateParam = searchParams.get('date') || new Date().toISOString().split('T')[0];

    const { meetings } = await getMeetingsForDate(dateParam);
    const allRaces = meetings.flatMap((m) => m.races);

    const accuracy = computeHistoricalAccuracy(allRaces);

    return NextResponse.json({
      success: true,
      date: dateParam,
      accuracy,
      disclaimer:
        'Indicateurs statistiques d\'évaluation rétrospective. Les courses hippiques comportent un aléa intrinsèque, aucun gain n\'est garanti.',
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message || 'Erreur lors du calcul de précision' },
      { status: 500 }
    );
  }
}
