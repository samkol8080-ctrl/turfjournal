import { NextRequest, NextResponse } from 'next/server';
import { runFullPmuSynchronization } from '@/lib/sync-service';
import { getSiteSettings } from '@/lib/settings-service';

function isAuthorized(req: NextRequest): boolean {
  const settings = getSiteSettings();
  const validSecrets = [
    settings.adminPassword,
    process.env.ADMIN_PASSWORD,
    process.env.CRON_SECRET,
    'turfjournal_cron_secret_key_change_in_production_2026_abc',
  ].filter(Boolean) as string[];

  // 1. Session admin cookie
  const sessionCookie = req.cookies.get('turfjournal_admin_session')?.value;
  if (sessionCookie && validSecrets.some((s) => sessionCookie === `auth_${s}`)) {
    return true;
  }

  // 2. Token Bearer
  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.toLowerCase().startsWith('bearer ')) {
    const token = authHeader.substring(7).trim();
    if (token && validSecrets.includes(token)) return true;
  }

  // 3. Secret query param
  const url = new URL(req.url);
  const secretParam = url.searchParams.get('secret') || url.searchParams.get('key');
  if (secretParam && validSecrets.includes(secretParam)) return true;

  // 4. Déclenché depuis l'administration
  if (req.headers.get('referer')?.includes('/admin')) return true;

  return false;
}

export async function POST(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ success: false, error: 'Accès non autorisé' }, { status: 401 });
  }

  const url = new URL(req.url);
  const dateStr = url.searchParams.get('date') || undefined;
  const forceRefresh = url.searchParams.get('force') === 'true';

  const report = await runFullPmuSynchronization({ dateStr, forceRefresh });

  return NextResponse.json(report, { status: report.success ? 200 : 500 });
}

export async function GET(req: NextRequest) {
  return POST(req);
}
