﻿'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Cookie, ChevronRight, CheckCircle2, RotateCcw } from 'lucide-react';

export default function PolitiqueCookiesPage() {
  const [currentConsent, setCurrentConsent] = useState<string>('Non défini');

  useEffect(() => {
    const saved = localStorage.getItem('TurfJournal_cookie_consent');
    if (saved === 'accepted') setCurrentConsent('Accepté (Cookies publicitaires et analytiques activés)');
    else if (saved === 'declined') setCurrentConsent('Refusé (Seuls les cookies strictement techniques sont actifs)');
    else setCurrentConsent('En attente de choix');
  }, []);

  const resetConsent = () => {
    localStorage.removeItem('TurfJournal_cookie_consent');
    setCurrentConsent('En attente de choix (Bandeau réactivé)');
    window.location.reload();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-800 font-bold">Cookies</span>
      </nav>

      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center space-x-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
          <Cookie className="w-4 h-4" />
          <span>Gestion des Traceurs</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
          Politique Relative aux Cookies
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
          Explications claires sur l&apos;usage des cookies sur TurfJournal et options de configuration.
        </p>
      </div>

      {/* Interactive Status Card */}
      <div className="card-modern p-6 border border-emerald-200 bg-emerald-50/50 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex flex-wrap items-center gap-2">
          <span>Votre statut de consentement actuel :</span>
          <span className="text-emerald-800 font-semibold font-mono bg-white px-2 py-0.5 rounded border border-emerald-200">{currentConsent}</span>
        </h3>
        <p className="text-xs text-slate-600">
          Vous avez la possibilité de modifier ou réinitialiser votre choix à tout instant.
        </p>
        <button
          onClick={resetConsent}
          className="inline-flex items-center space-x-2 px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-xs font-bold transition-all text-white shadow-xs"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Réinitialiser mes préférences de cookies</span>
        </button>
      </div>

      <div className="card-modern p-6 sm:p-8 space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed border border-slate-200 bg-white">
        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">1. Qu&apos;est-ce qu&apos;un Cookie ?</h2>
          <p>
            Un cookie est un petit fichier texte déposé sur votre terminal (ordinateur, tablette ou smartphone) lors de la visite d&apos;un site internet. Il permet au site de mémoriser vos actions et préférences pour une durée déterminée.
          </p>
        </section>

        <section className="space-y-3 pt-4 border-t border-slate-200">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">2. Typologie des Cookies Utilisés</h2>
          <div className="space-y-3">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <strong className="text-slate-900 block font-bold">Cookies strictement nécessaires (Obligatoires)</strong>
              <span className="text-xs text-slate-600">
                Indispensables pour naviguer sur le site, mémoriser vos préférences d&apos;affichage et vos choix de consentement. Ils ne peuvent pas être désactivés.
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <strong className="text-slate-900 block font-bold">Cookies publicitaires Google AdSense</strong>
              <span className="text-xs text-slate-600">
                Permettent de financer l&apos;accès gratuit à nos contenus d&apos;analyse. Ces traceurs tiers affichent des bannières pertinentes et limitent le nombre d&apos;affichages répétitifs d&apos;une même annonce.
              </span>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

