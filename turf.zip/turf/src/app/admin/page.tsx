'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import {
  DollarSign,
  Trophy,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Trash2,
  PlusCircle,
  ExternalLink,
  Copy,
  RefreshCw,
  Power,
  Globe,
  Database,
  ArrowLeft,
  Calendar,
  Layers,
  Sparkles,
  Lock,
  LogOut,
  BarChart3,
  Search,
  Bell,
  Eye,
  EyeOff,
  ShieldCheck,
  Send,
  Newspaper,
  FileText,
  Code,
  Zap,
  Bot,
} from 'lucide-react';
import Logo from '@/components/common/Logo';
import { AdSenseConfig, AdPlacement, SiteSettings } from '@/lib/settings-service';

export default function AdminDashboardPage() {
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');

  // Active Tab
  const [activeTab, setActiveTab] = useState<'analytics' | 'ads' | 'articles' | 'results' | 'predictions' | 'settings'>('analytics');

  // Articles & Actualités State
  const [articlesList, setArticlesList] = useState<any[]>([]);
  const [articlesLoading, setArticlesLoading] = useState(false);
  const [articleMessage, setArticleMessage] = useState<{ type: 'success' | 'error'; text: string; url?: string } | null>(null);
  const [generatingDaily, setGeneratingDaily] = useState(false);

  // New Article Form
  const [newArticleTitle, setNewArticleTitle] = useState('');
  const [newArticleCategory, setNewArticleCategory] = useState('actualites');
  const [newArticleExcerpt, setNewArticleExcerpt] = useState('');
  const [newArticleContent, setNewArticleContent] = useState('');
  const [newArticleTags, setNewArticleTags] = useState('quinté+, vincennes, pmu, actualités');
  const [publishingArticle, setPublishingArticle] = useState(false);

  // AdSense State
  const [adConfig, setAdConfig] = useState<AdSenseConfig | null>(null);
  const [clientIdInput, setClientIdInput] = useState('');
  const [loadingAds, setLoadingAds] = useState(false);
  const [adsMessage, setAdsMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // New placement form
  const [showAddPlacement, setShowAddPlacement] = useState(false);
  const [newPlacement, setNewPlacement] = useState({
    name: '',
    slotId: '',
    format: 'horizontal' as const,
    location: 'home-custom',
  });

  // Settings State (Analytics, Search Console, General, Security)
  const [settings, setSettings] = useState<any>(null);
  const [loadingSettings, setLoadingSettings] = useState(false);
  const [settingsMessage, setSettingsMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // SEO & Analytics Form Inputs
  const [gscTag, setGscTag] = useState('');
  const [gaId, setGaId] = useState('');
  const [gtmId, setGtmId] = useState('');

  // Announcement Form Inputs
  const [announcementEnabled, setAnnouncementEnabled] = useState(false);
  const [announcementText, setAnnouncementText] = useState('');
  const [announcementLinkText, setAnnouncementLinkText] = useState('');
  const [announcementLinkUrl, setAnnouncementLinkUrl] = useState('');

  // Password change
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Espace Partenaire State
  const [partnerEnabled, setPartnerEnabled] = useState(false);
  const [partnerBannerText, setPartnerBannerText] = useState('');
  const [partnerBannerLink, setPartnerBannerLink] = useState('');
  const [partnerBadgeLabel, setPartnerBadgeLabel] = useState('Espace Partenaire');
  const [savingPartner, setSavingPartner] = useState(false);

  // Gemini AI State
  const [geminiApiKey, setGeminiApiKey] = useState('');
  const [geminiModel, setGeminiModel] = useState('gemini-1.5-flash');
  const [geminiAutoUpdate, setGeminiAutoUpdate] = useState(true);
  const [geminiLoading, setGeminiLoading] = useState(false);
  const [geminiTestStatus, setGeminiTestStatus] = useState<string | null>(null);

  // Cache Clear State
  const [clearingCache, setClearingCache] = useState(false);
  const [cacheMessage, setCacheMessage] = useState<string | null>(null);

  // Results API State
  const [resultsDate, setResultsDate] = useState(new Date().toISOString().split('T')[0]);
  const [meetingFilter, setMeetingFilter] = useState('');
  const [quinteFilter, setQuinteFilter] = useState(false);
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [loadingResults, setLoadingResults] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  // Sync state
  const [syncLoading, setSyncLoading] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  // Ping API
  const [pingLatency, setPingLatency] = useState<number | null>(null);
  const [pingLoading, setPingLoading] = useState(false);

  // Accuracy Tracker State
  const [accuracyData, setAccuracyData] = useState<any>(null);
  const [accuracyLoading, setAccuracyLoading] = useState(false);

  // Music Tester State
  const [testMusic, setTestMusic] = useState('1a 2a 1a (25) 3a Da');
  const [musicScore, setMusicScore] = useState<number | null>(null);

  const loadSiteSettings = useCallback(async () => {
    setLoadingSettings(true);
    try {
      const res = await fetch('/api/backend/settings');
      const data = await res.json();
      if (data.success && data.settings) {
        setSettings(data.settings);
        setGscTag(data.settings.seoAndAnalytics?.googleSearchConsoleTag || '');
        setGaId(data.settings.seoAndAnalytics?.googleAnalyticsId || '');
        setGtmId(data.settings.seoAndAnalytics?.googleTagManagerId || '');
        setAnnouncementEnabled(!!data.settings.announcement?.isEnabled);
        setAnnouncementText(data.settings.announcement?.text || '');
        setAnnouncementLinkText(data.settings.announcement?.linkText || '');
        setAnnouncementLinkUrl(data.settings.announcement?.linkUrl || '');

        // Espace Partenaire
        setPartnerEnabled(!!data.settings.partnerSpace?.isEnabled);
        setPartnerBannerText(data.settings.partnerSpace?.customBannerText || '');
        setPartnerBannerLink(data.settings.partnerSpace?.customBannerLink || '');
        setPartnerBadgeLabel(data.settings.partnerSpace?.badgeLabel || 'Espace Partenaire');

        // Google Gemini AI
        setGeminiApiKey(data.settings.gemini?.apiKey || '');
        setGeminiModel(data.settings.gemini?.model || 'gemini-1.5-flash');
        setGeminiAutoUpdate(data.settings.gemini?.autoUpdateDaily ?? true);
      }
    } catch {
      setSettingsMessage({ type: 'error', text: 'Impossible de charger les paramètres' });
    } finally {
      setLoadingSettings(false);
    }
  }, []);

  const loadAdConfig = useCallback(async () => {
    setLoadingAds(true);
    try {
      const res = await fetch('/api/backend/ads');
      const data = await res.json();
      if (data.success && data.config) {
        setAdConfig(data.config);
        setClientIdInput(data.config.clientId || '');
      }
    } catch {
      setAdsMessage({ type: 'error', text: 'Impossible de charger la configuration AdSense' });
    } finally {
      setLoadingAds(false);
    }
  }, []);

  const loadAccuracy = useCallback(async () => {
    setAccuracyLoading(true);
    try {
      const res = await fetch('/api/predictions/accuracy');
      const data = await res.json();
      if (data.success) {
        setAccuracyData(data.accuracy);
      }
    } catch {} finally {
      setAccuracyLoading(false);
    }
  }, []);

  const loadArticles = useCallback(async () => {
    setArticlesLoading(true);
    try {
      const res = await fetch('/api/articles?all=true');
      const data = await res.json();
      if (data.success && Array.isArray(data.articles)) {
        setArticlesList(data.articles);
      }
    } catch {} finally {
      setArticlesLoading(false);
    }
  }, []);

  const loadAllConfigs = useCallback(() => {
    loadAdConfig();
    loadSiteSettings();
    loadAccuracy();
    loadArticles();
  }, [loadAdConfig, loadSiteSettings, loadAccuracy, loadArticles]);

  // 1. Vérification de l'authentification au chargement
  useEffect(() => {
    fetch('/api/admin/auth')
      .then((res) => res.json())
      .then((data) => {
        setIsAuthenticated(data.authenticated);
        if (data.authenticated) {
          loadAllConfigs();
        }
      })
      .catch(() => {
        setIsAuthenticated(false);
      });
  }, [loadAllConfigs]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError('');

    try {
      const res = await fetch('/api/admin/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: passwordInput }),
      });
      const data = await res.json();

      if (data.success) {
        setIsAuthenticated(true);
        loadAllConfigs();
      } else {
        setAuthError(data.message || 'Mot de passe incorrect');
      }
    } catch {
      setAuthError('Erreur de connexion au serveur');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/admin/auth', { method: 'DELETE' });
    setIsAuthenticated(false);
    setPasswordInput('');
  };

  const handleGenerateDailyNews = async () => {
    setGeneratingDaily(true);
    setArticleMessage(null);
    try {
      const res = await fetch('/api/articles/daily-auto', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setArticleMessage({
          type: 'success',
          text: data.message,
          url: data.url,
        });
        await loadArticles();
      } else {
        setArticleMessage({
          type: 'error',
          text: data.message || 'Erreur lors de la génération automatique',
        });
      }
    } catch {
      setArticleMessage({ type: 'error', text: 'Erreur réseau avec le serveur' });
    } finally {
      setGeneratingDaily(false);
    }
  };

  const handlePublishArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newArticleTitle.trim() || !newArticleContent.trim()) {
      setArticleMessage({ type: 'error', text: 'Le titre et le contenu de l\'article sont obligatoires.' });
      return;
    }
    setPublishingArticle(true);
    setArticleMessage(null);
    try {
      const res = await fetch('/api/articles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newArticleTitle.trim(),
          categorySlug: newArticleCategory,
          excerpt: newArticleExcerpt.trim() || undefined,
          content: newArticleContent.trim(),
          tags: newArticleTags.split(',').map((t) => t.trim()).filter(Boolean),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setArticleMessage({
          type: 'success',
          text: 'Article d\'actualité publié avec succès !',
          url: data.url,
        });
        setNewArticleTitle('');
        setNewArticleExcerpt('');
        setNewArticleContent('');
        await loadArticles();
      } else {
        setArticleMessage({ type: 'error', text: data.message || 'Erreur lors de la publication' });
      }
    } catch {
      setArticleMessage({ type: 'error', text: 'Erreur de connexion au serveur' });
    } finally {
      setPublishingArticle(false);
    }
  };

  const handleDeleteArticle = async (id: string, title: string) => {
    if (!confirm(`Supprimer définitivement l'article "${title}" ?`)) return;
    try {
      const res = await fetch(`/api/articles?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setArticleMessage({ type: 'success', text: 'Article supprimé avec succès.' });
        await loadArticles();
      } else {
        setArticleMessage({ type: 'error', text: data.message || 'Erreur lors de la suppression' });
      }
    } catch {
      setArticleMessage({ type: 'error', text: 'Erreur de communication avec le serveur' });
    }
  };

  const handleClearCache = async () => {
    setClearingCache(true);
    setCacheMessage(null);
    try {
      const res = await fetch('/api/backend/cache', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setCacheMessage(`Cache vidé en ${data.durationMs}ms ! Données ultra-fraîches actives.`);
        setSettingsMessage({
          type: 'success',
          text: `Cache vidé avec succès (${data.durationMs}ms) : Mémoire, PMU et pages Next.js réactualisées !`,
        });
        loadAllConfigs();
      } else {
        setCacheMessage('Erreur lors de la purge du cache');
      }
    } catch {
      setCacheMessage('Erreur de connexion serveur');
    } finally {
      setClearingCache(false);
    }
  };

  const handleSavePartnerSpace = async (enableOverride?: boolean) => {
    setSavingPartner(true);
    const targetState = enableOverride !== undefined ? enableOverride : partnerEnabled;
    try {
      const res = await fetch('/api/backend/partner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          isEnabled: targetState,
          customBannerText: partnerBannerText.trim(),
          customBannerLink: partnerBannerLink.trim(),
          badgeLabel: partnerBadgeLabel.trim() || 'Espace Partenaire',
        }),
      });
      const data = await res.json();
      if (data.success) {
        setPartnerEnabled(targetState);
        setAdsMessage({
          type: 'success',
          text: targetState
            ? 'Espace Partenaire activé sur le site'
            : 'Espace Partenaire désactivé (aucun bloc publicitaire ni placeholder)',
        });
      } else {
        setAdsMessage({ type: 'error', text: data.message || 'Erreur sauvegarde partenaire' });
      }
    } catch {
      setAdsMessage({ type: 'error', text: 'Erreur réseau lors de la mise à jour' });
    } finally {
      setSavingPartner(false);
    }
  };

  const handleTestGemini = async () => {
    setGeminiLoading(true);
    setGeminiTestStatus('Test de connectivité avec Google Gemini...');
    try {
      const res = await fetch('/api/backend/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'test',
          apiKey: geminiApiKey.trim(),
          model: geminiModel,
        }),
      });
      const data = await res.json();
      setGeminiTestStatus(data.message);
    } catch (err: any) {
      setGeminiTestStatus(`Erreur de connexion : ${err.message}`);
    } finally {
      setGeminiLoading(false);
    }
  };

  const handleSaveGemini = async () => {
    setGeminiLoading(true);
    try {
      const res = await fetch('/api/backend/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'save_config',
          apiKey: geminiApiKey.trim(),
          model: geminiModel,
          autoUpdateDaily: geminiAutoUpdate,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setArticleMessage({
          type: 'success',
          text: 'Configuration Gemini AI enregistrée avec succès !',
        });
      } else {
        setArticleMessage({ type: 'error', text: data.message || 'Erreur enregistrement Gemini' });
      }
    } catch {
      setArticleMessage({ type: 'error', text: 'Erreur réseau lors de l’enregistrement de Gemini' });
    } finally {
      setGeminiLoading(false);
    }
  };

  const handleGenerateGeminiDaily = async () => {
    setGeneratingDaily(true);
    setArticleMessage(null);
    try {
      const res = await fetch('/api/backend/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'generate_now' }),
      });
      const data = await res.json();
      if (data.success) {
        setArticleMessage({
          type: 'success',
          text: data.message,
          url: data.url || (data.article?.slug ? `/actualites/${data.article.slug}` : undefined),
        });
        await loadArticles();
      } else {
        setArticleMessage({ type: 'error', text: data.message || 'Erreur lors de la rédaction' });
      }
    } catch {
      setArticleMessage({ type: 'error', text: 'Erreur réseau lors de la rédaction Gemini' });
    } finally {
      setGeneratingDaily(false);
    }
  };

  const handleSaveSeoAndAnalytics = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoadingSettings(true);
    try {
      const res = await fetch('/api/backend/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          seoAndAnalytics: {
            googleSearchConsoleTag: gscTag.trim(),
            googleAnalyticsId: gaId.trim().toUpperCase(),
            googleTagManagerId: gtmId.trim().toUpperCase(),
          },
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSettings(data.settings);
        setSettingsMessage({
          type: 'success',
          text: 'Google Search Console et Google Analytics enregistrés et actifs sur tout le site !',
        });
      }
    } catch {
      setSettingsMessage({ type: 'error', text: 'Erreur lors de la sauvegarde des paramètres' });
    } finally {
      setLoadingSettings(false);
    }
  };

  const handleSaveAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoadingSettings(true);
    try {
      const res = await fetch('/api/backend/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          announcement: {
            isEnabled: announcementEnabled,
            text: announcementText.trim(),
            linkText: announcementLinkText.trim(),
            linkUrl: announcementLinkUrl.trim(),
          },
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSettings(data.settings);
        setSettingsMessage({
          type: 'success',
          text: announcementEnabled
            ? 'Bannière d\'annonce activée sur le site public'
            : 'Bannière d\'annonce désactivée',
        });
      }
    } catch {
      setSettingsMessage({ type: 'error', text: 'Erreur lors de la mise à jour de la bannière' });
    } finally {
      setLoadingSettings(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      setSettingsMessage({ type: 'error', text: 'Le mot de passe doit comporter au moins 6 caractères' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setSettingsMessage({ type: 'error', text: 'Les deux mots de passe ne correspondent pas' });
      return;
    }

    setLoadingSettings(true);
    try {
      const res = await fetch('/api/backend/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminPassword: newPassword }),
      });
      const data = await res.json();
      if (data.success) {
        setNewPassword('');
        setConfirmPassword('');
        setSettingsMessage({ type: 'success', text: 'Mot de passe administrateur modifié avec succès' });
      }
    } catch {
      setSettingsMessage({ type: 'error', text: 'Erreur lors de la modification du mot de passe' });
    } finally {
      setLoadingSettings(false);
    }
  };

  const toggleAdSense = async (enable: boolean) => {
    setLoadingAds(true);
    try {
      const res = await fetch('/api/backend/ads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isEnabled: enable }),
      });
      const data = await res.json();
      if (data.success) {
        setAdConfig(data.config);
        setAdsMessage({
          type: 'success',
          text: enable ? 'Google AdSense activé sur tout le site' : 'Google AdSense désactivé du site',
        });
      }
    } catch {
      setAdsMessage({ type: 'error', text: 'Erreur lors du changement de statut' });
    } finally {
      setLoadingAds(false);
    }
  };

  const handleSaveClientId = async () => {
    setLoadingAds(true);
    try {
      const res = await fetch('/api/backend/ads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clientId: clientIdInput, isEnabled: clientIdInput.trim().length > 0 }),
      });
      const data = await res.json();
      if (data.success) {
        setAdConfig(data.config);
        setAdsMessage({ type: 'success', text: 'Identifiant Client ID AdSense enregistré' });
      }
    } catch {
      setAdsMessage({ type: 'error', text: 'Erreur lors de la mise à jour du Client ID' });
    } finally {
      setLoadingAds(false);
    }
  };

  const handleDeleteAdSense = async () => {
    if (!confirm('Attention : Voulez-vous supprimer définitivement tous les codes AdSense et masquer les annonces ?')) {
      return;
    }
    setLoadingAds(true);
    try {
      const res = await fetch('/api/backend/ads', { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setAdConfig(data.config);
        setClientIdInput('');
        setAdsMessage({ type: 'success', text: 'Google AdSense a été complètement supprimé du site' });
      }
    } catch {
      setAdsMessage({ type: 'error', text: 'Erreur lors de la suppression' });
    } finally {
      setLoadingAds(false);
    }
  };

  const handleAddPlacement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlacement.name || !newPlacement.slotId) return;

    setLoadingAds(true);
    try {
      const res = await fetch('/api/backend/ads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'add_placement', ...newPlacement }),
      });
      const data = await res.json();
      if (data.success) {
        setAdConfig(data.config);
        setShowAddPlacement(false);
        setNewPlacement({ name: '', slotId: '', format: 'horizontal', location: 'home-custom' });
        setAdsMessage({ type: 'success', text: 'Nouvel emplacement publicitaire ajouté avec succès' });
      }
    } catch {
      setAdsMessage({ type: 'error', text: 'Erreur lors de l’ajout du slot' });
    } finally {
      setLoadingAds(false);
    }
  };

  const handleDeletePlacement = async (placementId: string) => {
    try {
      const res = await fetch(`/api/backend/ads?placementId=${placementId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setAdConfig(data.config);
        setAdsMessage({ type: 'success', text: 'Emplacement publicitaire supprimé' });
      }
    } catch {
      setAdsMessage({ type: 'error', text: 'Erreur lors de la suppression du slot' });
    }
  };

  const fetchResultsApi = async () => {
    setLoadingResults(true);
    try {
      let url = `/api/results?date=${resultsDate}`;
      if (meetingFilter) url += `&meeting=${meetingFilter}`;
      if (quinteFilter) url += `&quinte=true`;

      const res = await fetch(url);
      const data = await res.json();
      setApiResponse(data);
    } catch (err: any) {
      setApiResponse({ error: err.message || 'Erreur requête API' });
    } finally {
      setLoadingResults(false);
    }
  };

  const copyApiUrl = () => {
    let url = `${window.location.origin}/api/results?date=${resultsDate}`;
    if (meetingFilter) url += `&meeting=${meetingFilter}`;
    if (quinteFilter) url += `&quinte=true`;
    navigator.clipboard.writeText(url);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleTriggerSync = async () => {
    setSyncLoading(true);
    setSyncStatus('Synchronisation en cours avec l\'API officielle PMU...');
    try {
      const res = await fetch('/api/cron/sync-races', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setSyncStatus(`Synchronisation réussie : ${data.meetingsCount ?? 0} réunions, ${data.racesCount ?? 0} courses, ${data.participantsCount ?? 0} partants, ${data.resultsCount ?? 0} résultats officiels (${data.durationMs ? `${data.durationMs}ms` : 'succès'}).`);
      } else {
        setSyncStatus(`Info synchronisation : ${data.error || data.message || 'Terminé'}`);
      }
    } catch (err: any) {
      setSyncStatus(`Erreur synchronisation : ${err.message || 'Hôte indisponible'}`);
    } finally {
      setSyncLoading(false);
    }
  };

  const handleTestPing = async () => {
    setPingLoading(true);
    const start = Date.now();
    try {
      await fetch('/api/results');
      setPingLatency(Date.now() - start);
    } catch {
      setPingLatency(null);
    } finally {
      setPingLoading(false);
    }
  };

  const calculateMusicScore = () => {
    const tokens = testMusic.replace(/[()]/g, ' ').split(/\s+/).filter(Boolean);
    let pts = 0;
    let weights = 0;
    tokens.slice(0, 5).forEach((token, index) => {
      const weight = Math.max(0.2, 1.0 - index * 0.2);
      weights += weight;
      const upper = token.toUpperCase();
      if (upper.startsWith('1')) pts += 10 * weight;
      else if (upper.startsWith('2')) pts += 8 * weight;
      else if (upper.startsWith('3')) pts += 6 * weight;
      else if (upper.startsWith('4')) pts += 4 * weight;
      else if (upper.startsWith('5')) pts += 2.5 * weight;
      else if (upper.startsWith('D')) pts += 0;
      else pts += 1 * weight;
    });
    const calculated = weights > 0 ? Math.round((pts / (weights * 10)) * 100) : 50;
    setMusicScore(calculated);
  };

  // Écran de chargement initial de l'authentification
  if (isAuthenticated === null) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="flex items-center space-x-3 text-slate-500 font-bold text-sm">
          <RefreshCw className="w-5 h-5 animate-spin text-emerald-700" />
          <span>Vérification de la session administrateur...</span>
        </div>
      </div>
    );
  }

  // ÉCRAN DE VERROUILLAGE / MOT DE PASSE SI NON AUTHENTIFIÉ
  if (!isAuthenticated) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md card-modern p-6 sm:p-8 bg-white border border-slate-200 shadow-xl space-y-6">
          <div className="text-center space-y-3">
            <div className="flex justify-center mb-1">
              <Logo size="md" showTagline={false} />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                TurfJournal Administration
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                Espace privé réservé. Veuillez saisir le mot de passe administrateur pour déverrouiller le panneau.
              </p>
            </div>
          </div>

          {authError && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs font-semibold flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0 text-red-600" />
              <span>{authError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Mot de passe Administrateur
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Entrez votre mot de passe..."
                  className="w-full px-3.5 py-3 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-sm focus:outline-none focus:border-emerald-600 focus:bg-white pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3.5 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={authLoading}
              className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-sm shadow-md transition-all disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              {authLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Vérification...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Déverrouiller l&apos;Administration</span>
                </>
              )}
            </button>
          </form>

          <div className="pt-4 border-t border-slate-100 text-center">
            <Link
              href="/"
              className="text-xs font-bold text-slate-500 hover:text-emerald-700 transition-colors inline-flex items-center space-x-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Retourner au site public</span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // PANNEAU D'ADMINISTRATION COMPLET (AUTHENTIFIÉ)
  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8 py-6 sm:py-10 space-y-6 sm:space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
            <Sliders className="w-4 h-4 text-emerald-700" />
            <span>Panneau d&apos;Administration Central</span>
          </div>
          <h1 className="text-xl sm:text-3xl font-black text-slate-900 flex flex-wrap items-center gap-2">
            <span>TurfJournal.com Manager</span>
            <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-300">
              Session Authentifiée
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Pilotez tout le site sans toucher au code : Google Search Console, Analytics GA4, AdSense, Résultats PMU et sécurité.
          </p>
        </div>

        <div className="flex items-center space-x-2 self-start sm:self-auto">
          <button
            onClick={handleClearCache}
            disabled={clearingCache}
            className="inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold shadow-xs transition-colors cursor-pointer"
            title="Purger le cache et rafraîchir toutes les données"
          >
            <Zap className={`w-3.5 h-3.5 ${clearingCache ? 'animate-spin' : 'text-amber-600'}`} />
            <span>{clearingCache ? 'Vidage...' : 'Vider le cache'}</span>
          </button>

          <Link
            href="/"
            className="inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-white border border-slate-300 hover:border-slate-400 text-slate-700 text-xs font-bold shadow-xs transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Site public</span>
          </Link>
          <button
            onClick={handleLogout}
            className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold transition-colors"
            title="Se déconnecter"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Déconnexion</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 scrollbar-none">
        <button
          onClick={() => setActiveTab('analytics')}
          className={`flex items-center space-x-2 px-3.5 sm:px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer shadow-xs ${
            activeTab === 'analytics'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 hover:text-slate-900 border border-slate-200'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Google Console & Analytics</span>
          {(gscTag || gaId) && <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />}
        </button>

        <button
          onClick={() => setActiveTab('ads')}
          className={`flex items-center space-x-2 px-3.5 sm:px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer shadow-xs ${
            activeTab === 'ads'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 hover:text-slate-900 border border-slate-200'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Espace Partenaire & Publicités</span>
          {(partnerEnabled || adConfig?.isEnabled) && <span className="w-2 h-2 rounded-full bg-emerald-300" />}
        </button>

        <button
          onClick={() => {
            setActiveTab('articles');
            if (articlesList.length === 0) loadArticles();
          }}
          className={`flex items-center space-x-2 px-3.5 sm:px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer shadow-xs ${
            activeTab === 'articles'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 hover:text-slate-900 border border-slate-200'
          }`}
        >
          <Newspaper className="w-4 h-4" />
          <span>Actualités & Rédaction</span>
          {articlesList.length > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-emerald-100 text-emerald-800 font-black">
              {articlesList.length}
            </span>
          )}
        </button>

        <button
          onClick={() => {
            setActiveTab('results');
            if (!apiResponse) fetchResultsApi();
          }}
          className={`flex items-center space-x-2 px-3.5 sm:px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer shadow-xs ${
            activeTab === 'results'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 hover:text-slate-900 border border-slate-200'
          }`}
        >
          <Trophy className="w-4 h-4" />
          <span>API Résultats Hippiques</span>
        </button>

        <button
          onClick={() => setActiveTab('predictions')}
          className={`flex items-center space-x-2 px-3.5 sm:px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer shadow-xs ${
            activeTab === 'predictions'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 hover:text-slate-900 border border-slate-200'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Moteur & Pronostics</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center space-x-2 px-3.5 sm:px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer shadow-xs ${
            activeTab === 'settings'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 hover:text-slate-900 border border-slate-200'
          }`}
        >
          <Globe className="w-4 h-4" />
          <span>Paramètres & Sécurité</span>
        </button>
      </div>

      {/* Notifications Messages */}
      {(settingsMessage || adsMessage || articleMessage) && (
        <div
          className={`p-3.5 sm:p-4 rounded-xl text-xs font-semibold flex items-center justify-between border ${
            (settingsMessage?.type === 'success' || adsMessage?.type === 'success' || articleMessage?.type === 'success')
              ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
              : 'bg-red-50 text-red-900 border-red-200'
          }`}
        >
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>{settingsMessage?.text || adsMessage?.text || articleMessage?.text}</span>
            {articleMessage?.url && (
              <Link
                href={articleMessage.url}
                target="_blank"
                className="inline-flex items-center space-x-1 underline font-black text-emerald-700 hover:text-emerald-900 ml-2"
              >
                <span>Voir l&apos;article en direct</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </Link>
            )}
          </div>
          <button
            onClick={() => {
              setSettingsMessage(null);
              setAdsMessage(null);
              setArticleMessage(null);
            }}
            className="text-slate-400 hover:text-slate-700 font-bold ml-4 p-1"
          >
            ✕
          </button>
        </div>
      )}

      {/* ONGLET 1 : GOOGLE SEARCH CONSOLE & ANALYTICS GA4 */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-6 shadow-xs">
            <div className="border-b border-slate-200 pb-5">
              <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center space-x-2">
                <BarChart3 className="w-5 h-5 text-emerald-700" />
                <span>Configuration Google Search Console & Google Analytics 4</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Configurez le suivi d&apos;audience et la vérification du nom de domaine sans toucher au code.
              </p>
            </div>

            <form onSubmit={handleSaveSeoAndAnalytics} className="space-y-6 text-xs">
              {/* Google Search Console */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <label className="block font-bold text-slate-900 text-sm">
                  1. Google Search Console (Vérification de propriété)
                </label>
                <p className="text-slate-600">
                  Collez le code de validation de votre balise meta HTML fournie par Search Console (la valeur du paramètre <code>content</code>).
                </p>
                <div className="flex flex-col sm:flex-row gap-3 pt-1">
                  <input
                    type="text"
                    value={gscTag}
                    onChange={(e) => setGscTag(e.target.value)}
                    placeholder="ex: abCdEf1234567890_xYz"
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-emerald-600"
                  />
                  {gscTag ? (
                    <span className="inline-flex items-center space-x-1 px-3 py-2 rounded-xl bg-emerald-100 text-emerald-800 font-bold border border-emerald-300 self-start sm:self-auto">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                      <span>Balise active</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center space-x-1 px-3 py-2 rounded-xl bg-slate-100 text-slate-500 font-bold border border-slate-200 self-start sm:self-auto">
                      <span>Non renseigné</span>
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-slate-400 block">
                  Résultat injecté dans &lt;head&gt; : <code>&lt;meta name=&quot;google-site-verification&quot; content=&quot;{gscTag || 'VOTRE_CODE'}&quot; /&gt;</code>
                </span>
              </div>

              {/* Google Analytics 4 */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <label className="block font-bold text-slate-900 text-sm">
                  2. Google Analytics 4 (Measurement ID)
                </label>
                <p className="text-slate-600">
                  Votre identifiant de flux Google Analytics (commence par <strong>G-</strong>).
                </p>
                <div className="flex flex-col sm:flex-row gap-3 pt-1">
                  <input
                    type="text"
                    value={gaId}
                    onChange={(e) => setGaId(e.target.value)}
                    placeholder="ex: G-XXXXXXXXXX"
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-emerald-600"
                  />
                  {gaId ? (
                    <span className="inline-flex items-center space-x-1 px-3 py-2 rounded-xl bg-emerald-100 text-emerald-800 font-bold border border-emerald-300 self-start sm:self-auto">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                      <span>Script GA4 actif</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center space-x-1 px-3 py-2 rounded-xl bg-slate-100 text-slate-500 font-bold border border-slate-200 self-start sm:self-auto">
                      <span>Non renseigné</span>
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-slate-400 block">
                  Permet de suivre le trafic en temps réel, les pages vues et les origines géographiques (France, Maroc, etc.).
                </span>
              </div>

              {/* Google Tag Manager (Optionnel) */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <label className="block font-bold text-slate-900 text-sm">
                  3. Google Tag Manager (Optionnel)
                </label>
                <input
                  type="text"
                  value={gtmId}
                  onChange={(e) => setGtmId(e.target.value)}
                  placeholder="ex: GTM-XXXXXX"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-emerald-600"
                />
              </div>

              <button
                type="submit"
                disabled={loadingSettings}
                className="px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-all disabled:opacity-50 inline-flex items-center space-x-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Enregistrer & Activer Google Console / Analytics</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ONGLET 2 : ADSENSE & ESPACE PARTENAIRE */}
      {activeTab === 'ads' && (
        <div className="space-y-6">
          {/* CARTE : ESPACE PARTENAIRE */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200/90 space-y-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
              <div>
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 mb-2">
                  <Layers className="w-3.5 h-3.5" />
                  <span>Contrôle Espace Partenaire</span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-slate-900">
                  Activer / Désactiver l&apos;Espace Partenaire
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-xl leading-relaxed">
                  Activez ou désactivez en 1 clic l&apos;Espace Partenaire. Lorsqu&apos;il est <strong className="text-slate-800">désactivé</strong>, aucun encart, aucun texte &quot;flex&quot; ni aucun bloc réservé ne s&apos;affiche sur le site public.
                </p>
              </div>

              <div className="flex items-center space-x-3 self-start sm:self-auto">
                {partnerEnabled ? (
                  <button
                    onClick={() => handleSavePartnerSpace(false)}
                    disabled={savingPartner}
                    className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
                  >
                    <Power className="w-4 h-4 text-white" />
                    <span>Activé (Cliquer pour désactiver)</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleSavePartnerSpace(true)}
                    disabled={savingPartner}
                    className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-300 transition-all cursor-pointer"
                  >
                    <Power className="w-4 h-4 text-slate-500" />
                    <span>Désactivé (Cliquer pour activer)</span>
                  </button>
                )}
              </div>
            </div>

            {partnerEnabled && (
              <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50/50 border border-emerald-200 space-y-4 text-xs animate-in fade-in">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Texte de l&apos;offre partenaire (optionnel)
                    </label>
                    <input
                      type="text"
                      value={partnerBannerText}
                      onChange={(e) => setPartnerBannerText(e.target.value)}
                      placeholder="Ex: Jusqu'à 100€ de bonus offerts pour votre premier pari hippique"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 placeholder:text-slate-400 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 shadow-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Lien d&apos;affiliation / redirection partenaire (optionnel)
                    </label>
                    <input
                      type="text"
                      value={partnerBannerLink}
                      onChange={(e) => setPartnerBannerLink(e.target.value)}
                      placeholder="Ex: https://partenaire.com/bonus-turf"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 placeholder:text-slate-400 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 shadow-xs"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    onClick={() => handleSavePartnerSpace()}
                    disabled={savingPartner}
                    className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{savingPartner ? 'Enregistrement...' : 'Enregistrer l\'offre partenaire'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
              <div>
                <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center space-x-2">
                  <DollarSign className="w-5 h-5 text-amber-500" />
                  <span>Gestion Google AdSense</span>
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Activez, ajoutez ou supprimez les codes publicitaires sans toucher au code du site.
                </p>
              </div>

              <div className="flex items-center space-x-3 self-start sm:self-auto">
                <span className="text-xs font-bold text-slate-700">Statut :</span>
                {adConfig?.isEnabled ? (
                  <button
                    onClick={() => toggleAdSense(false)}
                    disabled={loadingAds}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-300 hover:bg-emerald-200 transition-colors"
                  >
                    <Power className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Actif (Cliquer pour désactiver)</span>
                  </button>
                ) : (
                  <button
                    onClick={() => toggleAdSense(true)}
                    disabled={loadingAds}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-xs font-bold border border-slate-300 hover:bg-slate-200 transition-colors"
                  >
                    <Power className="w-3.5 h-3.5 text-slate-400" />
                    <span>Inactif (Cliquer pour activer)</span>
                  </button>
                )}
              </div>
            </div>

            {/* Client ID Configuration Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-1">
              <div className="md:col-span-2 space-y-3">
                <label className="block text-xs font-bold text-slate-800">
                  Identifiant Éditeur AdSense (Client ID)
                </label>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <input
                    type="text"
                    value={clientIdInput}
                    onChange={(e) => setClientIdInput(e.target.value)}
                    placeholder="ex: ca-pub-1234567890123456"
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-mono focus:outline-none focus:border-emerald-600 focus:bg-white"
                  />
                  <button
                    onClick={handleSaveClientId}
                    disabled={loadingAds}
                    className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs disabled:opacity-50"
                  >
                    Enregistrer le Client ID
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Votre identifiant Google AdSense officiel (commençant par &quot;ca-pub-&quot;).
                </p>
              </div>

              {/* Danger Zone: Delete AdSense completely */}
              <div className="p-4 rounded-xl bg-red-50/80 border border-red-200 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-xs font-bold text-red-900 flex items-center space-x-1.5">
                    <Trash2 className="w-3.5 h-3.5 text-red-600" />
                    <span>Supprimer AdSense</span>
                  </h3>
                  <p className="text-[11px] text-red-700 mt-1 leading-relaxed">
                    Désactive immédiatement et supprime tous les codes AdSense de l&apos;ensemble du site public.
                  </p>
                </div>
                <button
                  onClick={handleDeleteAdSense}
                  disabled={loadingAds}
                  className="w-full py-2.5 px-3 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors shadow-xs"
                >
                  Supprimer AdSense du site
                </button>
              </div>
            </div>
          </div>

          {/* Ad Placements List */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
                  <Layers className="w-4 h-4 text-emerald-700" />
                  <span>Emplacements Publicitaires Configurés</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Gérez les blocs publicitaires individuels dans les pages.
                </p>
              </div>

              <button
                onClick={() => setShowAddPlacement(!showAddPlacement)}
                className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors shadow-xs self-start"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>{showAddPlacement ? 'Annuler' : 'Ajouter un Emplacement'}</span>
              </button>
            </div>

            {/* Form to add placement */}
            {showAddPlacement && (
              <form
                onSubmit={handleAddPlacement}
                className="p-5 rounded-xl bg-slate-50 border border-slate-300 space-y-4 text-xs animate-in fade-in"
              >
                <h4 className="font-bold text-slate-900">Nouvel Emplacement Publicitaire</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Nom du slot</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: Milieu d'article"
                      value={newPlacement.name}
                      onChange={(e) => setNewPlacement({ ...newPlacement, name: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-emerald-600"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Slot ID AdSense</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: 9876543210"
                      value={newPlacement.slotId}
                      onChange={(e) => setNewPlacement({ ...newPlacement, slotId: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-emerald-600"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Format</label>
                    <select
                      value={newPlacement.format}
                      onChange={(e: any) => setNewPlacement({ ...newPlacement, format: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-emerald-600"
                    >
                      <option value="horizontal">Horizontal (Bannière)</option>
                      <option value="rectangle">Rectangle (Pavé)</option>
                      <option value="vertical">Vertical (Gratte-ciel)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Identifiant d&apos;emplacement</label>
                    <input
                      type="text"
                      placeholder="ex: article-mid"
                      value={newPlacement.location}
                      onChange={(e) => setNewPlacement({ ...newPlacement, location: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-white border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-emerald-600"
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddPlacement(false)}
                    className="px-4 py-2 rounded-lg bg-slate-200 text-slate-700 font-bold hover:bg-slate-300"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-emerald-700 text-white font-bold hover:bg-emerald-800"
                  >
                    Ajouter l&apos;emplacement
                  </button>
                </div>
              </form>
            )}

            {/* Table of placements */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs min-w-[500px]">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Nom</th>
                    <th className="p-3">Slot ID</th>
                    <th className="p-3">Format</th>
                    <th className="p-3">Position</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {adConfig?.placements.map((p: AdPlacement) => (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3 font-bold text-slate-900">{p.name}</td>
                      <td className="p-3 font-mono text-slate-600">{p.slotId}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-700 border border-slate-200">
                          {p.format}
                        </span>
                      </td>
                      <td className="p-3 font-mono text-slate-500 text-[11px]">{p.location}</td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => handleDeletePlacement(p.id)}
                          className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 hover:text-red-700 transition-colors"
                          title="Supprimer cet emplacement"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {(!adConfig?.placements || adConfig.placements.length === 0) && (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-400">
                        Aucun emplacement configuré. Les annonces ne sont pas affichées sur le site public.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ONGLET : ACTUALITES & REDACTION */}
      {activeTab === 'articles' && (
        <div className="space-y-6">
          {/* CARTE : GOOGLE GEMINI AI POUR LES ACTUALITES QUOTIDIENNES */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-indigo-200/90 space-y-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-indigo-100 pb-5">
              <div className="space-y-1">
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider bg-indigo-50 text-indigo-800 border border-indigo-200 shadow-2xs">
                  <Bot className="w-3.5 h-3.5" />
                  <span>Google Gemini AI — Journalisme Hippique</span>
                </div>
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  Mise à Jour des Actualités Quotidiennes par IA Gemini
                </h2>
                <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
                  L&apos;IA Google Gemini analyse en direct les données du Quinté+ officiel PMU (partants, cotes, musiques, hippodrome, distance) et rédige un article journalistique complet avec analyse tactique et pronostics.
                </p>
              </div>

              <button
                onClick={handleGenerateGeminiDaily}
                disabled={generatingDaily}
                className="inline-flex items-center justify-center space-x-2 px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-all shadow-xs active:scale-95 disabled:opacity-50 whitespace-nowrap self-start sm:self-auto cursor-pointer"
              >
                {generatingDaily ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Rédaction Gemini en cours...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>✨ Rédiger l&apos;Actualité avec Gemini AI</span>
                  </>
                )}
              </button>
            </div>

            {/* Configuration Clé API Gemini */}
            <div className="p-4 sm:p-5 rounded-2xl bg-indigo-50/40 border border-indigo-200/80 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-bold mb-1">
                    Clé API Google Gemini (GEMINI_API_KEY)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="password"
                      value={geminiApiKey}
                      onChange={(e) => setGeminiApiKey(e.target.value)}
                      placeholder="AIzaSy..."
                      className="flex-1 px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 shadow-xs"
                    />
                    <button
                      type="button"
                      onClick={handleSaveGemini}
                      disabled={geminiLoading}
                      className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold transition-colors cursor-pointer shadow-xs"
                    >
                      Enregistrer
                    </button>
                  </div>
                  <span className="text-[11px] text-slate-500 mt-1.5 block">
                    Obtenez une clé gratuite en 30 secondes sur <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-indigo-600 font-semibold underline hover:text-indigo-800">Google AI Studio</a>.
                  </span>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Modèle d&apos;IA</label>
                  <select
                    value={geminiModel}
                    onChange={(e) => setGeminiModel(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 shadow-xs"
                  >
                    <option value="gemini-1.5-flash">Gemini 1.5 Flash (Rapide & Gratuit)</option>
                    <option value="gemini-2.0-flash">Gemini 2.0 Flash (Nouvelle Génération)</option>
                    <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-indigo-200/60">
                <button
                  type="button"
                  onClick={handleTestGemini}
                  disabled={geminiLoading}
                  className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 font-bold transition-colors shadow-xs cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${geminiLoading ? 'animate-spin' : ''}`} />
                  <span>Tester la connexion API Gemini</span>
                </button>

                {geminiTestStatus && (
                  <span className="text-xs font-mono text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                    {geminiTestStatus}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* 1. Carte Génération Automatique Quotidienne Déterministe */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-emerald-200/90 space-y-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-2xs">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Automatisation Quotidienne PMU</span>
                </div>
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  Générer l&apos;Actualité Quinté+ du Jour en 1 Clic
                </h2>
                <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
                  Interroge l&apos;API officielle PMU, analyse l&apos;hippodrome, les partants, les favoris et leurs musiques pour rédiger et publier instantanément un article d&apos;actualité journalistique complet.
                </p>
              </div>

              <button
                onClick={handleGenerateDailyNews}
                disabled={generatingDaily}
                className="inline-flex items-center justify-center space-x-2 px-5 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs transition-all shadow-xs active:scale-95 disabled:opacity-50 whitespace-nowrap self-start sm:self-auto cursor-pointer"
              >
                {generatingDaily ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>Rédaction en cours...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>✨ Rédiger & Publier l&apos;Actualité du Jour</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 2. Formulaire de Rédaction Manuelle */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-6 shadow-xs">
            <div className="border-b border-slate-200 pb-4">
              <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center space-x-2">
                <FileText className="w-5 h-5 text-emerald-700" />
                <span>Rédiger une Nouvelle Actualité Hippique</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Rédigez et publiez immédiatement un article visible par tous les visiteurs et indexé par Google.
              </p>
            </div>

            <form onSubmit={handlePublishArticle} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-bold mb-1">
                    Titre de l&apos;actualité <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newArticleTitle}
                    onChange={(e) => setNewArticleTitle(e.target.value)}
                    placeholder="Ex: Quinté+ du jour : Les clés pour déchiffrer l'épreuve à Vincennes"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Catégorie</label>
                  <select
                    value={newArticleCategory}
                    onChange={(e) => setNewArticleCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                  >
                    <option value="actualites">Actualités Hippiques</option>
                    <option value="quinte">Quinté+ & Grands Prix</option>
                    <option value="guides">Guides & Stratégies</option>
                    <option value="interviews">Interviews & Débriefings</option>
                    <option value="jeu-responsable">Jeu Responsable</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Chapeau / Résumé introductif (affiché dans le flux et sur Google)
                </label>
                <input
                  type="text"
                  value={newArticleExcerpt}
                  onChange={(e) => setNewArticleExcerpt(e.target.value)}
                  placeholder="Court résumé de 1 à 2 phrases pour capter le lecteur..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Contenu complet de l&apos;article <span className="text-red-500">*</span>
                </label>
                <p className="text-[11px] text-slate-400 mb-2">
                  Conseil : Utilisez `### Titre de section`, `- Liste à puces`, et `**Gras**` pour aérer la lecture.
                </p>
                <textarea
                  rows={8}
                  required
                  value={newArticleContent}
                  onChange={(e) => setNewArticleContent(e.target.value)}
                  placeholder={`Le grand rendez-vous hippique du jour nous donne rendez-vous sur la piste cendrée...\n\n### 1. Les forces en présence\nLe peloton réunit plusieurs champions particulièrement affûtés.\n\n### 2. Notre sélection\n- N°4 : Vainqueur potentiel\n- N°7 : Bel outsider`}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900 font-mono text-xs leading-relaxed"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Mots-clés / Tags</label>
                <input
                  type="text"
                  value={newArticleTags}
                  onChange={(e) => setNewArticleTags(e.target.value)}
                  placeholder="quinté+, trot, vincennes, favoris"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={publishingArticle}
                  className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs transition-colors shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  {publishingArticle ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Publication en cours...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Publier l&apos;article sur le site</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* 3. Liste des Articles Publiés */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center space-x-2">
                  <Newspaper className="w-5 h-5 text-emerald-700" />
                  <span>Articles & Actualités en Ligne ({articlesList.length})</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Liste des actualités publiées sur TurfJournal.com.
                </p>
              </div>

              <button
                onClick={loadArticles}
                disabled={articlesLoading}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors self-start cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${articlesLoading ? 'animate-spin' : ''}`} />
                <span>Actualiser la liste</span>
              </button>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs min-w-[600px]">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Titre de l&apos;article</th>
                    <th className="p-3">Catégorie</th>
                    <th className="p-3">Date</th>
                    <th className="p-3">Statut</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {articlesList.map((article: any) => {
                    const articleUrl = article.categorySlug === 'guides' ? `/guides/${article.slug}` : `/actualites/${article.slug}`;
                    return (
                      <tr key={article.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3 font-bold text-slate-900 max-w-xs truncate" title={article.title}>
                          {article.title}
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-50 text-emerald-800 border border-emerald-200">
                            {article.categoryName || article.categorySlug}
                          </span>
                        </td>
                        <td className="p-3 text-slate-500 whitespace-nowrap">
                          {new Date(article.publishedAt).toLocaleDateString('fr-FR')}
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            En ligne
                          </span>
                        </td>
                        <td className="p-3 text-right space-x-2 whitespace-nowrap">
                          <Link
                            href={articleUrl}
                            target="_blank"
                            className="inline-flex items-center space-x-1 p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-50 font-bold transition-colors"
                            title="Voir sur le site public"
                          >
                            <span>Voir</span>
                            <ExternalLink className="w-3.5 h-3.5" />
                          </Link>
                          <button
                            onClick={() => handleDeleteArticle(article.id, article.title)}
                            className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 hover:text-red-700 transition-colors"
                            title="Supprimer cet article"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {articlesList.length === 0 && (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-400">
                        {articlesLoading ? 'Chargement des articles...' : 'Aucun article rédigé.'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* 4. Documentation API & Automatisation Quotidienne */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200/90 rounded-2xl space-y-5 shadow-xs">
            <div className="border-b border-slate-100 pb-4">
              <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider bg-slate-100 text-slate-800 border border-slate-200 mb-2">
                <Code className="w-3.5 h-3.5" />
                <span>Développeurs & Webhooks</span>
              </div>
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                Documentation API : Comment écrire les actualités chaque jour
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Utilisez ces endpoints REST pour publier vos actualités automatiquement chaque jour via Python, cURL, Zapier ou vos propres scripts d&apos;automatisation.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {/* Endpoint 1 : Publication d'un article */}
              <div className="p-4 rounded-xl bg-slate-950 text-slate-200 border border-slate-800 space-y-3 font-mono shadow-xs">
                <div className="flex items-center justify-between text-[11px] font-sans border-b border-slate-800 pb-2">
                  <span className="font-bold text-emerald-400">POST /api/articles</span>
                  <span className="text-slate-400">Création personnalisée</span>
                </div>
                <div className="text-[11px] text-emerald-300 bg-black/40 p-3 rounded-lg overflow-x-auto">
                  <pre className="text-slate-300">
{`curl -X POST https://turfjournal.com/api/articles \\
  -H "Authorization: Bearer VOTRE_MOT_DE_PASSE" \\
  -H "Content-Type: application/json" \\
  -d '{
    "title": "Titre de votre actualité du jour",
    "categorySlug": "actualites",
    "excerpt": "Résumé introductif...",
    "content": "### Titre 1\\nContenu détaillé...",
    "tags": ["quinté", "trot", "pmu"]
  }'`}
                  </pre>
                </div>
                <p className="text-[11px] font-sans text-slate-400">
                  Authentification par en-tête `Authorization: Bearer &lt;mot_de_passe_admin&gt;` ou `X-API-KEY`.
                </p>
              </div>

              {/* Endpoint 2 : Déclencheur Quinté+ Automatique Quotidien */}
              <div className="p-4 rounded-xl bg-slate-950 text-slate-200 border border-slate-800 space-y-3 font-mono shadow-xs">
                <div className="flex items-center justify-between text-[11px] font-sans border-b border-slate-800 pb-2">
                  <span className="font-bold text-amber-400">POST /api/articles/daily-auto</span>
                  <span className="text-slate-400">Génération Quinté+ auto</span>
                </div>
                <div className="text-[11px] text-amber-300 bg-black/40 p-3 rounded-lg overflow-x-auto">
                  <pre className="text-slate-300">
{`# Appel Cron quotidien chaque matin :
curl -X POST \\
  "https://turfjournal.com/api/articles/daily-auto?key=VOTRE_MOT_DE_PASSE"

# En Python :
import requests
requests.post(
  "https://turfjournal.com/api/articles/daily-auto",
  headers={"Authorization": "Bearer VOTRE_MOT_DE_PASSE"}
)`}
                  </pre>
                </div>
                <p className="text-[11px] font-sans text-slate-400">
                  Déclenchable facilement par un service Cron (Vercel Cron, GitHub Actions, crontab Linux) chaque matin.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ONGLET 3 : RESULTATS API */}
      {activeTab === 'results' && (
        <div className="space-y-6">
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-6 shadow-xs">
            <div className="border-b border-slate-200 pb-5">
              <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-emerald-700" />
                <span>API des Résultats des Courses Hippiques (`/api/results`)</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Point de terminaison REST retournant les résultats réels, arrivées officielles et rapports PMU.
              </p>
            </div>

            {/* Query Filters */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Date d&apos;analyse</label>
                <input
                  type="date"
                  value={resultsDate}
                  onChange={(e) => setResultsDate(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-medium focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Filtrer par Réunion</label>
                <select
                  value={meetingFilter}
                  onChange={(e) => setMeetingFilter(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-medium focus:outline-none focus:border-emerald-600"
                >
                  <option value="">Toutes les Réunions</option>
                  <option value="R1">R1</option>
                  <option value="R2">R2</option>
                  <option value="R3">R3</option>
                  <option value="R4">R4</option>
                  <option value="R5">R5</option>
                  <option value="R6">R6</option>
                </select>
              </div>

              <div className="flex items-center space-x-3 pt-4 sm:pt-6">
                <label className="flex items-center space-x-2 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={quinteFilter}
                    onChange={(e) => setQuinteFilter(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                  />
                  <span>Quinté+ uniquement</span>
                </label>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                onClick={fetchResultsApi}
                disabled={loadingResults}
                className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingResults ? 'animate-spin' : ''}`} />
                <span>Interroger l&apos;API Résultats</span>
              </button>

              <button
                onClick={copyApiUrl}
                className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-white border border-slate-300 hover:border-slate-400 text-slate-700 text-xs font-bold transition-colors shadow-xs"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copiedUrl ? 'Lien copié !' : 'Copier l\'URL API'}</span>
              </button>

              <Link
                href={`/api/results?date=${resultsDate}${meetingFilter ? `&meeting=${meetingFilter}` : ''}${quinteFilter ? '&quinte=true' : ''}`}
                target="_blank"
                className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors"
              >
                <span>Ouvrir JSON brut</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </Link>
            </div>

            {/* Live API Response Preview */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                <span>Aperçu de la réponse JSON :</span>
                {apiResponse && (
                  <span className="text-emerald-700 font-mono">
                    {apiResponse.totalFinishedRaces ?? (apiResponse.quinte ? 1 : 0)} résultat(s)
                  </span>
                )}
              </div>
              <pre className="p-4 rounded-xl bg-slate-900 text-emerald-400 text-[11px] sm:text-xs font-mono max-h-96 overflow-y-auto leading-relaxed border border-slate-800">
                {loadingResults
                  ? 'Chargement des résultats...'
                  : apiResponse
                  ? JSON.stringify(apiResponse, null, 2)
                  : 'Cliquez sur "Interroger l\'API Résultats" pour visualiser les données en direct.'}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* ONGLET 4 : PRONOSTICS & AUDIT DE PRECISION */}
      {activeTab === 'predictions' && (
        <div className="space-y-6">
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-6 shadow-xs">
            <div className="border-b border-slate-200 pb-5">
              <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-amber-500" />
                <span>Audit & Moteur Algorithmique TurfJournal</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Suivi de la précision rétrospective et étalonnage des coefficients d&apos;analyse.
              </p>
            </div>

            {/* Historical Prediction Accuracy Audit */}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-black text-slate-900 flex items-center space-x-2">
                    <Trophy className="w-4 h-4 text-emerald-700" />
                    <span>Audit Rétrospectif de Précision des Pronostics</span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Confrontation automatique des sélections de l&apos;algorithme aux arrivées officielles PMU.
                  </p>
                </div>
                <button
                  onClick={loadAccuracy}
                  disabled={accuracyLoading}
                  className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors self-start sm:self-auto"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${accuracyLoading ? 'animate-spin' : ''}`} />
                  <span>Actualiser l&apos;audit</span>
                </button>
              </div>

              {accuracyData && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                      <span className="text-[10px] uppercase font-bold text-emerald-800 block">Favori Placé (Top 3)</span>
                      <span className="text-xl font-black text-emerald-800 font-mono">{accuracyData.top1PlaceRate}%</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                      <span className="text-[10px] uppercase font-bold text-slate-600 block">Favori Gagnant (1er)</span>
                      <span className="text-xl font-black text-slate-900 font-mono">{accuracyData.top1WinRate}%</span>
                    </div>
                    <div className="p-3 rounded-xl bg-teal-50 border border-teal-200">
                      <span className="text-[10px] uppercase font-bold text-teal-800 block">Top 3 Placé (≥2)</span>
                      <span className="text-xl font-black text-teal-800 font-mono">{accuracyData.top3PlaceRate}%</span>
                    </div>
                    <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
                      <span className="text-[10px] uppercase font-bold text-amber-800 block">Quinté Réussi (≥3)</span>
                      <span className="text-xl font-black text-amber-700 font-mono">{accuracyData.top5QuinteRate}%</span>
                    </div>
                  </div>

                  {/* Recent Evaluations Table */}
                  <div className="overflow-x-auto border border-slate-200 rounded-xl">
                    <table className="w-full text-left text-xs min-w-[550px]">
                      <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                        <tr>
                          <th className="p-2.5">Course</th>
                          <th className="p-2.5">Cheval Sélectionné</th>
                          <th className="p-2.5">Score Moteur</th>
                          <th className="p-2.5">Arrivée Officielle</th>
                          <th className="p-2.5 text-right">Résultat</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {accuracyData.recentEvaluations?.map((ev: any, idx: number) => (
                          <tr key={idx} className="hover:bg-slate-50">
                            <td className="p-2.5 font-bold text-slate-900">
                              {ev.meetingCode} C{ev.raceNumber} - {ev.raceName}
                            </td>
                            <td className="p-2.5">
                              <span className="font-mono font-bold text-emerald-800">#{ev.topPickNumber}</span>{' '}
                              <span className="font-bold text-slate-900">{ev.topPickHorse}</span>
                            </td>
                            <td className="p-2.5 font-mono text-slate-600 font-bold">{ev.score}/100</td>
                            <td className="p-2.5 font-mono text-slate-700">
                              {ev.officialArrival?.join(' - ') || '-'}
                            </td>
                            <td className="p-2.5 text-right">
                              {ev.wasWinner ? (
                                <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                                  GAGNANT (1er)
                                </span>
                              ) : ev.wasPlaced ? (
                                <span className="px-2 py-0.5 rounded text-[10px] font-black bg-blue-100 text-blue-800 border border-blue-300">
                                  PLACÉ ({ev.topPickPosition}e)
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                                  {ev.topPickPosition ? `${ev.topPickPosition}e` : 'Non placé'}
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* Music Tester */}
            <div className="pt-6 border-t border-slate-200 space-y-3 text-xs">
              <label className="block text-slate-700 font-bold">
                Tester l&apos;Analyseur de Musique Hippique
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={testMusic}
                  onChange={(e) => setTestMusic(e.target.value)}
                  placeholder="ex: 1a 2a 1a (25) Da"
                  className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 font-mono text-slate-900 focus:outline-none focus:border-emerald-600"
                />
                <button
                  onClick={calculateMusicScore}
                  className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold transition-all shadow-xs"
                >
                  Calculer
                </button>
              </div>
              {musicScore !== null && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                  <span className="font-bold text-emerald-900">Note calculée : {musicScore} / 100</span>
                  <span className="text-[11px] font-bold px-2.5 py-1 rounded bg-emerald-700 text-white">
                    {musicScore >= 75 ? 'Excellente forme' : musicScore >= 50 ? 'Forme régulière' : 'Forme incertaine'}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ONGLET 5 : PARAMETRES, ANNONCES & MOT DE PASSE */}
      {activeTab === 'settings' && (
        <div className="space-y-6">
          {/* Purge & Optimisation du Cache */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-amber-200/90 space-y-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-100 pb-4">
              <div>
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider bg-amber-50 text-amber-900 border border-amber-200 mb-2">
                  <Zap className="w-3.5 h-3.5 text-amber-600" />
                  <span>Vitesse & Cache Instantané</span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-slate-900">
                  Vider tout le Cache du Site (Mobile & Laptop)
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-xl leading-relaxed">
                  Purger immédiatement la mémoire cache de l&apos;API PMU, les paramètres, les articles et revalider toutes les pages Next.js pour garantir une vitesse maximale et des données fraîches.
                </p>
              </div>

              <button
                onClick={handleClearCache}
                disabled={clearingCache}
                className="inline-flex items-center space-x-2 px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs transition-all shadow-xs active:scale-95 disabled:opacity-50 whitespace-nowrap self-start sm:self-auto cursor-pointer"
              >
                <Zap className={`w-4 h-4 ${clearingCache ? 'animate-spin' : ''}`} />
                <span>{clearingCache ? 'Purge en cours...' : '⚡ Vider le cache maintenant'}</span>
              </button>
            </div>

            {cacheMessage && (
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-mono">
                {cacheMessage}
              </div>
            )}
          </div>

          {/* Dynamic Announcement Banner Setting */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-5 shadow-xs">
            <div className="border-b border-slate-200 pb-4">
              <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center space-x-2">
                <Bell className="w-5 h-5 text-amber-500" />
                <span>Bannière d&apos;Annonce en Haut de Page</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Affichez un message important ou promotionnel visible sur toutes les pages du site public.
              </p>
            </div>

            <form onSubmit={handleSaveAnnouncement} className="space-y-4 text-xs">
              <div className="flex items-center space-x-3">
                <label className="flex items-center space-x-2 cursor-pointer font-bold text-slate-800">
                  <input
                    type="checkbox"
                    checked={announcementEnabled}
                    onChange={(e) => setAnnouncementEnabled(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                  />
                  <span>Activer la bannière d&apos;annonce sur le site</span>
                </label>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Texte de l&apos;annonce</label>
                <input
                  type="text"
                  value={announcementText}
                  onChange={(e) => setAnnouncementText(e.target.value)}
                  placeholder="ex: Grande course Quinté+ à Vincennes : découvrez notre sélection exclusive !"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Texte du bouton / lien (optionnel)</label>
                  <input
                    type="text"
                    value={announcementLinkText}
                    onChange={(e) => setAnnouncementLinkText(e.target.value)}
                    placeholder="ex: Voir le Quinté"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Lien de destination (URL)</label>
                  <input
                    type="text"
                    value={announcementLinkUrl}
                    onChange={(e) => setAnnouncementLinkUrl(e.target.value)}
                    placeholder="ex: /pronostics ou https://..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loadingSettings}
                className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs transition-all"
              >
                Enregistrer la Bannière
              </button>
            </form>
          </div>

          {/* Change Admin Password */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-5 shadow-xs">
            <div className="border-b border-slate-200 pb-4">
              <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center space-x-2">
                <Lock className="w-5 h-5 text-emerald-700" />
                <span>Sécurité : Modifier le Mot de Passe Administrateur</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Modifiez le mot de passe requis pour accéder à ce panneau.
              </p>
            </div>

            <form onSubmit={handleChangePassword} className="space-y-4 text-xs max-w-lg">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Nouveau mot de passe (min. 6 caractères)</label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Confirmer le nouveau mot de passe</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <button
                type="submit"
                disabled={loadingSettings}
                className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition-all"
              >
                Modifier le Mot de Passe
              </button>
            </form>
          </div>

          {/* System Flux & Sync */}
          <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200 space-y-4 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
              <Database className="w-4 h-4 text-emerald-700" />
              <span>Flux PMU & Synchronisation</span>
            </h3>
            <p className="text-xs text-slate-600">
              Flux configuré : <code>https://offline.turfinfo.api.pmu.fr/rest/client/7/programme</code>
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={handleTestPing}
                disabled={pingLoading}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all border border-slate-300"
              >
                {pingLoading ? 'Ping en cours...' : 'Tester la Latence API'}
              </button>

              <button
                onClick={handleTriggerSync}
                disabled={syncLoading}
                className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs inline-flex items-center space-x-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncLoading ? 'animate-spin' : ''}`} />
                <span>Forcer la Synchronisation PMU</span>
              </button>

              {pingLatency !== null && (
                <span className="text-xs text-emerald-800 font-bold bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                  Connecté • Latence : {pingLatency} ms
                </span>
              )}
            </div>

            {syncStatus && (
              <div className="p-3 rounded-xl bg-slate-100 text-slate-800 font-medium text-xs border border-slate-200">
                {syncStatus}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
