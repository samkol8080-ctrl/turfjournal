import React from 'react';
import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ChevronRight } from 'lucide-react';
import { getJockeyProfile } from '@/lib/data-service';
import AdBanner from '@/components/ads/AdBanner';

interface JockeyPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: JockeyPageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const jockey = await getJockeyProfile(resolvedParams.id);

  if (!jockey) {
    return {
      title: 'Jockey non trouvé | TurfJournal',
      description: 'Fiche jockey non trouvée dans les données officielles PMU.',
    };
  }

  return {
    title: `${jockey.name} : Statistiques, Victoires & Palmarès | TurfJournal`,
    description: `Fiche jockey/driver de ${jockey.name} : ${jockey.wins} victoires, taux de réussite ${jockey.winRate}%, partants du jour.`,
    alternates: {
      canonical: `/jockeys/${jockey.id}`,
    },
  };
}

export default async function JockeyDetailPage({ params }: JockeyPageProps) {
  const resolvedParams = await params;
  const jockey = await getJockeyProfile(resolvedParams.id);

  if (!jockey) {
    notFound();
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span>Jockeys & Drivers</span>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-700 font-bold">{jockey.name}</span>
      </nav>

      <div className="card-modern p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <span className="text-xs uppercase font-bold text-emerald-700 tracking-wider block mb-1">
              Fiche Professionnelle Jockey / Driver
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900">{jockey.name}</h1>
            <p className="text-xs text-slate-500 mt-1">
              Pilote professionnel en activité sur les principaux hippodromes français et internationaux.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-center min-w-[100px]">
              <span className="text-[10px] text-emerald-800 uppercase font-bold block">Taux Victoire</span>
              <strong className="text-xl font-black text-emerald-800 font-mono">{jockey.winRate}%</strong>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Victoires totales</span>
            <span className="text-xl font-black text-slate-900 font-mono">{jockey.wins}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Places d&apos;honneur</span>
            <span className="text-xl font-black text-slate-900 font-mono">{jockey.places}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Montes disputées</span>
            <span className="text-xl font-black text-slate-700 font-mono">{jockey.rides}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Réussite dans les 3</span>
            <span className="text-xl font-black text-emerald-700 font-mono">
              {(((jockey.wins + jockey.places) / jockey.rides) * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      <AdBanner format="horizontal" slotId="jockey-bottom" />
    </div>
  );
}

