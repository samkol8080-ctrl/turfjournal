﻿import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { BookOpen, ArrowRight } from 'lucide-react';
import { getArticles } from '@/lib/data-service';
import AdBanner from '@/components/ads/AdBanner';

export const metadata: Metadata = {
  title: 'Guides & Stratégies Turf pour Débutants et Initiés | TurfJournal',
  description:
    'Apprenez à parier intelligemment : décrypter la musique, comprendre le Quinté+, analyser le déferrage et gérer votre budget avec méthode.',
  alternates: {
    canonical: '/guides',
  },
};

export default async function GuidesPage() {
  const articles = await getArticles('guides');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center space-x-2 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
          <BookOpen className="w-4 h-4" />
          <span>Formation & Méthodologie Hippique</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
          Guides Turf & Stratégies d&apos;Analyse
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl leading-relaxed">
          Des tutoriels clairs et documentés pour acquérir une véritable autonomie d&apos;analyse face aux programmes de courses et optimiser vos sélections de chevaux.
        </p>
      </div>

      <AdBanner format="horizontal" slotId="guides-top" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((guide) => (
          <div key={guide.id} className="card-modern p-6 sm:p-8 flex flex-col justify-between group">
            <div>
              <span className="inline-block px-2.5 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 mb-4">
                Dossier Méthodologie
              </span>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 group-hover:text-emerald-700 transition-colors mb-3 leading-snug">
                <Link href={`/guides/${guide.slug}`}>{guide.title}</Link>
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 line-clamp-3 leading-relaxed mb-6">
                {guide.excerpt}
              </p>
            </div>

            <Link
              href={`/guides/${guide.slug}`}
              className="inline-flex items-center space-x-2 text-xs font-bold text-emerald-700 hover:text-emerald-800 transition-colors pt-4 border-t border-slate-100"
            >
              <span>Consulter le guide pédagogique</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        ))}
      </div>

      <AdBanner format="horizontal" slotId="guides-bottom" />
    </div>
  );
}

