﻿import React from 'react';
import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ChevronRight, Calendar, User, ArrowLeft, BookOpen, ShieldAlert } from 'lucide-react';
import { getArticleBySlug } from '@/lib/data-service';
import AdBanner from '@/components/ads/AdBanner';

interface GuidePageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: GuidePageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const article = await getArticleBySlug(resolvedParams.slug);

  if (!article) {
    return { title: 'Guide non trouvé | TurfJournal' };
  }

  return {
    title: `${article.title} | Guide TurfJournal`,
    description: article.metaDescription || article.excerpt,
    alternates: {
      canonical: `/guides/${article.slug}`,
    },
  };
}

export default async function GuideDetailPage({ params }: GuidePageProps) {
  const resolvedParams = await params;
  const article = await getArticleBySlug(resolvedParams.slug);

  if (!article) {
    notFound();
  }

  const guideJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: article.title,
    description: article.excerpt,
    datePublished: article.publishedAt,
    author: {
      '@type': 'Organization',
      name: 'TurfJournal Rédaction',
    },
    publisher: {
      '@type': 'Organization',
      name: 'TurfJournal',
    },
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(guideJsonLd) }}
      />

      <nav aria-label="Fil d'Ariane" className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
        <Link href="/" className="hover:text-emerald-700 transition-colors">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <Link href="/guides" className="hover:text-emerald-700 transition-colors">Guides</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-emerald-800 font-semibold truncate max-w-xs">{article.title}</span>
      </nav>

      <article className="card-modern p-6 sm:p-10 border border-slate-200 bg-white">
        <header className="border-b border-slate-200 pb-6 mb-8">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 mb-4">
            Guide Pédagogique
          </span>
          <h1 className="text-2xl sm:text-4xl font-black text-slate-900 leading-tight mb-4">
            {article.title}
          </h1>

          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
            <span className="flex items-center space-x-1.5 font-medium">
              <User className="w-4 h-4 text-emerald-700" />
              <span>Rédaction TurfJournal</span>
            </span>
            <span>•</span>
            <span className="flex items-center space-x-1.5">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Mis à jour le {new Date(article.publishedAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
            </span>
          </div>
        </header>

        <p className="text-base sm:text-lg text-slate-700 leading-relaxed font-medium mb-8 bg-slate-50 p-5 rounded-xl border border-slate-200">
          {article.excerpt}
        </p>

        <AdBanner format="rectangle" slotId="in-guide-1" className="my-8" />

        <div className="prose max-w-none text-slate-700 text-sm sm:text-base leading-relaxed space-y-6">
          {article.content.split('\n\n').map((paragraph, index) => {
            if (paragraph.startsWith('### ')) {
              return (
                <h3 key={index} className="text-lg sm:text-xl font-bold text-slate-900 pt-4 border-t border-slate-200">
                  {paragraph.replace('### ', '')}
                </h3>
              );
            }
            if (paragraph.startsWith('- ')) {
              const items = paragraph.split('\n- ');
              return (
                <ul key={index} className="list-disc list-inside space-y-2 text-slate-700">
                  {items.map((it, idx) => (
                    <li key={idx}>{it.replace(/^- /, '')}</li>
                  ))}
                </ul>
              );
            }
            return <p key={index}>{paragraph}</p>;
          })}
        </div>

        {article.tags && (
          <div className="mt-10 pt-6 border-t border-slate-200 flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Thématiques :</span>
            {article.tags.map((tag) => (
              <span key={tag} className="px-2.5 py-1 rounded bg-slate-100 text-slate-700 text-xs border border-slate-200 font-medium">
                #{tag}
              </span>
            ))}
          </div>
        )}
      </article>

      <AdBanner format="horizontal" slotId="guide-bottom" />
    </div>
  );
}

