export type DisciplineType =
  | 'TROT_ATTELE'
  | 'TROT_MONTE'
  | 'PLAT'
  | 'OBSTACLE_HAIES'
  | 'STEEPLE_CHASE'
  | 'CROSS_COUNTRY';

export type RaceStatusType = 'SCHEDULED' | 'RUNNING' | 'FINISHED' | 'CANCELLED';

export type ParticipantStatusType = 'RUNNER' | 'NON_RUNNER' | 'DISQUALIFIED';

export interface JockeyData {
  id: string;
  name: string;
  wins: number;
  places: number;
  rides: number;
  winRate: number;
}

export interface TrainerData {
  id: string;
  name: string;
  wins: number;
  places: number;
  runners: number;
  winRate: number;
}

export interface HorseData {
  id: string;
  name: string;
  sex?: string;
  age?: number;
  breed?: string;
  sire?: string;
  dam?: string;
  owner?: string;
  trainerId?: string;
  trainerName?: string;
  careerWins: number;
  careerPlaces: number;
  careerRuns: number;
  careerEarnings: number;
}

export interface ParticipantData {
  id: string;
  horseNumber: number;
  horseId: string;
  horseName: string;
  horseAge?: number;
  horseSex?: string;
  sire?: string;
  dam?: string;
  jockeyId?: string;
  jockeyName?: string;
  trainerId?: string;
  trainerName?: string;
  draw?: number; // Corde ou départ
  weight?: number; // kg
  blinkers?: string; // Sans, Oeillères simples, Australiennes
  shoes?: string; // D4, DP, DA, Ferré
  oddsMorning?: number;
  oddsCurrent?: number;
  music?: string;
  finalPosition?: number;
  status: ParticipantStatusType;
}

export interface PredictionFactor {
  formScore: number;       // 0 - 100
  jockeyScore: number;     // 0 - 100
  distanceAptitude: number;// 0 - 100
  regularityScore: number; // 0 - 100
}

export interface PredictionTopPick {
  number: number;
  horseName: string;
  jockeyName: string;
  rank: number;
  overallScore: number;
  category: 'FAVORI' | 'BASE' | 'OUTSIDER' | 'TOCARD_SPECULATIF';
  comment: string;
  factors: PredictionFactor;
  missingDataWarning?: string;
}

export interface PredictionData {
  id: string;
  raceId: string;
  confidenceScore: number; // 1 to 5
  summaryText: string;
  topPicks: PredictionTopPick[];
  factorsJson?: string;
  topPicksJson?: string;
  isPublic: boolean;
  generatedAt: string;
}

export interface RaceResultData {
  id: string;
  raceId: string;
  arrivalOrder: string; // "4 - 12 - 7 - 1 - 9"
  reportSimpleGagnant?: number;
  reportSimplePlace?: number;
  reportQuinte?: number;
  comment?: string;
  verifiedAt: string;
}

export interface RaceData {
  id: string;
  meetingCode: string; // R1, R2
  meetingName: string;
  hippodromeName: string;
  hippodromeCity: string;
  raceNumber: number; // C1, C2
  name: string;
  slug: string;
  discipline: DisciplineType;
  distance: number;
  purse?: number;
  conditions?: string;
  scheduledAt: string;
  status: RaceStatusType;
  isQuinte: boolean;
  isPick5: boolean;
  trackSurface?: string;
  participants: ParticipantData[];
  prediction?: PredictionData;
  result?: RaceResultData;
}

export interface MeetingData {
  id: string;
  code: string; // R1, R2
  name: string;
  date: string; // YYYY-MM-DD
  hippodromeName: string;
  city: string;
  surface?: string;
  trackType?: string;
  status: RaceStatusType;
  races: RaceData[];
}

export interface ArticleData {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  categorySlug: string;
  categoryName: string;
  featuredImage?: string;
  isPublished: boolean;
  publishedAt: string;
  metaTitle?: string;
  metaDescription?: string;
  tags?: string[];
}

export interface SyncLogData {
  id: string;
  provider: string;
  status: 'SUCCESS' | 'FAILURE' | 'IN_PROGRESS';
  itemsSynced: number;
  details?: string;
  startedAt: string;
  completedAt?: string;
}

export interface AdPlacementData {
  id: string;
  code: string;
  name: string;
  slotId?: string;
  format: string;
  isEnabled: boolean;
  position: string;
}
