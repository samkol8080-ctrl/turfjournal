/**
 * Service de synchronisation automatique et continue avec l'API officielle PMU
 * Réalise les 10 opérations requises :
 * 1. Récupération du programme officiel du jour
 * 2. Découverte de toutes les réunions
 * 3. Découverte des courses pour chaque réunion
 * 4. Récupération des partants officiels de chaque épreuve
 * 5. Mise à jour des cotes en direct et matinales
 * 6. Détection des non-partants
 * 7. Récupération des arrivées officielles et rapports définitifs
 * 8. Mise à jour des statuts des courses (SCHEDULED, RUNNING, FINISHED)
 * 9. Enregistrement persistant dans la base de données
 * 10. Enregistrement des logs et des erreurs dans ApiSyncLog
 */

import { pmuService } from './api/pmu';
import prisma from './prisma';
import { isDatabaseConnected } from './data-service';
import { generateRacePrediction } from './prediction-engine';
import { evaluateArrivalOrder } from './accuracy-tracker';

let isSyncRunning = false;

export interface SyncReport {
  success: boolean;
  message: string;
  durationMs: number;
  timestamp: string;
  stats: {
    meetingsCount: number;
    racesCount: number;
    participantsCount: number;
    resultsCount: number;
    oddsUpdatedCount: number;
    nonRunnersCount: number;
  };
  errors: string[];
}

export async function runFullPmuSynchronization(options?: {
  dateStr?: string;
  forceRefresh?: boolean;
}): Promise<SyncReport> {
  // Empêcher l'exécution simultanée de tâches de synchronisation en double
  if (isSyncRunning) {
    return {
      success: false,
      message: 'Une synchronisation PMU est déjà en cours d\'exécution.',
      durationMs: 0,
      timestamp: new Date().toISOString(),
      stats: {
        meetingsCount: 0,
        racesCount: 0,
        participantsCount: 0,
        resultsCount: 0,
        oddsUpdatedCount: 0,
        nonRunnersCount: 0,
      },
      errors: ['Synchronisation concurrente évitée.'],
    };
  }

  isSyncRunning = true;
  const start = Date.now();
  const errors: string[] = [];
  const dateStr = options?.dateStr || new Date().toISOString().split('T')[0];

  const stats = {
    meetingsCount: 0,
    racesCount: 0,
    participantsCount: 0,
    resultsCount: 0,
    oddsUpdatedCount: 0,
    nonRunnersCount: 0,
  };

  const dbOk = await isDatabaseConnected();
  let syncLogId: string | null = null;

  if (dbOk) {
    try {
      const log = await prisma.apiSyncLog.create({
        data: {
          provider: 'PMU_OFFICIAL_API',
          endpoint: `/programme/${pmuService.formatDateToPmu(dateStr)}`,
          status: 'IN_PROGRESS',
          itemsSynced: 0,
          startedAt: new Date(),
        },
      });
      syncLogId = log.id;
    } catch {}
  }

  try {
    // 1. Récupérer le programme officiel du jour
    const prog = await pmuService.getDailyProgramme(dateStr);

    if (!prog.isAvailable || prog.meetings.length === 0) {
      throw new Error(prog.error || 'Les données PMU sont temporairement indisponibles.');
    }

    stats.meetingsCount = prog.meetings.length;
    const targetDate = new Date(dateStr + 'T12:00:00Z');

    // 2. Traiter chaque réunion
    for (const m of prog.meetings) {
      const rNum = parseInt(m.code.replace('R', ''), 10);
      stats.racesCount += m.races.length;

      let dbMeetingId: string | null = null;

      if (dbOk) {
        try {
          const hippo = await prisma.hippodrome.upsert({
            where: { code: m.code },
            update: { name: m.hippodromeName, city: m.city, surface: m.surface, trackType: m.trackType },
            create: { name: m.hippodromeName, code: m.code, city: m.city, surface: m.surface, trackType: m.trackType },
          });

          const dbM = await prisma.meeting.upsert({
            where: { date_code: { date: targetDate, code: m.code } },
            update: { name: m.name, status: m.status as any },
            create: {
              code: m.code,
              name: m.name,
              date: targetDate,
              hippodromeId: hippo.id,
              status: m.status as any,
            },
          });
          dbMeetingId = dbM.id;
        } catch (mErr: any) {
          errors.push(`Erreur DB réunion ${m.code}: ${mErr.message}`);
        }
      }

      // 3. Découvrir et traiter chaque course de la réunion
      for (const r of m.races) {
        const cNum = r.raceNumber;

        // 4. Récupérer les partants officiels
        let participants = r.participants;
        if (participants.length === 0) {
          try {
            participants = await pmuService.getParticipants(dateStr, rNum, cNum);
            r.participants = participants;
          } catch (pErr: any) {
            errors.push(`Erreur partants R${rNum}C${cNum}: ${pErr.message}`);
          }
        }

        stats.participantsCount += participants.length;

        // 5 & 6. Mettre à jour les cotes et détecter les non-partants
        for (const p of participants) {
          if (p.status === 'NON_RUNNER') {
            stats.nonRunnersCount++;
          }
          if (p.oddsCurrent || p.oddsMorning) {
            stats.oddsUpdatedCount++;
          }
        }

        // 7 & 8. Vérifier les arrivées officielles et mettre à jour le statut
        let raceResultData: any = null;
        try {
          const res = await pmuService.getRaceResult(dateStr, rNum, cNum);
          if (res && res.isFinished && res.arrivalOrder) {
            r.status = 'FINISHED';
            stats.resultsCount++;
            raceResultData = res;
          }
        } catch (resErr: any) {
          // Normal si la course n'est pas encore courue
        }

        // Générer le pronostic analytique
        let prediction = r.prediction;
        if (!prediction && participants.length > 0) {
          prediction = generateRacePrediction(r.id, r.name, r.discipline, participants);
          r.prediction = prediction;
        }

        // 9. Persister en base de données
        if (dbOk && dbMeetingId) {
          try {
            const dbRace = await prisma.race.upsert({
              where: { slug: r.slug },
              update: {
                name: r.name,
                distance: r.distance,
                purse: r.purse,
                status: r.status as any,
                isQuinte: r.isQuinte,
                isPick5: r.isPick5,
              },
              create: {
                meetingId: dbMeetingId,
                raceNumber: cNum,
                name: r.name,
                slug: r.slug,
                discipline: r.discipline as any,
                distance: r.distance,
                purse: r.purse,
                scheduledAt: new Date(r.scheduledAt),
                status: r.status as any,
                isQuinte: r.isQuinte,
                isPick5: r.isPick5,
              },
            });

            // Sauvegarder les partants réels
            for (const p of participants) {
              const horse = await prisma.horse.upsert({
                where: { name: p.horseName },
                update: {
                  age: p.horseAge,
                  sex: p.horseSex,
                },
                create: {
                  name: p.horseName,
                  age: p.horseAge,
                  sex: p.horseSex,
                },
              });

              let jockeyId: string | undefined;
              if (p.jockeyName && p.jockeyName !== 'Non renseigné') {
                const j = await prisma.jockey.upsert({
                  where: { name: p.jockeyName },
                  update: {},
                  create: { name: p.jockeyName },
                });
                jockeyId = j.id;
              }

              let trainerId: string | undefined;
              if (p.trainerName && p.trainerName !== 'Non renseigné') {
                const t = await prisma.trainer.upsert({
                  where: { name: p.trainerName },
                  update: {},
                  create: { name: p.trainerName },
                });
                trainerId = t.id;
              }

              await prisma.raceParticipant.upsert({
                where: { raceId_horseNumber: { raceId: dbRace.id, horseNumber: p.horseNumber } },
                update: {
                  oddsMorning: p.oddsMorning,
                  oddsCurrent: p.oddsCurrent,
                  shoes: p.shoes,
                  draw: p.draw,
                  weight: p.weight,
                  music: p.music,
                  status: p.status as any,
                  jockeyId,
                  trainerId,
                },
                create: {
                  raceId: dbRace.id,
                  horseId: horse.id,
                  horseNumber: p.horseNumber,
                  jockeyId,
                  trainerId,
                  oddsMorning: p.oddsMorning,
                  oddsCurrent: p.oddsCurrent,
                  shoes: p.shoes,
                  draw: p.draw,
                  weight: p.weight,
                  music: p.music,
                  status: p.status as any,
                },
              });

              // Enregistrer l'historique de cote si présent
              if (p.oddsCurrent || p.oddsMorning) {
                try {
                  await prisma.raceOdds.create({
                    data: {
                      raceId: dbRace.id,
                      horseNumber: p.horseNumber,
                      oddsMorning: p.oddsMorning,
                      oddsCurrent: p.oddsCurrent,
                      trend: 'STABLE',
                    },
                  });
                } catch {}
              }
            }

            // Sauvegarder le résultat officiel si disponible
            if (raceResultData && raceResultData.arrivalOrder) {
              await prisma.raceResult.upsert({
                where: { raceId: dbRace.id },
                update: {
                  arrivalOrder: raceResultData.arrivalOrder,
                  reportSimpleGagnant: raceResultData.reportSimpleGagnant,
                  reportSimplePlace: raceResultData.reportSimplePlace,
                  reportQuinte: raceResultData.reportQuinte,
                  comment: raceResultData.comment,
                  verifiedAt: new Date(),
                },
                create: {
                  raceId: dbRace.id,
                  arrivalOrder: raceResultData.arrivalOrder,
                  reportSimpleGagnant: raceResultData.reportSimpleGagnant,
                  reportSimplePlace: raceResultData.reportSimplePlace,
                  reportQuinte: raceResultData.reportQuinte,
                  comment: raceResultData.comment,
                  verifiedAt: new Date(),
                },
              });

              // Évaluer la prédiction historique
              if (prediction && prediction.topPicks.length > 0) {
                try {
                  const evalResult = evaluateArrivalOrder(
                    prediction.topPicks.map((tp) => tp.number),
                    raceResultData.arrivalOrder
                  );

                  await prisma.predictionHistory.create({
                    data: {
                      raceId: dbRace.id,
                      raceName: r.name,
                      raceDate: targetDate,
                      isQuinte: r.isQuinte,
                      topPicks: prediction.topPicks.map((tp) => tp.number).join(','),
                      actualArrival: raceResultData.arrivalOrder,
                      winnerHit: evalResult.winnerHit,
                      top3Hit: evalResult.top3Hit,
                      top5Hit: evalResult.top5Hit,
                      quinteHit: evalResult.quinteHit,
                      evaluatedAt: new Date(),
                    },
                  });
                } catch {}
              }
            }

            // Sauvegarder la prédiction si générée
            if (prediction) {
              await prisma.prediction.upsert({
                where: { raceId: dbRace.id },
                update: {
                  confidenceScore: prediction.confidenceScore,
                  summaryText: prediction.summaryText,
                  topPicksJson: JSON.stringify(prediction.topPicks),
                  factorsJson: JSON.stringify(prediction.topPicks[0]?.factors || {}),
                },
                create: {
                  raceId: dbRace.id,
                  confidenceScore: prediction.confidenceScore,
                  summaryText: prediction.summaryText,
                  topPicksJson: JSON.stringify(prediction.topPicks),
                  factorsJson: JSON.stringify(prediction.topPicks[0]?.factors || {}),
                  isPublic: true,
                },
              });
            }
          } catch (rErr: any) {
            errors.push(`Erreur persistance course ${r.slug}: ${rErr.message}`);
          }
        }
      }
    }

    const durationMs = Date.now() - start;

    // 10. Mettre à jour le log de synchronisation
    if (dbOk && syncLogId) {
      try {
        await prisma.apiSyncLog.update({
          where: { id: syncLogId },
          data: {
            status: 'SUCCESS',
            itemsSynced: stats.racesCount,
            details: `Synchronisation réussie : ${stats.meetingsCount} réunions, ${stats.racesCount} courses, ${stats.participantsCount} partants, ${stats.resultsCount} résultats.`,
            errorMessage: errors.length > 0 ? errors.slice(0, 5).join(' | ') : null,
            completedAt: new Date(),
          },
        });
      } catch {}
    }

    return {
      success: true,
      message: `Synchronisation PMU réussie : ${stats.meetingsCount} réunions, ${stats.racesCount} courses (${stats.resultsCount} résultats officiels).`,
      durationMs,
      timestamp: new Date().toISOString(),
      stats,
      errors,
    };
  } catch (err: any) {
    const durationMs = Date.now() - start;
    const errorMsg = err.message || 'Erreur inconnue de synchronisation PMU';

    if (dbOk && syncLogId) {
      try {
        await prisma.apiSyncLog.update({
          where: { id: syncLogId },
          data: {
            status: 'FAILURE',
            errorMessage: errorMsg,
            completedAt: new Date(),
          },
        });
      } catch {}
    }

    return {
      success: false,
      message: errorMsg,
      durationMs,
      timestamp: new Date().toISOString(),
      stats,
      errors: [...errors, errorMsg],
    };
  } finally {
    isSyncRunning = false;
  }
}
