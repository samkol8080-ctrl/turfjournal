import { ParticipantData, PredictionData, PredictionTopPick, PredictionFactor } from '@/types/racing';

/**
 * Analyse de la musique d'un cheval (ex: "1a 2a 3a (25) 4a Da")
 * Calcule un score de forme entre 0 et 100.
 */
export function analyzeMusic(music?: string): { score: number; warning?: string } {
  if (!music || music.trim().length === 0) {
    return { score: 50, warning: 'Aucune performance récente enregistrée' };
  }

  // Tokenize performances
  const tokens = music.replace(/[()]/g, ' ').split(/\s+/).filter(Boolean);
  if (tokens.length === 0) {
    return { score: 50, warning: 'Historique incomplet' };
  }

  let totalPoints = 0;
  let totalWeights = 0;
  let disqualifiedCount = 0;

  tokens.slice(0, 5).forEach((token, index) => {
    // Poids décroissant pour les courses récentes : 1.0, 0.8, 0.6, 0.4, 0.2
    const weight = Math.max(0.2, 1.0 - index * 0.2);
    totalWeights += weight;

    const upper = token.toUpperCase();
    if (upper.startsWith('D') || upper.includes('DA') || upper.includes('DM')) {
      disqualifiedCount++;
      // Zéro point pour disqualification
    } else if (upper.startsWith('1')) {
      totalPoints += 10 * weight;
    } else if (upper.startsWith('2')) {
      totalPoints += 8 * weight;
    } else if (upper.startsWith('3')) {
      totalPoints += 6 * weight;
    } else if (upper.startsWith('4')) {
      totalPoints += 4 * weight;
    } else if (upper.startsWith('5')) {
      totalPoints += 2.5 * weight;
    } else {
      // Non placé
      totalPoints += 1 * weight;
    }
  });

  const rawScore = totalWeights > 0 ? (totalPoints / (totalWeights * 10)) * 100 : 50;
  const score = Math.min(98, Math.max(15, Math.round(rawScore)));

  let warning: string | undefined;
  if (disqualifiedCount >= 2) {
    warning = `Attention : cheval fautif (${disqualifiedCount} disqualifications récentes)`;
  } else if (tokens.length < 3) {
    warning = 'Faible nombre de courses enregistrées (données statistiques partielles)';
  }

  return { score, warning };
}

/**
 * Calcul des facteurs pour un partant individuel
 */
export function computeParticipantFactors(
  p: ParticipantData,
  discipline: string
): { factors: PredictionFactor; overallScore: number; warning?: string } {
  const { score: formScore, warning } = analyzeMusic(p.music);

  // Score Entourage (Jockey / Driver + Entraîneur)
  let jockeyScore = 65;
  if (p.oddsMorning && p.oddsMorning < 5) {
    jockeyScore += 15;
  } else if (p.oddsMorning && p.oddsMorning > 20) {
    jockeyScore -= 10;
  }

  // Bonus Ferrure (Trot)
  let shoeBonus = 0;
  if (discipline.includes('TROT')) {
    if (p.shoes === 'D4') shoeBonus = 12; // Déferré des 4
    else if (p.shoes === 'DA' || p.shoes === 'DP') shoeBonus = 6;
  }

  // Bonus Corde / Numéro
  let drawBonus = 0;
  if (p.draw && p.draw >= 1 && p.draw <= 6) {
    drawBonus = 5; // Corde favorable
  }

  // Régularité
  const regularityScore = Math.min(95, Math.max(30, Math.round(formScore * 0.9 + (p.oddsMorning ? 20 - Math.min(20, p.oddsMorning) : 10))));
  const distanceAptitude = Math.min(96, Math.max(40, Math.round(60 + drawBonus + (shoeBonus > 0 ? 10 : 0))));

  const weightedOverall = Math.round(
    formScore * 0.40 +
    jockeyScore * 0.25 +
    distanceAptitude * 0.20 +
    regularityScore * 0.15 +
    shoeBonus
  );

  const overallScore = Math.min(99, Math.max(20, weightedOverall));

  return {
    factors: {
      formScore,
      jockeyScore: Math.min(95, jockeyScore),
      distanceAptitude,
      regularityScore,
    },
    overallScore,
    warning,
  };
}

/**
 * Moteur de prédiction complet pour une course
 */
export function generateRacePrediction(
  raceId: string,
  raceName: string,
  discipline: string,
  participants: ParticipantData[]
): PredictionData {
  if (!participants || participants.length === 0) {
    return {
      id: `pred-${raceId}`,
      raceId,
      confidenceScore: 1,
      summaryText: 'Analyse insuffisante : données historiques limitées.',
      topPicks: [],
      isPublic: true,
      generatedAt: new Date().toISOString(),
    };
  }

  // Filtrer les partants valides (non déclarés non-partants)
  const runners = participants.filter((p) => p.status === 'RUNNER');

  const scoredList = runners.map((p) => {
    const { factors, overallScore, warning } = computeParticipantFactors(p, discipline);
    return {
      participant: p,
      factors,
      overallScore,
      warning,
    };
  });

  // Trier par score global décroissant
  scoredList.sort((a, b) => b.overallScore - a.overallScore);

  // Assigner les catégories logiques de pronostic
  const topPicks: PredictionTopPick[] = scoredList.map((item, index) => {
    let category: 'FAVORI' | 'BASE' | 'OUTSIDER' | 'TOCARD_SPECULATIF';
    let comment = '';

    if (index === 0) {
      category = 'FAVORI';
      comment = `Premier choix statistique (${item.overallScore}/100). Très solide sur ses dernières sorties avec des indicateurs de forme au vert.`;
    } else if (index === 1 || index === 2) {
      category = 'BASE';
      comment = `Indispensable pour une combinaison de jeu. Grande constance et entourage performant.`;
    } else if (index < 5) {
      category = 'OUTSIDER';
      comment = `Candidat très compétitif pour les accessits. Capable de brouiller les cartes avec un parcours limpide.`;
    } else {
      category = 'TOCARD_SPECULATIF';
      comment = `Sélection spéculative à belle cote pour pimenter les rapports des paris combinés (Quinté / Multi).`;
    }

    return {
      number: item.participant.horseNumber,
      horseName: item.participant.horseName,
      jockeyName: item.participant.jockeyName || 'Non renseigné',
      rank: index + 1,
      overallScore: item.overallScore,
      category,
      comment,
      factors: item.factors,
      missingDataWarning: item.warning,
    };
  });

  // Déterminer la confiance globale (1 à 5 étoiles)
  const gapBetweenTop2 = (topPicks[0]?.overallScore || 0) - (topPicks[1]?.overallScore || 0);
  let confidenceScore = 3;
  if (gapBetweenTop2 > 10 && (topPicks[0]?.overallScore || 0) > 85) {
    confidenceScore = 5;
  } else if (gapBetweenTop2 > 5) {
    confidenceScore = 4;
  } else if (scoredList.length < 8) {
    confidenceScore = 2;
  }

  const leader = topPicks[0];
  const summary = leader
    ? `Pour cette épreuve (${raceName}), notre modèle mathématique place en tête le n°${leader.number} ${leader.horseName} avec un indice de performance de ${leader.overallScore}/100. L'analyse met en valeur sa musique récente et son aptitude aux conditions de course. La course reste ouverte aux accessits avec plusieurs outsiders capables d'accrocher une place.`
    : `Analyse statistique disponible pour la course ${raceName}.`;

  return {
    id: `pred-${raceId}`,
    raceId,
    confidenceScore,
    summaryText: summary,
    topPicks: topPicks.slice(0, 8), // Top 8 chevaux recommandés
    isPublic: true,
    generatedAt: new Date().toISOString(),
  };
}
