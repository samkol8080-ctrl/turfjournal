import { RaceData, PredictionTopPick } from '@/types/racing';

export interface AccuracyMetric {
  totalEvaluatedRaces: number;
  top1WinRate: number;      // % du cheval n°1 finissant 1er
  top1PlaceRate: number;    // % du cheval n°1 finissant dans les 3 premiers
  top3PlaceRate: number;    // % où au moins 2 chevaux du top 3 finissent placés
  top5QuinteRate: number;   // % où au moins 3 chevaux de notre sélection finissent dans le Quinté
  recentEvaluations: RaceEvaluation[];
}

export interface RaceEvaluation {
  raceId: string;
  raceName: string;
  meetingCode: string;
  raceNumber: number;
  date: string;
  topPickNumber: number;
  topPickHorse: string;
  officialArrival: number[]; // ex: [8, 3, 1, 5, 4]
  topPickPosition: number | null; // position finale du top pick
  wasWinner: boolean;
  wasPlaced: boolean;
  score: number;
}

/**
 * Calcule la précision mathématique des pronostics algorithmiques
 * en confrontant les prédictions générées aux ordres d'arrivées officiels PMU.
 */
export function computeHistoricalAccuracy(races: RaceData[]): AccuracyMetric {
  let evaluatedCount = 0;
  let top1Wins = 0;
  let top1Places = 0;
  let top3Hits = 0;
  let top5Hits = 0;

  const evaluations: RaceEvaluation[] = [];

  for (const race of races) {
    if (!race.result || !race.result.arrivalOrder || !race.prediction || !race.prediction.topPicks.length) {
      continue;
    }

    // Extraction des numéros officiels d'arrivée
    const officialNumbers = race.result.arrivalOrder
      .split(/[-,\s]+/)
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => !isNaN(n) && n > 0);

    if (officialNumbers.length === 0) continue;

    evaluatedCount++;

    const topPicks = race.prediction.topPicks;
    const topPick = topPicks[0];
    const top3Picks = topPicks.slice(0, 3).map((p) => p.number);
    const top5Picks = topPicks.slice(0, 5).map((p) => p.number);

    // Position réelle du favori
    const topPickPos = officialNumbers.indexOf(topPick.number);
    const position = topPickPos !== -1 ? topPickPos + 1 : null;

    const isWinner = position === 1;
    const isPlaced = position !== null && position <= 3;

    if (isWinner) top1Wins++;
    if (isPlaced) top1Places++;

    // Précision du Top 3 : combien figurent dans les 3 premiers officiels ?
    const officialTop3 = officialNumbers.slice(0, 3);
    const top3Matches = top3Picks.filter((num) => officialTop3.includes(num)).length;
    if (top3Matches >= 2) top3Hits++;

    // Précision Quinté (Top 5)
    const officialTop5 = officialNumbers.slice(0, 5);
    const top5Matches = top5Picks.filter((num) => officialTop5.includes(num)).length;
    if (top5Matches >= 3) top5Hits++;

    evaluations.push({
      raceId: race.id,
      raceName: race.name,
      meetingCode: race.meetingCode,
      raceNumber: race.raceNumber,
      date: race.scheduledAt.split('T')[0],
      topPickNumber: topPick.number,
      topPickHorse: topPick.horseName,
      officialArrival: officialNumbers.slice(0, 5),
      topPickPosition: position,
      wasWinner: isWinner,
      wasPlaced: isPlaced,
      score: topPick.overallScore,
    });
  }

  // Si aucune course évaluée disponible
  if (evaluatedCount === 0) {
    return {
      totalEvaluatedRaces: 0,
      top1WinRate: 0,
      top1PlaceRate: 0,
      top3PlaceRate: 0,
      top5QuinteRate: 0,
      recentEvaluations: [],
    };
  }

  return {
    totalEvaluatedRaces: evaluatedCount,
    top1WinRate: Math.round((top1Wins / evaluatedCount) * 1000) / 10,
    top1PlaceRate: Math.round((top1Places / evaluatedCount) * 1000) / 10,
    top3PlaceRate: Math.round((top3Hits / evaluatedCount) * 1000) / 10,
    top5QuinteRate: Math.round((top5Hits / evaluatedCount) * 1000) / 10,
    recentEvaluations: evaluations.slice(0, 10),
  };
}

export interface ArrivalEvaluation {
  winnerHit: boolean;
  top3Hit: boolean;
  top5Hit: boolean;
  quinteHit: boolean;
}

/**
 * Évalue la concordance entre une sélection de pronostic et l'ordre d'arrivée officiel PMU
 */
export function evaluateArrivalOrder(
  topPicks: number[],
  arrivalOrder: string
): ArrivalEvaluation {
  const officialNumbers = arrivalOrder
    .split(/[-,\s]+/)
    .map((s) => parseInt(s.trim(), 10))
    .filter((n) => !isNaN(n) && n > 0);

  if (officialNumbers.length === 0 || topPicks.length === 0) {
    return { winnerHit: false, top3Hit: false, top5Hit: false, quinteHit: false };
  }

  const top1 = topPicks[0];
  const winner = officialNumbers[0];
  const winnerHit = top1 === winner;

  const officialTop3 = officialNumbers.slice(0, 3);
  const myTop3 = topPicks.slice(0, 3);
  const top3Hit = myTop3.filter((n) => officialTop3.includes(n)).length >= 2;

  const officialTop5 = officialNumbers.slice(0, 5);
  const myTop5 = topPicks.slice(0, 5);
  const top5Matches = myTop5.filter((n) => officialTop5.includes(n)).length;
  const top5Hit = top5Matches >= 3;
  const quinteHit = top5Matches === 5;

  return { winnerHit, top3Hit, top5Hit, quinteHit };
}
