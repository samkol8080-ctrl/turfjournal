import fs from 'fs';
import path from 'path';

export interface AdPlacement {
  id: string;
  name: string;
  slotId: string;
  format: 'horizontal' | 'rectangle' | 'vertical' | 'responsive';
  location: string;
  isEnabled: boolean;
}

export interface AdSenseConfig {
  isEnabled: boolean;
  clientId: string;
  autoAdsEnabled: boolean;
  placements: AdPlacement[];
  updatedAt: string;
}

export interface SeoAndAnalyticsConfig {
  googleSearchConsoleTag: string; // ex: Code ou clé de vérification de Google Search Console
  googleAnalyticsId: string;      // ex: G-XXXXXXXXXX (Google Analytics 4)
  googleTagManagerId: string;    // ex: GTM-XXXXXX
  metaTitleSuffix: string;       // ex: " | TurfJournal"
  metaDefaultDescription: string;
}

export interface AnnouncementConfig {
  isEnabled: boolean;
  text: string;
  linkText?: string;
  linkUrl?: string;
}

export interface SocialLinksConfig {
  twitter?: string;
  telegram?: string;
  facebook?: string;
  youtube?: string;
}

export interface PartnerSpaceConfig {
  isEnabled: boolean; // Activer / Désactiver l'Espace Partenaire depuis le backend
  customBannerText?: string;
  customBannerLink?: string;
  badgeLabel?: string;
}

export interface GeminiConfig {
  apiKey: string;
  model: string; // ex: 'gemini-1.5-flash', 'gemini-2.0-flash'
  autoUpdateDaily: boolean;
  systemPrompt?: string;
}

export interface SiteSettings {
  siteName: string;
  siteUrl: string;
  brandTagline: string;
  contactEmail: string;
  apiProviderUrl: string;
  adminPassword: string;
  adsense: AdSenseConfig;
  partnerSpace: PartnerSpaceConfig;
  gemini: GeminiConfig;
  seoAndAnalytics: SeoAndAnalyticsConfig;
  announcement: AnnouncementConfig;
  socialLinks: SocialLinksConfig;
}

const DEFAULT_SETTINGS: SiteSettings = {
  siteName: 'TurfJournal',
  siteUrl: 'https://turfjournal.com',
  brandTagline: 'Le Journal Numérique des Courses Hippiques & Pronostics',
  contactEmail: 'contact@turfjournal.com',
  apiProviderUrl: 'https://offline.turfinfo.api.pmu.fr/rest/client/7/programme',
  adminPassword: process.env.ADMIN_PASSWORD || 'turfjournal2026',
  adsense: {
    isEnabled: false,
    clientId: '',
    autoAdsEnabled: false,
    placements: [
      {
        id: 'header-banner',
        name: 'Bannière En-tête',
        slotId: '1001001',
        format: 'horizontal',
        location: 'home-top',
        isEnabled: true,
      },
      {
        id: 'quinte-middle',
        name: 'Sous le Quinté+',
        slotId: '1001002',
        format: 'horizontal',
        location: 'quinte-below',
        isEnabled: true,
      },
      {
        id: 'race-details',
        name: 'Détail Course',
        slotId: '1001003',
        format: 'rectangle',
        location: 'race-bottom',
        isEnabled: true,
      },
      {
        id: 'footer-banner',
        name: 'Bannière Pied de Page',
        slotId: '1001004',
        format: 'horizontal',
        location: 'footer-top',
        isEnabled: true,
      },
    ],
    updatedAt: new Date().toISOString(),
  },
  partnerSpace: {
    isEnabled: false, // DÉSACTIVÉ par défaut : aucun bloc/placeholder ne s'affiche
    customBannerText: '',
    customBannerLink: '',
    badgeLabel: 'Espace Partenaire',
  },
  gemini: {
    apiKey: process.env.GEMINI_API_KEY || '',
    model: 'gemini-1.5-flash',
    autoUpdateDaily: true,
  },
  seoAndAnalytics: {
    googleSearchConsoleTag: '',
    googleAnalyticsId: '',
    googleTagManagerId: '',
    metaTitleSuffix: ' | TurfJournal',
    metaDefaultDescription:
      'Site d\'information hippique gratuit : pronostics Quinté+, partants, cotes en direct et résultats officiels PMU.',
  },
  announcement: {
    isEnabled: false,
    text: 'Bienvenue sur la nouvelle version de TurfJournal.com avec données PMU en direct !',
    linkText: 'Découvrir le Quinté+',
    linkUrl: '/pronostics',
  },
  socialLinks: {
    twitter: 'https://twitter.com/turfjournal',
    telegram: 'https://t.me/turfjournal',
    facebook: '',
    youtube: '',
  },
};

const SETTINGS_FILE_PATH = path.join(process.cwd(), 'data', 'settings.json');

let memorySettings: SiteSettings | null = null;

export function getSiteSettings(): SiteSettings {
  if (memorySettings) return memorySettings;

  try {
    if (fs.existsSync(SETTINGS_FILE_PATH)) {
      const raw = fs.readFileSync(SETTINGS_FILE_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      // Merge avec les valeurs par défaut au cas où des clés ont été ajoutées
      memorySettings = {
        ...DEFAULT_SETTINGS,
        ...parsed,
        adsense: {
          ...DEFAULT_SETTINGS.adsense,
          ...(parsed.adsense || {}),
        },
        partnerSpace: {
          ...DEFAULT_SETTINGS.partnerSpace,
          ...(parsed.partnerSpace || {}),
        },
        gemini: {
          ...DEFAULT_SETTINGS.gemini,
          ...(parsed.gemini || {}),
        },
        seoAndAnalytics: {
          ...DEFAULT_SETTINGS.seoAndAnalytics,
          ...(parsed.seoAndAnalytics || {}),
        },
        announcement: {
          ...DEFAULT_SETTINGS.announcement,
          ...(parsed.announcement || {}),
        },
        socialLinks: {
          ...DEFAULT_SETTINGS.socialLinks,
          ...(parsed.socialLinks || {}),
        },
      };
      return memorySettings!;
    }
  } catch (err) {
    console.warn('Erreur lecture settings.json, utilisation des paramètres par défaut :', err);
  }

  try {
    const dir = path.dirname(SETTINGS_FILE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(SETTINGS_FILE_PATH, JSON.stringify(DEFAULT_SETTINGS, null, 2), 'utf-8');
  } catch {}

  memorySettings = { ...DEFAULT_SETTINGS };
  return memorySettings;
}

export function saveSiteSettings(newSettings: Partial<SiteSettings>): SiteSettings {
  const current = getSiteSettings();
  const updated: SiteSettings = {
    ...current,
    ...newSettings,
    adsense: {
      ...current.adsense,
      ...(newSettings.adsense || {}),
      updatedAt: new Date().toISOString(),
    },
    partnerSpace: {
      ...current.partnerSpace,
      ...(newSettings.partnerSpace || {}),
    },
    gemini: {
      ...current.gemini,
      ...(newSettings.gemini || {}),
    },
    seoAndAnalytics: {
      ...current.seoAndAnalytics,
      ...(newSettings.seoAndAnalytics || {}),
    },
    announcement: {
      ...current.announcement,
      ...(newSettings.announcement || {}),
    },
    socialLinks: {
      ...current.socialLinks,
      ...(newSettings.socialLinks || {}),
    },
  };

  try {
    const dir = path.dirname(SETTINGS_FILE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(SETTINGS_FILE_PATH, JSON.stringify(updated, null, 2), 'utf-8');
  } catch (err) {
    console.error('Erreur sauvegarde settings.json :', err);
  }

  memorySettings = updated;
  return updated;
}

export function getAdSenseConfig(): AdSenseConfig {
  return getSiteSettings().adsense;
}

export function updateAdSenseConfig(update: Partial<AdSenseConfig>): AdSenseConfig {
  const current = getAdSenseConfig();
  const updated: AdSenseConfig = {
    ...current,
    ...update,
    updatedAt: new Date().toISOString(),
  };

  saveSiteSettings({ adsense: updated });
  return updated;
}

export function deleteAdSense(): AdSenseConfig {
  const disabled: AdSenseConfig = {
    isEnabled: false,
    clientId: '',
    autoAdsEnabled: false,
    placements: [],
    updatedAt: new Date().toISOString(),
  };

  saveSiteSettings({ adsense: disabled });
  return disabled;
}

export function addAdPlacement(placement: Omit<AdPlacement, 'id'>): AdPlacement {
  const current = getAdSenseConfig();
  const id = `slot-${Date.now().toString(36)}`;
  const newPlacement: AdPlacement = { id, ...placement };

  updateAdSenseConfig({
    placements: [...current.placements, newPlacement],
  });

  return newPlacement;
}

export function removeAdPlacement(placementId: string): boolean {
  const current = getAdSenseConfig();
  const filtered = current.placements.filter((p) => p.id !== placementId);
  if (filtered.length !== current.placements.length) {
    updateAdSenseConfig({ placements: filtered });
    return true;
  }
  return false;
}

export function clearSettingsMemoryCache(): void {
  memorySettings = null;
}
