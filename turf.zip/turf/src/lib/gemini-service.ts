import { RaceData, ArticleData } from '@/types/racing';
import { getSiteSettings, saveSiteSettings } from './settings-service';
import { saveArticle, getArticleBySlug, slugify } from './article-service';

export interface GeminiActualityResult {
  success: boolean;
  isNew: boolean;
  message: string;
  article: ArticleData;
  source: 'gemini' | 'template_fallback';
  modelUsed?: string;
  latencyMs?: number;
}

/**
 * Teste la clé d'API Gemini et la connectivité avec l'API Google Generative Language
 */
export async function testGeminiConnection(
  customApiKey?: string,
  customModel?: string
): Promise<{ success: boolean; message: string; model: string; latencyMs: number }> {
  const settings = getSiteSettings();
  const apiKey = (customApiKey || settings.gemini?.apiKey || process.env.GEMINI_API_KEY || '').trim();
  const model = customModel || settings.gemini?.model || 'gemini-1.5-flash';

  if (!apiKey) {
    return {
      success: false,
      message: 'Aucune clé API Gemini configurée. Veuillez renseigner votre clé Google Gemini API.',
      model,
      latencyMs: 0,
    };
  }

  const start = Date.now();
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: 'Réponds uniquement par : "Connexion Gemini API réussie pour TurfJournal."',
              },
            ],
          },
        ],
        generationConfig: {
          maxOutputTokens: 50,
          temperature: 0.2,
        },
      }),
    });

    const latencyMs = Date.now() - start;
    const data = await res.json();

    if (!res.ok || data.error) {
      return {
        success: false,
        message: `Erreur Gemini API (${res.status}) : ${data.error?.message || 'Clé invalide'}`,
        model,
        latencyMs,
      };
    }

    const reply = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || 'OK';
    return {
      success: true,
      message: `Connecté avec succès à Gemini (${model}) : "${reply}"`,
      model,
      latencyMs,
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Erreur de communication avec l'API Gemini : ${err.message || 'Hôte injoignable'}`,
      model,
      latencyMs: Date.now() - start,
    };
  }
}

/**
 * Rédige et publie l'actualité du jour avec Gemini AI à partir des données réelles PMU
 */
export async function generateActualityWithGemini(
  quinteRace: RaceData | null,
  targetDateStr?: string
): Promise<GeminiActualityResult> {
  const start = Date.now();
  const todayStr = targetDateStr || new Date().toISOString().split('T')[0];
  const dateObj = new Date(todayStr + 'T12:00:00Z');
  const dateFr = dateObj.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const capitalizedDateFr = dateFr.charAt(0).toUpperCase() + dateFr.slice(1);

  const hippo = quinteRace?.hippodromeName || 'Vincennes';
  const raceName = quinteRace?.name || 'Grand Prix du Jour';
  const discipline = quinteRace?.discipline || 'Trot Attelé';
  const distance = quinteRace?.distance ? `${quinteRace.distance} mètres` : '2 700 mètres';
  const prize = quinteRace?.purse ? `${quinteRace.purse.toLocaleString('fr-FR')} €` : '53 000 €';
  const partants = quinteRace?.participants || [];
  const partantsCount = partants.length > 0 ? partants.length : 16;

  const targetSlug = `quinte-du-${todayStr}-${slugify(hippo)}`;

  // Vérifier si l'actualité existe déjà pour aujourd'hui
  const existing = await getArticleBySlug(targetSlug);
  if (existing) {
    return {
      success: true,
      isNew: false,
      message: 'L\'actualité du jour est déjà en ligne pour cette épreuve.',
      article: existing,
      source: 'gemini',
      latencyMs: Date.now() - start,
    };
  }

  // Vérifier la configuration Gemini
  const settings = getSiteSettings();
  const apiKey = (settings.gemini?.apiKey || process.env.GEMINI_API_KEY || '').trim();
  const model = settings.gemini?.model || 'gemini-1.5-flash';

  if (!apiKey) {
    // Si pas de clé Gemini, fallback immédiat sur le modèle journalistique déterministe
    const fallbackArticle = await generateDeterministicDailyNews(quinteRace, todayStr);
    return {
      success: true,
      isNew: true,
      message: 'Actualité rédigée via le moteur standard (configurez votre clé Gemini API dans le panneau admin pour activer l\'IA).',
      article: fallbackArticle,
      source: 'template_fallback',
      latencyMs: Date.now() - start,
    };
  }

  // Préparation du prompt enrichi avec les données réelles PMU
  const participantsSummary = partants.slice(0, 10).map((p) => {
    return `N°${p.horseNumber} ${p.horseName} (${p.jockeyName || 'Driver/Jockey'}, Entr: ${p.trainerName || 'Écurie'}) - Musique: ${p.music || 'NC'} - Ferrure: ${p.shoes || 'Standard'} - Cote: ${p.oddsCurrent || p.oddsMorning || 'NC'}`;
  }).join('\n');

  const prompt = `Tu es le Rédacteur en Chef et Journaliste Hippique Émérite de TurfJournal.com.
Rédige un article d'actualité complet, passionnant, analytique et optimisé pour le référencement naturel (SEO) en français pour le Quinté+ du jour.

DONNÉES OFFICIELLES DU QUINTÉ :
- Date : ${capitalizedDateFr}
- Hippodrome : ${hippo}
- Nom de la course : ${raceName}
- Discipline : ${discipline}
- Distance : ${distance}
- Allocation totale : ${prize}
- Nombre de partants : ${partantsCount}

LISTE DES PARTANTS PRINCIPAUX ET COTES :
${participantsSummary}

CONSIGNES STRICTES :
1. Rédige un titre percutant au format : "Quinté+ du [Date] à ${hippo} : Analyse du ${raceName} et nos favoris"
2. Rédige un chapeau/résumé d'introduction de 2 phrases percutantes.
3. Rédige le corps de l'article en Markdown avec des sous-titres :
   - ### 1. Le Contexte & Les Pièges du Tracé
   - ### 2. Les Favoris Légitimes & Bases Solides
   - ### 3. Les Outsiders à Belles Cotes pour les Jeux Combinés
   - ### 4. La Synthèse & Décryptage TurfJournal
4. Mentionne les numéros et noms des chevaux avec pertinence.
5. Termine par un rappel d'éthique et de jeu responsable.

Fournis ta réponse sous forme de JSON strict avec exactement cette structure :
{
  "title": "Titre ici",
  "excerpt": "Résumé ici",
  "content": "Contenu complet en Markdown ici...",
  "tags": ["quinté+", "actualités", "${hippo.toLowerCase()}", "pmu", "pronostic"]
}`;

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2048,
        },
      }),
    });

    const data = await res.json();

    if (!res.ok || data.error) {
      console.warn('Erreur appel Gemini API :', data.error);
      const fallback = await generateDeterministicDailyNews(quinteRace, todayStr);
      return {
        success: true,
        isNew: true,
        message: `Repli sur le moteur standard (${data.error?.message || 'Erreur Gemini'})`,
        article: fallback,
        source: 'template_fallback',
        latencyMs: Date.now() - start,
      };
    }

    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    
    // Extraction JSON de la réponse Gemini
    let parsedJson: any = null;
    try {
      const jsonMatch = rawText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsedJson = JSON.parse(jsonMatch[0]);
      }
    } catch {
      // Ignorer si le formatage JSON direct échoue
    }

    const title = parsedJson?.title || `Quinté+ du ${capitalizedDateFr} à ${hippo} : Analyse du ${raceName}`;
    const excerpt = parsedJson?.excerpt || `Retrouvez notre étude complète du Quinté+ ce ${dateFr} sur l'hippodrome de ${hippo}. Décryptage des partants et sélection de nos experts.`;
    const content = parsedJson?.content || rawText;
    const tags = Array.isArray(parsedJson?.tags) ? parsedJson.tags : ['quinté+', 'actualités', hippo.toLowerCase(), 'pmu'];

    const saved = await saveArticle({
      title,
      slug: targetSlug,
      excerpt,
      content,
      categorySlug: 'actualites',
      categoryName: 'Quinté+ & Grands Prix',
      isPublished: true,
      publishedAt: new Date().toISOString(),
      tags,
      metaTitle: `${title} | TurfJournal`,
      metaDescription: excerpt.substring(0, 155),
    });

    return {
      success: true,
      isNew: true,
      message: `Actualité rédigée et publiée avec succès par Google Gemini AI (${model}) !`,
      article: saved,
      source: 'gemini',
      modelUsed: model,
      latencyMs: Date.now() - start,
    };
  } catch (err: any) {
    console.error('Exception Gemini AI, fallback standard :', err);
    const fallback = await generateDeterministicDailyNews(quinteRace, todayStr);
    return {
      success: true,
      isNew: true,
      message: `Actualité rédigée via le moteur standard (Gemini indisponible : ${err.message})`,
      article: fallback,
      source: 'template_fallback',
      latencyMs: Date.now() - start,
    };
  }
}

/**
 * Générateur déterministe de secours (utilisé si Gemini API n'est pas encore configuré)
 */
async function generateDeterministicDailyNews(quinteRace: RaceData | null, todayStr: string): Promise<ArticleData> {
  const dateObj = new Date(todayStr + 'T12:00:00Z');
  const dateFr = dateObj.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const capitalizedDateFr = dateFr.charAt(0).toUpperCase() + dateFr.slice(1);

  const hippo = quinteRace?.hippodromeName || 'Vincennes';
  const raceName = quinteRace?.name || 'Grand Prix du Jour';
  const discipline = quinteRace?.discipline || 'Trot Attelé';
  const distance = quinteRace?.distance ? `${quinteRace.distance} mètres` : '2 700 mètres';
  const prize = quinteRace?.purse ? `${quinteRace.purse.toLocaleString('fr-FR')} €` : '53 000 €';
  const partants = quinteRace?.participants || [];
  const partantsCount = partants.length > 0 ? partants.length : 16;

  const targetSlug = `quinte-du-${todayStr}-${slugify(hippo)}`;

  const topHorses = partants.slice(0, 4);
  const outsiders = partants.slice(4, 7);

  const favorisText = topHorses.length > 0
    ? topHorses
        .map(
          (h) =>
            `- **N°${h.horseNumber} - ${h.horseName}** (${h.jockeyName || 'Driver titulaire'}) : Musique \`${h.music || 'Régulier'}\`. Candidat très sérieux pour la victoire.`
        )
        .join('\n')
    : `- **N°4 - Idao de Tillard** : Référence incontestable de la discipline.\n- **N°7 - Hooker Berry** : Redoutable au sprint.`;

  const outsidersText = outsiders.length > 0
    ? outsiders
        .map(
          (h) =>
            `- **N°${h.horseNumber} - ${h.horseName}** : Belle possibilité à belle cote en bout de combinaison.`
        )
        .join('\n')
    : `- **N°2 - Go On Boy** : Capable de créer une excellente surprise.`;

  const title = `Quinté+ du ${capitalizedDateFr} à ${hippo} : Analyse du ${raceName} & Forces en Présence`;
  const excerpt = `Découvrez notre décryptage complet du Quinté+ de ce ${dateFr} sur l'hippodrome de ${hippo}. Analyse des conditions de course et sélection de la rédaction.`;

  const content = `L'événement quotidien du PMU nous emmène ce ${dateFr} sur l'hippodrome de **${hippo}** pour le prestigieux **${raceName}**. 

Cette épreuve réunit un peloton de **${partantsCount} concurrents** sur la distance de **${distance}**, avec une dotation globale de **${prize}**.

### 1. Le Contexte de l'Épreuve & Conditions de Course
Disputé en **${discipline}**, le tracé de ${hippo} réclamera une parfaite tenue et une gestion rigoureuse du rythme.

### 2. Les Favoris Incontournables
${favorisText}

### 3. Les Outsiders à Suivre
${outsidersText}

### 4. La Synthèse de la Rédaction
Privilégiez les partants affichant une régularité exemplaire sur ce type de parcours. N'oubliez pas que les courses demeurent un sport soumis aux aléas : misez avec mesure et responsabilité.`;

  return saveArticle({
    title,
    slug: targetSlug,
    excerpt,
    content,
    categorySlug: 'actualites',
    categoryName: 'Quinté+ & Grands Prix',
    isPublished: true,
    publishedAt: new Date().toISOString(),
    tags: ['quinté+', 'actualités', hippo.toLowerCase(), 'pmu'],
    metaTitle: `${title} | TurfJournal`,
    metaDescription: excerpt.substring(0, 155),
  });
}
