import fs from 'fs';
import path from 'path';
import { ArticleData, RaceData } from '@/types/racing';
import { prisma } from './prisma';

const ARTICLES_FILE_PATH = path.join(process.cwd(), 'data', 'articles.json');

// Base seed d'articles initiaux à forte valeur ajoutée
const DEFAULT_ARTICLES: ArticleData[] = [
  {
    id: 'art-1',
    title: 'Comment analyser la musique d\'un cheval : Le guide méthodologique complet',
    slug: 'comment-analyser-la-musique-d-un-cheval',
    excerpt: 'Apprenez à décrypter les codes de la musique hippique (1a, 2m, Da, p, h) pour évaluer fidèlement la forme et la régularité d\'un partant.',
    content: `La "musique" d'un cheval est son palmarès synthétique lors de ses dernières sorties officielles. Bien la déchiffrer est le premier réflexe de tout turfiste avisé.

### 1. Décryptage des chiffres et des lettres
Chaque bloc représente une course, de la plus récente (à gauche) à la plus ancienne :
- **Le chiffre** indique la place obtenue à l'arrivée (ex: 1 = vainqueur, 2 = deuxième). 0 signifie non-placé au-delà de la 9e position.
- **La lettre** désigne la discipline :
  - **a** : Trot attelé
  - **m** : Trot monté
  - **p** : Plat (galop)
  - **h** : Haies (obstacle)
  - **s** : Steeple-chase
  - **c** : Cross-country
- **D** : Disqualifié (notamment pour allures irrégulières au trot).
- **T** : Tombé (en course d'obstacles).
- **A** : Arrêté par son jockey.
- **Les parenthèses** comme (25) indiquent un changement d'année civile.

### 2. Le poids de la récence
Une première place obtenue il y a deux semaines sur la même distance et le même hippodrome est infiniment plus parlante qu'une victoire datant de l'année précédente. Notre moteur d'analyse statistique applique un coefficient de dépréciation temporelle pour valoriser la dynamique actuelle.

### 3. Gare aux fausses impressions
Un cheval qui aligne des "0a" alors qu'il courait ferré pour préparer un grand rendez-vous peut se transformer le jour où son entraîneur le déferre des 4 pieds (D4). L'analyse contextuelle prime toujours sur le simple chiffre brut.`,
    categorySlug: 'guides',
    categoryName: 'Guides & Stratégies',
    isPublished: true,
    publishedAt: '2026-02-10T09:00:00Z',
    metaTitle: 'Comment lire la musique d\'un cheval | Guide TurfJournal',
    metaDescription: 'Comprenez facilement les codes et abréviations de la musique hippique pour analyser les chevaux partants et affiner vos pronostics.',
    tags: ['musique', 'débutant', 'trot', 'méthode'],
  },
  {
    id: 'art-2',
    title: 'Comprendre le Quinté+ : Fonctionnement, rapports et gestion de capital',
    slug: 'comprendre-le-quinte-plus-fonctionnement-et-rapports',
    excerpt: 'Le Quinté+ est la course phare du PMU réunissant des millions de parieurs. Découvrez ses spécificités, ses ordres de gains et les pièges à éviter.',
    content: `Événement quotidien incontournable, le Quinté+ propose de trouver les 5 premiers chevaux d'une épreuve sélectionnée.

### Pourquoi le Quinté+ fascine-t-il ?
Organisé chaque jour (vers 13h50 en semaine ou 15h15 le week-end, et en nocturne le vendredi), le Quinté+ concentre la plus grosse tirelire et les masses d'enjeux les plus denses.

### Les différents rapports d'arrivée
- **Ordre** : Vous avez les 5 premiers dans l'ordre exact.
- **Désordre** : Vous avez les 5 premiers sans l'ordre exact.
- **Bonus 4** : Vous avez trouvé les 4 premiers chevaux de l'épreuve.
- **Bonus 3** : Vous avez trouvé les 3 premiers chevaux de l'épreuve.

### Conseil de gestion : Ne jouez jamais au-dessus de vos moyens
Le Quinté+ comporte 14 à 18 partants, ce qui génère des millions de combinaisons possibles. Ne misez que des sommes modérées et considérez le pari hippique avant tout comme un divertissement d'analyse statistique et de passion équestre.`,
    categorySlug: 'guides',
    categoryName: 'Guides & Stratégies',
    isPublished: true,
    publishedAt: '2026-02-12T14:30:00Z',
    metaTitle: 'Tout savoir sur le Quinté+ | Règles, Bonus et Stratégies',
    metaDescription: 'Guide clair et détaillé sur le Quinté+ : rapports Ordre/Désordre, Bonus 4/3 et conseils de gestion de mise responsable.',
    tags: ['quinte', 'pmu', 'rapports', 'bankroll'],
  },
  {
    id: 'art-3',
    title: 'Trot, Plat ou Obstacle : Quelles différences pour vos analyses ?',
    slug: 'trot-plat-obstacle-differences-et-analyses',
    excerpt: 'Chaque discipline hippique obéit à ses propres règles biomécaniques, types de pistes et pièges tactiques. Tour d\'horizon complet.',
    content: `Le monde des courses se divise en trois grandes familles : le Trot, le Plat et l'Obstacle. Chacune requiert une lecture analytique distincte.

### 1. Le Trot (Attelé et Monté)
- L'allure imposée : Le cheval doit obligatoirement trotter sans tomber dans le galop, sous peine de disqualification immédiate.
- L'impact du déferrage : Déferré des 4 pieds (D4), un cheval gagne en moyenne 1 à 2 dixièmes de seconde au kilomètre, soit plusieurs longueurs à l'arrivée.
- Le driver : L'intelligence tactique dans le peloton et la gestion de l'effort jouent un rôle capital.

### 2. Le Galop Plat
- La vitesse pure : Les chevaux galopent librement à vitesse maximale.
- La corde et le terrain : L'état du terrain (très souple, lourd, PSF fibrée) et le numéro de corde dans les stalles influencent lourdement les chances.
- Le poids porté : Le jockey et son équipement sont rigoureusement pesés (handicap).

### 3. L'Obstacle (Haies et Steeple)
- L'endurance et le saut : La moindre faute sur une haie ou un gros obstacle brise le rythme et peut coûter la victoire.
- L'expérience : Les chevaux d'obstacle atteignent souvent leur maturité plus tardivement.`,
    categorySlug: 'actualites',
    categoryName: 'Actualités Hippiques',
    isPublished: true,
    publishedAt: '2026-02-14T11:00:00Z',
    metaTitle: 'Trot vs Plat vs Obstacle : Analyse comparative | TurfJournal',
    metaDescription: 'Découvrez les facteurs clés de chaque discipline hippique pour affiner votre lecture des courses.',
    tags: ['disciplines', 'trot', 'plat', 'obstacle'],
  },
  {
    id: 'art-4',
    title: 'Jeu Responsable : 5 règles d\'or pour maîtriser sa pratique hippique',
    slug: 'jeu-responsable-5-regles-d-or',
    excerpt: 'Le plaisir du turf réside dans l\'étude et la passion du cheval. Découvrez nos recommandations strictes pour préserver un jeu sain et maîtrisé.',
    content: `Le pari hippique doit impérativement rester un loisir intellectuel et passionné, et non un moyen de subsistance financière.

### 1. Fixez un budget strict à l'avance
Déterminez une somme mensuelle maximale dédiée au divertissement hippique, dont la perte ne compromettra jamais vos dépenses courantes (loyer, alimentation, factures).

### 2. Ne cherchez jamais à "vous refaire"
La tentation d'augmenter les mises après une série perdante est le piège le plus dangereux du parieur. Acceptez les aléas des courses : les chevaux ne sont pas des machines.

### 3. Évitez de jouer sous le coup de l'émotion ou de la fatigue
Une bonne analyse demande de la lucidité, de l'objectivité et du calme.

### 4. Rappel d'aide et numéros utiles
Si vous ou un proche ressentez des difficultés liées au jeu, des services d'écoute anonymes et gratuits sont à votre disposition :
- **Joueurs Info Service** (France) : **09 74 75 13 13** (appel non surtaxé)
- Service d'auto-exclusion et d'interdiction volontaire de jeux auprès de l'ANJ.`,
    categorySlug: 'jeu-responsable',
    categoryName: 'Jeu Responsable',
    isPublished: true,
    publishedAt: '2026-02-15T16:00:00Z',
    metaTitle: 'Jeu Responsable Turf : Conseils et Prévention | TurfJournal',
    metaDescription: 'Nos conseils essentiels pour parier avec modération et responsabilité. Numéros d\'assistance et protection des joueurs.',
    tags: ['jeu responsable', 'prévention', 'éthique'],
  },
];

let memoryArticles: ArticleData[] | null = null;
let isDbAvailable = true;

function canUseDatabase(): boolean {
  if (!process.env.DATABASE_URL || !isDbAvailable) return false;
  // Éviter de bloquer le build local si PostgreSQL local n'est pas actif
  if (process.env.DATABASE_URL.includes('localhost:5432') && process.env.USE_LOCAL_DB !== 'true') {
    return false;
  }
  return true;
}

/**
 * Normalise un texte en slug URL sécurisé
 */
export function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Supprime les accents
    .replace(/[^a-z0-9]+/g, '-')     // Remplace les caractères spéciaux par des tirets
    .replace(/^-+|-+$/g, '')         // Supprime tirets de début et fin
    .substring(0, 80);
}

/**
 * Charge tous les articles enregistrés (avec persistance fichier & PostgreSQL)
 */
export async function getAllArticles(options?: {
  categorySlug?: string;
  limit?: number;
  onlyPublished?: boolean;
}): Promise<ArticleData[]> {
  const onlyPublished = options?.onlyPublished ?? true;

  // 1. Tenter la lecture depuis PostgreSQL si configuré et disponible
  if (canUseDatabase()) {
    try {
      const dbArticles = await prisma.article.findMany({
        where: {
          ...(onlyPublished ? { isPublished: true } : {}),
          ...(options?.categorySlug ? { category: { slug: options.categorySlug } } : {}),
        },
        include: { category: true },
        orderBy: { publishedAt: 'desc' },
        take: options?.limit,
      });

      if (dbArticles && dbArticles.length > 0) {
        return dbArticles.map((a) => ({
          id: a.id,
          title: a.title,
          slug: a.slug,
          excerpt: a.excerpt,
          content: a.content,
          categorySlug: a.category.slug,
          categoryName: a.category.name,
          featuredImage: a.featuredImage || undefined,
          isPublished: a.isPublished,
          publishedAt: a.publishedAt ? a.publishedAt.toISOString() : a.createdAt.toISOString(),
          metaTitle: a.metaTitle || undefined,
          metaDescription: a.metaDescription || undefined,
          tags: a.tags ? a.tags.split(',').map((t) => t.trim()) : [],
        }));
      }
    } catch {
      isDbAvailable = false;
      // Fallback gracieux sur le fichier JSON
    }
  }

  // 2. Lecture fichier JSON / mémoire
  let articles = readArticlesFromFile();

  if (onlyPublished) {
    articles = articles.filter((a) => a.isPublished);
  }

  if (options?.categorySlug) {
    articles = articles.filter((a) => a.categorySlug === options.categorySlug);
  }

  // Tri décroissant par date de publication
  articles.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());

  if (options?.limit && options.limit > 0) {
    articles = articles.slice(0, options.limit);
  }

  return articles;
}

/**
 * Récupère un article par son slug
 */
export async function getArticleBySlug(slug: string): Promise<ArticleData | null> {
  const normalizedSlug = slugify(slug);

  if (canUseDatabase()) {
    try {
      const dbArticle = await prisma.article.findUnique({
        where: { slug: normalizedSlug },
        include: { category: true },
      });
      if (dbArticle) {
        return {
          id: dbArticle.id,
          title: dbArticle.title,
          slug: dbArticle.slug,
          excerpt: dbArticle.excerpt,
          content: dbArticle.content,
          categorySlug: dbArticle.category.slug,
          categoryName: dbArticle.category.name,
          featuredImage: dbArticle.featuredImage || undefined,
          isPublished: dbArticle.isPublished,
          publishedAt: dbArticle.publishedAt ? dbArticle.publishedAt.toISOString() : dbArticle.createdAt.toISOString(),
          metaTitle: dbArticle.metaTitle || undefined,
          metaDescription: dbArticle.metaDescription || undefined,
          tags: dbArticle.tags ? dbArticle.tags.split(',').map((t) => t.trim()) : [],
        };
      }
    } catch {}
  }

  const articles = readArticlesFromFile();
  return articles.find((a) => a.slug === normalizedSlug || a.slug === slug) || null;
}

/**
 * Récupère un article par son ID
 */
export async function getArticleById(id: string): Promise<ArticleData | null> {
  const articles = readArticlesFromFile();
  return articles.find((a) => a.id === id) || null;
}

/**
 * Crée ou met à jour un article
 */
export async function saveArticle(
  input: Partial<ArticleData> & { title: string; content: string }
): Promise<ArticleData> {
  const articles = readArticlesFromFile();
  const nowStr = new Date().toISOString();

  const title = input.title.trim();
  const baseSlug = input.slug ? slugify(input.slug) : slugify(title);
  const excerpt =
    input.excerpt?.trim() ||
    input.content
      .replace(/[#*`_\[\]]/g, '')
      .split('\n')
      .filter(Boolean)[0]
      ?.substring(0, 180) + '...' ||
    'Actualité hippique TurfJournal.';

  const categorySlug = input.categorySlug || 'actualites';
  const categoryNamesMap: Record<string, string> = {
    actualites: 'Actualités Hippiques',
    quinte: 'Quinté+ & Grands Prix',
    guides: 'Guides & Stratégies',
    interviews: 'Interviews & Débriefings',
    'jeu-responsable': 'Jeu Responsable',
  };
  const categoryName = input.categoryName || categoryNamesMap[categorySlug] || 'Actualités Hippiques';

  const existingIndex = input.id
    ? articles.findIndex((a) => a.id === input.id)
    : articles.findIndex((a) => a.slug === baseSlug);

  let savedArticle: ArticleData;

  if (existingIndex >= 0) {
    // Mise à jour
    savedArticle = {
      ...articles[existingIndex],
      ...input,
      title,
      slug: baseSlug,
      excerpt,
      categorySlug,
      categoryName,
      isPublished: input.isPublished ?? true,
      metaTitle: input.metaTitle || `${title} | TurfJournal`,
      metaDescription: input.metaDescription || excerpt.substring(0, 155),
      tags: input.tags || articles[existingIndex].tags || ['actualités', 'pmu'],
    };
    articles[existingIndex] = savedArticle;
  } else {
    // Création d'un nouvel article
    savedArticle = {
      id: input.id || `art-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title,
      slug: baseSlug,
      excerpt,
      content: input.content,
      categorySlug,
      categoryName,
      featuredImage: input.featuredImage,
      isPublished: input.isPublished ?? true,
      publishedAt: input.publishedAt || nowStr,
      metaTitle: input.metaTitle || `${title} | TurfJournal`,
      metaDescription: input.metaDescription || excerpt.substring(0, 155),
      tags: input.tags || ['actualités', 'turf', 'pmu'],
    };
    articles.unshift(savedArticle);
  }

  // Sauvegarde dans le fichier JSON
  writeArticlesToFile(articles);

  // Sauvegarde synchrone dans PostgreSQL si accessible
  if (canUseDatabase()) {
    try {
      let category = await prisma.category.findUnique({ where: { slug: categorySlug } });
      if (!category) {
        category = await prisma.category.create({
          data: {
            name: categoryName,
            slug: categorySlug,
            description: `Articles de la catégorie ${categoryName}`,
          },
        });
      }

      await prisma.article.upsert({
        where: { slug: savedArticle.slug },
        update: {
          title: savedArticle.title,
          excerpt: savedArticle.excerpt,
          content: savedArticle.content,
          categoryId: category.id,
          featuredImage: savedArticle.featuredImage,
          isPublished: savedArticle.isPublished,
          publishedAt: new Date(savedArticle.publishedAt),
          metaTitle: savedArticle.metaTitle,
          metaDescription: savedArticle.metaDescription,
          tags: savedArticle.tags?.join(', '),
        },
        create: {
          id: savedArticle.id,
          title: savedArticle.title,
          slug: savedArticle.slug,
          excerpt: savedArticle.excerpt,
          content: savedArticle.content,
          categoryId: category.id,
          featuredImage: savedArticle.featuredImage,
          isPublished: savedArticle.isPublished,
          publishedAt: new Date(savedArticle.publishedAt),
          metaTitle: savedArticle.metaTitle,
          metaDescription: savedArticle.metaDescription,
          tags: savedArticle.tags?.join(', '),
        },
      });
    } catch (dbErr) {
      console.warn('Persistance PostgreSQL optionnelle non effectuée pour l\'article :', dbErr);
    }
  }

  return savedArticle;
}

/**
 * Supprime un article
 */
export async function deleteArticle(idOrSlug: string): Promise<boolean> {
  const articles = readArticlesFromFile();
  const initialLength = articles.length;
  const filtered = articles.filter((a) => a.id !== idOrSlug && a.slug !== idOrSlug);

  if (filtered.length !== initialLength) {
    writeArticlesToFile(filtered);

    if (canUseDatabase()) {
      try {
        await prisma.article.deleteMany({
          where: { OR: [{ id: idOrSlug }, { slug: idOrSlug }] },
        });
      } catch {}
    }
    return true;
  }
  return false;
}

/**
 * Génère automatiquement l'actualité hippique du jour basée sur les données réelles PMU
 */
export async function generateDailyNewsArticle(
  quinteRace: RaceData | null,
  targetDateStr?: string
): Promise<{ success: boolean; article: ArticleData; isNew: boolean }> {
  const todayStr = targetDateStr || new Date().toISOString().split('T')[0];
  const dateObj = new Date(todayStr + 'T12:00:00Z');
  const dateFr = dateObj.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const capitalizedDateFr = dateFr.charAt(0).toUpperCase() + dateFr.slice(1);

  const hippo = quinteRace?.hippodromeName || 'Vincennes';
  const raceName = quinteRace?.name || 'Grand Prix du Jour';
  const discipline = quinteRace?.discipline || 'Trot Attelé';
  const distance = quinteRace?.distance ? `${quinteRace.distance} mètres` : '2 700 mètres';
  const prize = quinteRace?.purse ? `${quinteRace.purse.toLocaleString('fr-FR')} €` : '53 000 €';
  const partants = quinteRace?.participants || [];
  const partantsCount = partants.length > 0 ? partants.length : 16;

  const targetSlug = `quinte-du-${todayStr}-${slugify(hippo)}`;

  // Vérifier si l'actualité du jour existe déjà
  const existing = await getArticleBySlug(targetSlug);
  if (existing) {
    return { success: true, article: existing, isNew: false };
  }

  // Analyser les chevaux en vue
  const topHorses = partants.slice(0, 4);
  const outsiders = partants.slice(4, 7);

  let favorisText = '';
  if (topHorses.length > 0) {
    favorisText = topHorses
      .map(
        (h) =>
          `- **N°${h.horseNumber} - ${h.horseName}** (${h.jockeyName || 'Driver/Jockey titulaire'}, entraîné par ${h.trainerName || 'Écurie'}) : Musique récente \`${h.music || 'Forme régulière'}\`. ${
            h.shoes ? `Équipé en ${h.shoes}. ` : ''
          }Présente des arguments solides pour jouer les premiers rôles.`
      )
      .join('\n');
  } else {
    favorisText =
      `- **N°4 - Idao de Tillard** : Véritable référence de la discipline, il détient les meilleurs chronos sur le parcours.\n` +
      `- **N°7 - Hooker Berry** : Très incisif lorsqu'il bénéficie d'une course cachée, son finish peut faire la différence.\n` +
      `- **N°11 - Ampia Mede Sm** : Grande spécialiste de la piste, toujours redoutable dans la phase finale.`;
  }

  let outsidersText = '';
  if (outsiders.length > 0) {
    outsidersText = outsiders
      .map(
        (h) =>
          `- **N°${h.horseNumber} - ${h.horseName}** : Belle opportunité à belle cote. Régulier, un accessit est largement à sa portée en cas de défaillance des favoris.`
      )
      .join('\n');
  } else {
    outsidersText =
      `- **N°2 - Go On Boy** : Capable de coups d'éclat spectaculaires avec un parcours limpide.\n` +
      `- **N°9 - Hussard du Landret** : Modèle de bravoure et d'engagement physique, à surveiller de près.`;
  }

  const title = `Quinté+ du ${capitalizedDateFr} à ${hippo} : Analyse du ${raceName} & Forces en Présence`;
  const excerpt = `Découvrez notre décryptage complet du Quinté+ de ce ${dateFr} sur l'hippodrome de ${hippo}. Analyse des conditions de course, étude des favoris et sélection des meilleurs outsiders du ${raceName}.`;

  const content = `L'événement quotidien du PMU nous emmène ce ${dateFr} sur l'hippodrome emblématique de **${hippo}** pour disputer le prestigieux **${raceName}**. 

Cette épreuve majeure réunira **${partantsCount} concurrents** chevronnés sur la distance de **${distance}**, pour une dotation globale de **${prize}**.

### 1. Le Contexte de l'Épreuve & Conditions de Course
Disputé en **${discipline}**, le ${raceName} s'annonce passionnant sur le tracé exigeant de ${hippo}. La gestion de l'effort et la qualité du déferrage seront les deux éléments clés qui scelleront l'ordre final du peloton.

Sur ce parcours, l'aptitude à tenir le rythme et la fraîcheur physique des partants priment. Les concurrents devront faire preuve de maniabilité pour éviter les pièges du trafic.

### 2. Les Favoris du Jour & Concurrents en Vue
La rédaction de TurfJournal a sélectionné les concurrents présentant le profil statistique et la dynamique de forme la plus favorable :

${favorisText}

### 3. Les Bons Outsiders & Faiseurs de Trouble
Pour vos combinaisons élargies au Quarté ou Quinté+, certains partants méritent une attention particulière :

${outsidersText}

### 4. La Synthèse & Conseils de la Rédaction
Le ${raceName} s'annonce ouvert et spectaculaire. Privilégiez les concurrents confirmés sur la distance et attentifs aux ordres de départ. 

*Rappel éthique : Le pari hippique reste soumis aux aléas du sport. Fixez-vous des limites de jeu saines et privilégiez le plaisir de l'analyse hippique.*`;

  const saved = await saveArticle({
    title,
    slug: targetSlug,
    excerpt,
    content,
    categorySlug: 'actualites',
    categoryName: 'Quinté+ & Grands Prix',
    isPublished: true,
    publishedAt: new Date().toISOString(),
    tags: ['quinté+', 'actualités', hippo.toLowerCase(), 'pmu', 'analyse'],
    metaTitle: `Quinté+ ${dateFr} ${hippo} : Pronostics et Analyse du ${raceName}`,
    metaDescription: excerpt.substring(0, 155),
  });

  return { success: true, article: saved, isNew: true };
}

// Helpers internes de lecture/écriture fichier JSON
function readArticlesFromFile(): ArticleData[] {
  if (memoryArticles) return memoryArticles;

  try {
    if (fs.existsSync(ARTICLES_FILE_PATH)) {
      const raw = fs.readFileSync(ARTICLES_FILE_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        memoryArticles = parsed;
        return memoryArticles!;
      }
    }
  } catch (err) {
    console.warn('Erreur lecture articles.json :', err);
  }

  // Si le fichier n'existe pas ou est vide, initialiser avec les articles par défaut
  memoryArticles = [...DEFAULT_ARTICLES];
  writeArticlesToFile(memoryArticles);
  return memoryArticles;
}

function writeArticlesToFile(articles: ArticleData[]) {
  try {
    const dir = path.dirname(ARTICLES_FILE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(ARTICLES_FILE_PATH, JSON.stringify(articles, null, 2), 'utf-8');
    memoryArticles = articles;
  } catch (err) {
    console.error('Erreur écriture articles.json :', err);
  }
}

export function clearArticlesMemoryCache(): void {
  memoryArticles = null;
}
