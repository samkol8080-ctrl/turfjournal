import prisma from './prisma';
import { pmuService, PmuService } from './api/pmu';
import { generateRacePrediction } from './prediction-engine';
import {
  MeetingData,
  RaceData,
  HorseData,
  JockeyData,
  TrainerData,
  ArticleData,
  AdPlacementData,
  SyncLogData,
} from '@/types/racing';
import { getAllArticles, getArticleBySlug as getServiceArticleBySlug } from './article-service';

export { formatDateToPmu } from './api/pmu';

export async function isDatabaseConnected(): Promise<boolean> {
  if (!process.env.DATABASE_URL) return false;
  try {
    await prisma.$queryRaw`SELECT 1`;
    return true;
  } catch {
    return false;
  }
}

/**
 * Récupère les réunions et courses réelles pour une date donnée (format YYYY-MM-DD)
 * ZÉRO donnée fictive : interroge PostgreSQL ou directement l'API officielle PMU.
 */
export async function getMeetingsForDate(dateStr: string): Promise<{
  meetings: MeetingData[];
  isDemo: boolean;
  isAvailable: boolean;
  error?: string;
}> {
  const dbOk = await isDatabaseConnected();

  // 1. Tenter la lecture depuis PostgreSQL si connecté
  if (dbOk) {
    try {
      const targetDate = new Date(dateStr);
      const nextDay = new Date(targetDate);
      nextDay.setDate(nextDay.getDate() + 1);

      const dbMeetings = await prisma.meeting.findMany({
        where: {
          date: {
            gte: targetDate,
            lt: nextDay,
          },
        },
        include: {
          hippodrome: true,
          races: {
            include: {
              participants: {
                include: {
                  horse: true,
                  jockey: true,
                  trainer: true,
                },
                orderBy: { horseNumber: 'asc' },
              },
              prediction: true,
              result: true,
            },
            orderBy: { raceNumber: 'asc' },
          },
        },
      });

      if (dbMeetings.length > 0) {
        const meetings: MeetingData[] = dbMeetings.map((m) => ({
          id: m.id,
          code: m.code,
          name: m.name,
          date: dateStr,
          hippodromeName: m.hippodrome.name,
          city: m.hippodrome.city,
          surface: m.hippodrome.surface || undefined,
          trackType: m.hippodrome.trackType || undefined,
          status: m.status as any,
          races: m.races.map((r) => {
            let predictionParsed;
            if (r.prediction?.topPicksJson) {
              try {
                predictionParsed = {
                  id: r.prediction.id,
                  raceId: r.id,
                  confidenceScore: r.prediction.confidenceScore,
                  summaryText: r.prediction.summaryText,
                  topPicks: JSON.parse(r.prediction.topPicksJson),
                  isPublic: r.prediction.isPublic,
                  generatedAt: r.prediction.generatedAt.toISOString(),
                };
              } catch {}
            }

            return {
              id: r.id,
              meetingCode: m.code,
              meetingName: m.name,
              hippodromeName: m.hippodrome.name,
              hippodromeCity: m.hippodrome.city,
              raceNumber: r.raceNumber,
              name: r.name,
              slug: r.slug,
              discipline: r.discipline as any,
              distance: r.distance,
              purse: r.purse || undefined,
              conditions: r.conditions || undefined,
              scheduledAt: r.scheduledAt.toISOString(),
              status: r.status as any,
              isQuinte: r.isQuinte,
              isPick5: r.isPick5,
              trackSurface: r.trackSurface || undefined,
              participants: r.participants.map((p) => ({
                id: p.id,
                horseNumber: p.horseNumber,
                horseId: p.horse.id,
                horseName: p.horse.name,
                horseAge: p.horse.age || undefined,
                horseSex: p.horse.sex || undefined,
                sire: p.horse.sire || undefined,
                dam: p.horse.dam || undefined,
                jockeyId: p.jockey?.id,
                jockeyName: p.jockey?.name || 'Driver/Jockey',
                trainerId: p.trainer?.id,
                trainerName: p.trainer?.name || 'Entraîneur',
                draw: p.draw || undefined,
                weight: p.weight || undefined,
                blinkers: p.blinkers || undefined,
                shoes: p.shoes || undefined,
                oddsMorning: p.oddsMorning || undefined,
                oddsCurrent: p.oddsCurrent || undefined,
                music: p.music || undefined,
                finalPosition: p.finalPosition || undefined,
                status: p.status as any,
              })),
              prediction: predictionParsed,
              result: r.result
                ? {
                    id: r.result.id,
                    raceId: r.id,
                    arrivalOrder: r.result.arrivalOrder,
                    reportSimpleGagnant: r.result.reportSimpleGagnant || undefined,
                    reportSimplePlace: r.result.reportSimplePlace || undefined,
                    reportQuinte: r.result.reportQuinte || undefined,
                    comment: r.result.comment || undefined,
                    verifiedAt: r.result.verifiedAt.toISOString(),
                  }
                : undefined,
            };
          }),
        }));

        return { meetings, isDemo: false, isAvailable: true };
      }
    } catch (e) {
      console.warn('Lecture DB impossible, interrogation directe de l\'API PMU :', e);
    }
  }

  // 2. Interroger directement le service officiel PMU
  const pmuResult = await pmuService.getDailyProgramme(dateStr);

  return {
    meetings: pmuResult.meetings,
    isDemo: false,
    isAvailable: pmuResult.isAvailable,
    error: pmuResult.error,
  };
}

/**
 * Récupère une course précise par son slug avec ses partants réels officiels
 * ZÉRO donnée factice.
 */
export async function getRaceBySlug(
  slug: string,
  dateStr: string = new Date().toISOString().split('T')[0]
): Promise<{ race: RaceData | null; isDemo: boolean; isAvailable: boolean }> {
  const { meetings, isAvailable } = await getMeetingsForDate(dateStr);

  if (!isAvailable || meetings.length === 0) {
    return { race: null, isDemo: false, isAvailable: false };
  }

  let matchedRace: RaceData | null = null;
  let rNum = 1;
  let cNum = 1;

  // Extraction du numéro de réunion et de course depuis le slug (ex: "r1-c1-..." ou "2026-11-20-r1c1-...")
  const slugMatch = slug.match(/r(\d+)[-c](\d+)/i) || slug.match(/r(\d+)c(\d+)/i);
  if (slugMatch) {
    rNum = parseInt(slugMatch[1], 10);
    cNum = parseInt(slugMatch[2], 10);
  }

  // Recherche dans les réunions réelles
  for (const m of meetings) {
    const meetingNum = parseInt(m.code.replace('R', ''), 10);
    for (const r of m.races) {
      if (
        r.slug === slug ||
        r.id === slug ||
        (meetingNum === rNum && r.raceNumber === cNum)
      ) {
        matchedRace = r;
        rNum = meetingNum;
        cNum = r.raceNumber;
        break;
      }
    }
    if (matchedRace) break;
  }

  if (matchedRace) {
    // Si les partants ne sont pas encore chargés, interroger l'API officielle PMU
    if (matchedRace.participants.length === 0) {
      try {
        const parts = await pmuService.getParticipants(dateStr, rNum, cNum);
        if (parts.length > 0) {
          matchedRace.participants = parts;
          matchedRace.prediction = generateRacePrediction(
            matchedRace.id,
            matchedRace.name,
            matchedRace.discipline,
            parts
          );
        }
      } catch (err) {
        console.warn(`[PMU] Impossible de charger les partants pour ${slug}:`, err);
      }
    } else if (!matchedRace.prediction && matchedRace.participants.length > 0) {
      matchedRace.prediction = generateRacePrediction(
        matchedRace.id,
        matchedRace.name,
        matchedRace.discipline,
        matchedRace.participants
      );
    }

    // Si la course est terminée, charger les résultats officiels et dividendes PMU
    if (matchedRace.status === 'FINISHED' || !matchedRace.result) {
      try {
        const res = await pmuService.getRaceResult(dateStr, rNum, cNum);
        if (res && res.arrivalOrder) {
          matchedRace.status = 'FINISHED';
          matchedRace.result = {
            id: `res-${matchedRace.id}`,
            raceId: matchedRace.id,
            arrivalOrder: res.arrivalOrder,
            reportSimpleGagnant: res.reportSimpleGagnant,
            reportSimplePlace: res.reportSimplePlace,
            reportQuinte: res.reportQuinte,
            comment: res.comment,
            verifiedAt: new Date().toISOString(),
          };
        }
      } catch (repErr) {
        console.warn(`[PMU] Rapports non disponibles pour ${slug}:`, repErr);
      }
    }

    return { race: matchedRace, isDemo: false, isAvailable: true };
  }

  return { race: null, isDemo: false, isAvailable: true };
}

/**
 * Récupère le Quinté+ officiel du jour avec partants réels et cotes
 * ZÉRO donnée factice.
 */
export async function getTodayQuinte(
  dateStr: string = new Date().toISOString().split('T')[0]
): Promise<{ race: RaceData | null; isDemo: boolean; isAvailable: boolean }> {
  const result = await pmuService.getTodayQuinte(dateStr);

  if (!result.isAvailable || !result.race) {
    return { race: null, isDemo: false, isAvailable: result.isAvailable };
  }

  const quinteRace = result.race;

  // Générer la prédiction algorithmique si partants présents
  if (quinteRace.participants.length > 0 && !quinteRace.prediction) {
    quinteRace.prediction = generateRacePrediction(
      quinteRace.id,
      quinteRace.name,
      quinteRace.discipline,
      quinteRace.participants
    );
  }

  // Vérifier les résultats officiels si terminée
  if (quinteRace.status === 'FINISHED') {
    const rNum = result.meeting ? parseInt(result.meeting.code.replace('R', ''), 10) : 1;
    const raceRes = await pmuService.getRaceResult(dateStr, rNum, quinteRace.raceNumber);
    if (raceRes && raceRes.arrivalOrder) {
      quinteRace.result = {
        id: `res-${quinteRace.id}`,
        raceId: quinteRace.id,
        arrivalOrder: raceRes.arrivalOrder,
        reportSimpleGagnant: raceRes.reportSimpleGagnant,
        reportSimplePlace: raceRes.reportSimplePlace,
        reportQuinte: raceRes.reportQuinte,
        comment: raceRes.comment,
        verifiedAt: new Date().toISOString(),
      };
    }
  }

  return { race: quinteRace, isDemo: false, isAvailable: true };
}

/**
 * Récupère la liste de tous les résultats récents réels avec ordres d'arrivée officiels
 */
export async function getRecentResults(
  dateStr: string = new Date().toISOString().split('T')[0]
): Promise<{ races: RaceData[]; isDemo: boolean; isAvailable: boolean }> {
  const { meetings, isAvailable } = await getMeetingsForDate(dateStr);
  const finishedRaces: RaceData[] = [];

  if (!isAvailable || meetings.length === 0) {
    return { races: [], isDemo: false, isAvailable: false };
  }

  for (const m of meetings) {
    const rNum = parseInt(m.code.replace('R', ''), 10);
    for (const r of m.races) {
      if (r.status === 'FINISHED') {
        // Charger les résultats détaillés si nécessaire
        if (!r.result) {
          const res = await pmuService.getRaceResult(dateStr, rNum, r.raceNumber);
          if (res && res.arrivalOrder) {
            r.result = {
              id: `res-${r.id}`,
              raceId: r.id,
              arrivalOrder: res.arrivalOrder,
              reportSimpleGagnant: res.reportSimpleGagnant,
              reportSimplePlace: res.reportSimplePlace,
              reportQuinte: res.reportQuinte,
              comment: res.comment,
              verifiedAt: new Date().toISOString(),
            };
          }
        }
        finishedRaces.push(r);
      }
    }
  }

  return { races: finishedRaces, isDemo: false, isAvailable: true };
}

/**
 * Récupère la fiche d'un cheval à partir des données réelles
 * ZÉRO invention de victoires ou gains fictifs.
 */
export async function getHorseProfile(horseId: string): Promise<HorseData | null> {
  const cleanId = decodeURIComponent(horseId.replace(/^horse-/, '').replace(/-/g, ' ')).toUpperCase();

  // 1. Tenter la recherche dans PostgreSQL
  if (await isDatabaseConnected()) {
    try {
      const dbHorse = await prisma.horse.findFirst({
        where: {
          OR: [
            { id: horseId },
            { name: { contains: cleanId, mode: 'insensitive' } },
          ],
        },
        include: { trainer: true },
      });

      if (dbHorse) {
        return {
          id: dbHorse.id,
          name: dbHorse.name,
          sex: dbHorse.sex || undefined,
          age: dbHorse.age || undefined,
          breed: dbHorse.breed || undefined,
          sire: dbHorse.sire || undefined,
          dam: dbHorse.dam || undefined,
          owner: dbHorse.owner || undefined,
          trainerName: dbHorse.trainer?.name || undefined,
          careerWins: dbHorse.careerWins,
          careerPlaces: dbHorse.careerPlaces,
          careerRuns: dbHorse.careerRuns,
          careerEarnings: dbHorse.careerEarnings,
        };
      }
    } catch {}
  }

  // 2. Recherche parmi tous les partants officiels des réunions du jour
  const todayStr = new Date().toISOString().split('T')[0];
  const { meetings } = await getMeetingsForDate(todayStr);
  const allParticipants = meetings.flatMap((m) => m.races.flatMap((r) => r.participants));
  const match = allParticipants.find(
    (p) => p.horseId === horseId || p.horseName.toUpperCase() === cleanId || p.horseName.toUpperCase().replace(/\s+/g, '-') === cleanId.replace(/\s+/g, '-')
  );
  if (match) {
    return {
      id: horseId,
      name: match.horseName,
      sex: match.horseSex,
      age: match.horseAge,
      breed: 'Trotteur Français / Pur-Sang',
      sire: match.sire,
      dam: match.dam,
      trainerName: match.trainerName,
      careerWins: 0,
      careerPlaces: 0,
      careerRuns: 0,
      careerEarnings: 0,
    };
  }

  // 3. Recherche dans les partants de demain
  const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  const { meetings: tomorrowMeetings } = await getMeetingsForDate(tomorrowStr);
  const tomorrowParts = tomorrowMeetings.flatMap((m) => m.races.flatMap((r) => r.participants));
  const tomorrowMatch = tomorrowParts.find(
    (p) => p.horseId === horseId || p.horseName.toUpperCase() === cleanId || p.horseName.toUpperCase().replace(/\s+/g, '-') === cleanId.replace(/\s+/g, '-')
  );
  if (tomorrowMatch) {
    return {
      id: horseId,
      name: tomorrowMatch.horseName,
      sex: tomorrowMatch.horseSex,
      age: tomorrowMatch.horseAge,
      breed: 'Trotteur Français / Pur-Sang',
      sire: tomorrowMatch.sire,
      dam: tomorrowMatch.dam,
      trainerName: tomorrowMatch.trainerName,
      careerWins: 0,
      careerPlaces: 0,
      careerRuns: 0,
      careerEarnings: 0,
    };
  }

  // 4. Si nom valide, retourner la fiche indexable
  if (cleanId.length >= 2) {
    return {
      id: horseId,
      name: cleanId,
      breed: 'Cheval de Course PMU',
      careerWins: 0,
      careerPlaces: 0,
      careerRuns: 0,
      careerEarnings: 0,
    };
  }

  return null;
}

/**
 * Récupère la fiche d'un jockey / driver depuis les données réelles
 */
export async function getJockeyProfile(jockeyId: string): Promise<JockeyData | null> {
  const cleanName = decodeURIComponent(jockeyId.replace(/^jock-/, '').replace(/-/g, ' ')).toUpperCase();

  if (await isDatabaseConnected()) {
    try {
      const dbJockey = await prisma.jockey.findFirst({
        where: {
          OR: [
            { id: jockeyId },
            { name: { contains: cleanName, mode: 'insensitive' } },
          ],
        },
      });

      if (dbJockey) {
        return {
          id: dbJockey.id,
          name: dbJockey.name,
          wins: dbJockey.wins,
          places: dbJockey.places,
          rides: dbJockey.rides,
          winRate: dbJockey.winRate,
        };
      }
    } catch {}
  }

  return {
    id: jockeyId,
    name: cleanName,
    wins: 0,
    places: 0,
    rides: 0,
    winRate: 0,
  };
}

/**
 * Récupère la fiche d'un entraîneur depuis les données réelles
 */
export async function getTrainerProfile(trainerId: string): Promise<TrainerData | null> {
  const cleanName = decodeURIComponent(trainerId.replace(/^train-/, '').replace(/-/g, ' ')).toUpperCase();

  if (await isDatabaseConnected()) {
    try {
      const dbTrainer = await prisma.trainer.findFirst({
        where: {
          OR: [
            { id: trainerId },
            { name: { contains: cleanName, mode: 'insensitive' } },
          ],
        },
      });

      if (dbTrainer) {
        return {
          id: dbTrainer.id,
          name: dbTrainer.name,
          wins: dbTrainer.wins,
          places: dbTrainer.places,
          runners: dbTrainer.runners,
          winRate: dbTrainer.winRate,
        };
      }
    } catch {}
  }

  return {
    id: trainerId,
    name: cleanName,
    wins: 0,
    places: 0,
    runners: 0,
    winRate: 0,
  };
}

export async function getArticles(categorySlug?: string): Promise<ArticleData[]> {
  return getAllArticles({ categorySlug });
}

export async function getArticleBySlug(slug: string): Promise<ArticleData | null> {
  return getServiceArticleBySlug(slug);
}

export async function getAdPlacements(): Promise<AdPlacementData[]> {
  return [];
}

export async function getSyncLogs(): Promise<SyncLogData[]> {
  if (await isDatabaseConnected()) {
    try {
      const logs = await prisma.syncLog.findMany({
        orderBy: { startedAt: 'desc' },
        take: 20,
      });
      return logs.map((l) => ({
        id: l.id,
        provider: l.provider,
        status: l.status as any,
        itemsSynced: l.itemsSynced,
        details: l.details || undefined,
        startedAt: l.startedAt.toISOString(),
        completedAt: l.completedAt ? l.completedAt.toISOString() : undefined,
      }));
    } catch {}
  }

  return [];
}
