/**
 * Client d'intégration officiel PMU
 * Ce service s'appuie directement sur le service dédié src/lib/api/pmu.ts.
 * AUCUNE donnée fictive, simulée ou inventée n'est générée.
 * En cas d'indisponibilité du fournisseur, le statut d'erreur explicite est renvoyé.
 */

import { MeetingData, ParticipantData } from '@/types/racing';
import { pmuService, PmuService } from './api/pmu';

export { formatDateToPmu } from './api/pmu';

export interface RacingApiConfig {
  apiUrl: string;
  apiKey: string;
  isDemoMode: boolean;
  timeoutMs: number;
}

export class RacingApiClient {
  private pmu: PmuService;

  constructor() {
    this.pmu = pmuService;
  }

  public static clearCache(): void {
    pmuService.clearCache();
  }

  public getConfig(): RacingApiConfig {
    return {
      apiUrl: process.env.RACING_API_URL || 'https://offline.turfinfo.api.pmu.fr/rest/client/7/programme',
      apiKey: process.env.RACING_API_KEY || '',
      isDemoMode: false,
      timeoutMs: 10000,
    };
  }

  /**
   * Test de connectivité avec l'API officielle PMU
   */
  public async testConnection(): Promise<{ success: boolean; message: string; latencyMs: number }> {
    return this.pmu.testConnection();
  }

  /**
   * Récupère les réunions réelles du jour depuis l'API officielle PMU
   */
  public async getDailyMeetings(dateStr: string): Promise<{
    meetings: MeetingData[];
    isDemo: boolean;
    isAvailable: boolean;
    error?: string;
  }> {
    const result = await this.pmu.getDailyProgramme(dateStr);

    return {
      meetings: result.meetings,
      isDemo: false,
      isAvailable: result.isAvailable,
      error: result.error,
    };
  }

  /**
   * Récupère les partants réels officiels d'une course depuis le PMU
   */
  public async getRaceParticipants(
    dateStr: string,
    meetingNum: number,
    raceNum: number
  ): Promise<ParticipantData[]> {
    return this.pmu.getParticipants(dateStr, meetingNum, raceNum);
  }

  /**
   * Récupère les rapports officiels définitifs d'une course terminée
   */
  public async getRaceReports(
    dateStr: string,
    meetingNum: number,
    raceNum: number
  ): Promise<{
    reportSimpleGagnant?: number;
    reportSimplePlace?: number;
    reportQuinte?: number;
  }> {
    const res = await this.pmu.getRaceResult(dateStr, meetingNum, raceNum);
    return {
      reportSimpleGagnant: res?.reportSimpleGagnant,
      reportSimplePlace: res?.reportSimplePlace,
      reportQuinte: res?.reportQuinte,
    };
  }
}

/**
 * Fonction de compatibilité sans aucune donnée factice
 */
export function generateDemoMeetings(dateStr: string): MeetingData[] {
  console.warn(`[PMU] Aucune donnée fictive autorisée pour la date ${dateStr}. Données réelles exigées.`);
  return [];
}
