import React from 'react';

interface LogoProps {
  variant?: 'full' | 'icon' | 'compact';
  theme?: 'light' | 'dark' | 'auto';
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
}

export default function Logo({
  variant = 'full',
  theme = 'light',
  className = '',
  size = 'md',
  showTagline = true,
}: LogoProps) {
  const iconSizes = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12',
  };

  const textSizes = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-3xl',
  };

  const isDark = theme === 'dark';

  const iconElement = (
    <div
      className={`relative ${iconSizes[size]} rounded-2xl bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-900 flex items-center justify-center p-2 shadow-md shadow-emerald-950/20 ring-1 ring-white/20 flex-shrink-0 group-hover:scale-105 group-hover:shadow-emerald-600/30 transition-all duration-300`}
    >
      {/* Background Subtle Track Glow */}
      <div className="absolute inset-0 rounded-2xl bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-amber-400/20 via-transparent to-transparent pointer-events-none" />

      {/* Modern Vector Galloping Horse & Motion Lines */}
      <svg
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full relative z-10 drop-shadow-sm"
      >
        <defs>
          <linearGradient id="goldAccent" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FDE047" />
            <stop offset="100%" stopColor="#F59E0B" />
          </linearGradient>
          <linearGradient id="whiteShine" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#E2E8F0" />
          </linearGradient>
        </defs>

        {/* Speed motion stripes */}
        <path
          d="M6 34 L18 34"
          stroke="url(#goldAccent)"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity="0.8"
        />
        <path
          d="M10 40 L22 40"
          stroke="url(#goldAccent)"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity="0.6"
        />

        {/* Stylized Modern Thoroughbred Silhouette */}
        <path
          d="M48 14 C44 14, 40 16, 37 19 L32 24 C29 22, 25 21, 21 23 C19 24, 18 26, 19 28 C20 30, 23 31, 26 31 L32 31 L26 42 C25 44, 26 47, 28 48 C30 49, 33 48, 35 45 L41 35 L44 38 L42 46 C41 48, 43 50, 45 50 C47 50, 49 48, 50 45 L53 34 C55 31, 56 27, 56 23 C56 18, 52 14, 48 14 Z"
          fill="url(#whiteShine)"
        />

        {/* Jockey Helmet / Head in Golden Laurel Accent */}
        <circle cx="34" cy="18" r="4.5" fill="url(#goldAccent)" />

        {/* Dynamic Forward Mane Flare */}
        <path
          d="M45 16 C47 20, 50 21, 53 22 C51 18, 49 16, 45 16 Z"
          fill="url(#goldAccent)"
        />
      </svg>
    </div>
  );

  if (variant === 'icon') {
    return <div className={`inline-flex items-center ${className}`}>{iconElement}</div>;
  }

  return (
    <div className={`inline-flex items-center space-x-3 group ${className}`}>
      {iconElement}

      <div className="flex flex-col justify-center">
        <div className="flex items-center tracking-tight leading-none">
          <span
            className={`font-black ${textSizes[size]} tracking-tight ${
              isDark ? 'text-white' : 'text-slate-950'
            }`}
          >
            TURF
          </span>
          <span
            className={`font-black ${textSizes[size]} tracking-tight ml-1 bg-gradient-to-r ${
              isDark
                ? 'from-emerald-400 to-teal-300'
                : 'from-emerald-700 via-emerald-600 to-teal-600'
            } bg-clip-text text-transparent`}
          >
            JOURNAL
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 ml-1 mb-2 inline-block animate-pulse" />
        </div>

        {showTagline && variant !== 'compact' && (
          <p
            className={`text-[9.5px] uppercase font-black tracking-widest mt-0.5 hidden sm:block ${
              isDark ? 'text-emerald-400/80' : 'text-slate-500'
            }`}
          >
            L&apos;Information Hippique en Direct
          </p>
        )}
      </div>
    </div>
  );
}
