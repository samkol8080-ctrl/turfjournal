import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface ApiStatusBannerProps {
  show?: boolean;
  message?: string;
}

export default function DemoBanner({
  show = false,
  message = 'Les données PMU sont temporairement indisponibles.',
}: ApiStatusBannerProps) {
  if (!show) return null;

  return (
    <div className="bg-amber-50 border-b border-amber-300 py-3 px-4">
      <div className="max-w-7xl mx-auto flex items-center justify-center text-center text-xs">
        <div className="flex items-center space-x-2 text-amber-900 font-semibold">
          <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
          <span>{message}</span>
        </div>
      </div>
    </div>
  );
}
