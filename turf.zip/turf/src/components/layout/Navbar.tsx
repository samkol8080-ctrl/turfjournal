'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Logo from '@/components/common/Logo';
import { 
  Home,
  Calendar, 
  Sparkles, 
  Award, 
  BookOpen, 
  Menu, 
  X, 
  ChevronRight,
  TrendingUp,
  Flame
} from 'lucide-react';

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  const navLinks = [
    { name: 'Accueil', href: '/', icon: Home },
    { name: 'Programme', href: '/programme', icon: Calendar },
    { name: 'Pronostics Quinté+', href: '/pronostics', icon: Sparkles, highlight: true },
    { name: 'Résultats', href: '/resultats', icon: Award },
    { name: 'Actualités', href: '/actualites', icon: TrendingUp },
    { name: 'Guides', href: '/guides', icon: BookOpen },
  ];

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-2 sm:gap-4">
          {/* Logo & Brand */}
          <Link href="/" className="inline-block group focus:outline-none shrink-0">
            <Logo size="md" showTagline={true} />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1 bg-slate-100/90 p-1.5 rounded-2xl border border-slate-200/60 shadow-xs shrink-0">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const active = isActive(link.href);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex items-center space-x-2 px-3 xl:px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150 ${
                    active
                      ? 'bg-emerald-700 text-white shadow-xs font-black'
                      : link.highlight
                      ? 'text-amber-800 hover:bg-amber-100/70 hover:text-amber-900 bg-amber-50/70'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${active ? 'text-white' : link.highlight ? 'text-amber-600' : 'text-slate-500'}`} />
                  <span>{link.name}</span>
                  {link.highlight && !active && (
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right Action Bar */}
          <div className="flex items-center space-x-2 shrink-0">
            {/* Direct Quinté+ */}
            <div className="flex items-center space-x-2">
              <Link
                href="/pronostic-quinte-du-jour"
                className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 text-xs font-black shadow-xs transition-all hover:scale-102"
              >
                <Flame className="w-4 h-4 text-slate-950" />
                <span className="hidden sm:inline">Quinté+ du Jour</span>
                <span className="sm:hidden">Quinté+</span>
              </Link>
            </div>

            {/* Mobile menu trigger */}
            <div className="flex lg:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-xl text-slate-700 hover:text-slate-900 hover:bg-slate-100 focus:outline-none transition-colors cursor-pointer"
                aria-label="Menu principal"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white/98 backdrop-blur-xl border-b border-slate-200 px-4 pt-3 pb-6 space-y-3 shadow-xl">
          {/* Links list */}
          <div className="space-y-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const active = isActive(link.href);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-bold transition-colors ${
                    active
                      ? 'bg-emerald-700 text-white shadow-xs font-black'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className={`w-4 h-4 ${active ? 'text-white' : link.highlight ? 'text-amber-500' : 'text-emerald-700'}`} />
                    <span>{link.name}</span>
                    {link.highlight && !active && (
                      <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-black uppercase">
                        Quinté
                      </span>
                    )}
                  </div>
                  <ChevronRight className={`w-4 h-4 ${active ? 'text-white/70' : 'text-slate-400'}`} />
                </Link>
              );
            })}
          </div>

          {/* Mobile CTA Button */}
          <div className="pt-2 border-t border-slate-100">
            <Link
              href="/pronostic-quinte-du-jour"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs shadow-xs"
            >
              <Flame className="w-4 h-4 text-slate-950" />
              <span>Accéder au Quinté+ du Jour</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

