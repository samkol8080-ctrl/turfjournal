import React from 'react';
import Link from 'next/link';
import Logo from '@/components/common/Logo';
import { Trophy, ShieldAlert, Globe, ExternalLink } from 'lucide-react';

export default function Footer() {
  const currentYear = 2026;

  return (
    <footer className="bg-slate-900 border-t border-slate-800 text-slate-300 text-sm">
      {/* Responsible Gambling Warning Banner */}
      <div className="bg-slate-950 border-b border-slate-800/80 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-3 text-amber-400">
              <ShieldAlert className="w-5 h-5 flex-shrink-0 text-amber-400" />
              <div className="text-xs sm:text-sm">
                <span className="font-bold text-white uppercase tracking-wider block">
                  Jeu Responsable & Prévention de l&apos;Addiction
                </span>
                <span className="text-slate-300">
                  Les jeux d&apos;argent sont strictement interdits aux mineurs. Jouer comporte des risques : endettement, isolement, dépendance.
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-3 flex-shrink-0">
              <a
                href="https://www.joueurs-info-service.fr"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white text-xs border border-white/20 transition-colors"
              >
                <span>Joueurs Info Service : <strong>09 74 75 13 13</strong></span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Col 1: Brand & Presentation */}
          <div className="lg:col-span-2 space-y-4">
            <Link href="/" className="inline-block group focus:outline-hidden">
              <Logo theme="dark" size="md" showTagline={true} />
            </Link>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              turfjournal.com est un média d&apos;information hippique et d&apos;analyse statistique indépendant. Données vérifiées, arrivées officielles et pronostics mathématiques pour la France, le Maroc, la Belgique, la Suisse et le monde francophone.
            </p>
            <div className="flex items-center space-x-4 text-xs text-slate-400 pt-2">
              <span className="flex items-center space-x-1">
                <Globe className="w-3.5 h-3.5 text-emerald-400" />
                <span>FR / MA / BE / CH</span>
              </span>
              <span>•</span>
              <span>100% Indépendant</span>
            </div>
          </div>

          {/* Col 2: Navigation Rapide */}
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-b border-slate-800 pb-1">
              Courses & Paris
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <Link href="/pronostic-quinte-du-jour" className="hover:text-emerald-400 font-bold text-white transition-colors flex items-center space-x-1">
                  <span>Pronostic Quinté du Jour</span>
                </Link>
              </li>
              <li>
                <Link href="/quinte-de-demain" className="hover:text-amber-400 text-amber-300 font-bold transition-colors flex items-center space-x-1">
                  <span>Quinté de Demain (J-1)</span>
                </Link>
              </li>
              <li>
                <Link href="/programme" className="hover:text-emerald-400 transition-colors">
                  Programme des courses du jour
                </Link>
              </li>
              <li>
                <Link href="/pronostics" className="hover:text-emerald-400 transition-colors">
                  Pronostics Quinté+ & Événements
                </Link>
              </li>
              <li>
                <Link href="/resultats" className="hover:text-emerald-400 transition-colors">
                  Arrivées et Rapports officiels
                </Link>
              </li>
              <li>
                <Link href="/actualites" className="hover:text-emerald-400 transition-colors">
                  Actualités des hippodromes
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Guides & Méthodes */}
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-b border-slate-800 pb-1">
              Guides & Apprentissage
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <Link href="/guides/comment-analyser-la-musique-d-un-cheval" className="hover:text-emerald-400 transition-colors">
                  Comprendre la musique d&apos;un cheval
                </Link>
              </li>
              <li>
                <Link href="/guides/comprendre-le-quinte-plus-fonctionnement-et-rapports" className="hover:text-emerald-400 transition-colors">
                  Guide pratique du Quinté+
                </Link>
              </li>
              <li>
                <Link href="/guides/trot-plat-obstacle-differences-et-analyses" className="hover:text-emerald-400 transition-colors">
                  Trot, Plat et Obstacle
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-emerald-400 transition-colors">
                  Foire Aux Questions (FAQ)
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Légal & Conformité */}
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-b border-slate-800 pb-1">
              Transparence & Légal
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <Link href="/a-propos" className="hover:text-emerald-400 transition-colors">
                  À propos de TurfJournal
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-emerald-400 transition-colors">
                  Contactez la rédaction
                </Link>
              </li>
              <li>
                <Link href="/mentions-legales" className="hover:text-emerald-400 transition-colors">
                  Mentions légales
                </Link>
              </li>
              <li>
                <Link href="/politique-confidentialite" className="hover:text-emerald-400 transition-colors">
                  Politique de confidentialité (RGPD)
                </Link>
              </li>
              <li>
                <Link href="/politique-cookies" className="hover:text-emerald-400 transition-colors">
                  Gestion des cookies
                </Link>
              </li>
              <li>
                <Link href="/jeu-responsable" className="hover:text-amber-400 transition-colors font-medium">
                  Jeu Responsable & Aide
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Legal Disclaimer Box */}
        <div className="mt-10 pt-8 border-t border-slate-800 text-[11px] leading-relaxed text-slate-400 text-justify">
          <p>
            <strong>Avertissement Légal & Risque Financier :</strong> turfjournal.com est un site de presse et d&apos;information hippique entièrement gratuit. turfjournal.com n&apos;est pas un opérateur de jeux en ligne et ne prend aucun pari d&apos;argent. Les pronostics, indices de forme et analyses mathématiques diffusés sur ce site sont délivrés à titre purement indicatif et statistique. Les courses hippiques comportent un aléa intrinsèque et aucune analyse ne saurait garantir de gain financier. Ne misez jamais d&apos;argent dont vous auriez besoin pour vivre.
          </p>
        </div>

        {/* Copyright */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <p>© {currentYear} turfjournal.com. Tous droits réservés.</p>
          <p>Plateforme hébergée aux normes européennes de protection des données (RGPD).</p>
        </div>
      </div>
    </footer>
  );
}

