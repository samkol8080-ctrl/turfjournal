'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { ExternalLink } from 'lucide-react';

interface AdBannerProps {
  slotId?: string;
  format?: 'auto' | 'horizontal' | 'rectangle' | 'vertical';
  className?: string;
  label?: string;
}

interface BannerConfigState {
  adsEnabled: boolean;
  activeClientId: string;
  partnerSpaceEnabled: boolean;
  partnerBannerText: string;
  partnerBannerLink: string;
  badgeLabel: string;
}

// Cache global en mémoire pour éviter les requêtes réseau multiples par page
let cachedBannerConfig: BannerConfigState | null = null;
let pendingBannerFetch: Promise<BannerConfigState> | null = null;

async function fetchBannerConfig(): Promise<BannerConfigState> {
  if (cachedBannerConfig) return cachedBannerConfig;
  if (pendingBannerFetch) return pendingBannerFetch;

  pendingBannerFetch = (async () => {
    try {
      const res = await fetch('/api/backend/settings');
      const data = await res.json();
      if (data.success && data.settings) {
        const cfg: BannerConfigState = {
          adsEnabled: !!data.settings.adsense?.isEnabled,
          activeClientId: data.settings.adsense?.clientId || process.env.NEXT_PUBLIC_ADSENSE_CLIENT_ID || '',
          partnerSpaceEnabled: !!data.settings.partnerSpace?.isEnabled,
          partnerBannerText: data.settings.partnerSpace?.customBannerText || '',
          partnerBannerLink: data.settings.partnerSpace?.customBannerLink || '',
          badgeLabel: data.settings.partnerSpace?.badgeLabel || 'Espace Partenaire',
        };
        cachedBannerConfig = cfg;
        return cfg;
      }
    } catch {}

    const fallback: BannerConfigState = {
      adsEnabled: !!process.env.NEXT_PUBLIC_ADSENSE_CLIENT_ID,
      activeClientId: process.env.NEXT_PUBLIC_ADSENSE_CLIENT_ID || '',
      partnerSpaceEnabled: false,
      partnerBannerText: '',
      partnerBannerLink: '',
      badgeLabel: 'Espace Partenaire',
    };
    cachedBannerConfig = fallback;
    return fallback;
  })();

  const result = await pendingBannerFetch;
  pendingBannerFetch = null;
  return result;
}

export default function AdBanner({
  slotId,
  format = 'horizontal',
  className = '',
  label,
}: AdBannerProps) {
  const [config, setConfig] = useState<BannerConfigState | null>(cachedBannerConfig);
  const [hasConsent, setHasConsent] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    fetchBannerConfig().then((cfg) => {
      if (isMounted) setConfig(cfg);
    });

    const checkConsent = () => {
      const consent =
        localStorage.getItem('turfjournal_cookie_consent') ||
        localStorage.getItem('TurfJournal_cookie_consent');
      if (consent === 'accepted') {
        setHasConsent(true);
        if (config?.activeClientId && typeof window !== 'undefined') {
          try {
            ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
          } catch {}
        }
      }
    };

    const timer = setTimeout(checkConsent, 0);
    window.addEventListener('consent_updated', checkConsent);
    return () => {
      isMounted = false;
      clearTimeout(timer);
      window.removeEventListener('consent_updated', checkConsent);
    };
  }, [config?.activeClientId]);

  // Si pas encore chargé ou si ni l'Espace Partenaire ni AdSense ne sont activés, NE RIEN AFFICHER
  if (!config) return null;

  // 1. Priorité Espace Partenaire personnalisé si activé depuis le backend
  if (config.partnerSpaceEnabled && config.partnerBannerText) {
    const displayLabel = label || config.badgeLabel || 'Espace Partenaire';
    return (
      <div className={`my-4 mx-auto w-full max-w-4xl px-4 ${className}`}>
        <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-emerald-900/90 to-slate-900 text-white border border-emerald-800/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2.5">
            <span className="px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[10px] uppercase tracking-wider">
              {displayLabel}
            </span>
            <span className="text-slate-200 font-medium">{config.partnerBannerText}</span>
          </div>

          {config.partnerBannerLink && (
            <Link
              href={config.partnerBannerLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold transition-all whitespace-nowrap self-end sm:self-auto"
            >
              <span>Accéder à l&apos;offre</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>
          )}
        </div>
      </div>
    );
  }

  // 2. Si AdSense n'est pas activé ou s'il n'y a pas de Client ID réel, RETOURNER NULL
  // AUCUN placeholder vide ni encart en pointillés ne s'affiche sur le site public
  if (!config.adsEnabled || !config.activeClientId || !hasConsent) {
    return null;
  }

  // 3. Affichage réel de la bannière Google AdSense
  return (
    <div className={`my-4 mx-auto w-full text-center overflow-hidden ${className}`}>
      <span className="block text-[10px] uppercase tracking-wider text-slate-400 mb-1">
        Publicité
      </span>
      <ins
        className="adsbygoogle block"
        style={{ display: 'block' }}
        data-ad-client={config.activeClientId}
        data-ad-slot={slotId || '1234567890'}
        data-ad-format={format}
        data-full-width-responsive="true"
      />
    </div>
  );
}
