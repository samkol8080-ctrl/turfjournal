'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ShieldCheck, Cookie } from 'lucide-react';

export default function CookieConsent() {
  const [showBanner, setShowBanner] = useState<boolean>(false);

  useEffect(() => {
    const savedConsent =
      localStorage.getItem('turfjournal_cookie_consent') ||
      localStorage.getItem('TurfJournal_cookie_consent');
    if (!savedConsent) {
      const timer = setTimeout(() => setShowBanner(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('turfjournal_cookie_consent', 'accepted');
    setShowBanner(false);
    window.dispatchEvent(new Event('consent_updated'));
  };

  const handleDecline = () => {
    localStorage.setItem('turfjournal_cookie_consent', 'declined');
    setShowBanner(false);
    window.dispatchEvent(new Event('consent_updated'));
  };

  if (!showBanner) return null;

  return (
    <div
      role="dialog"
      aria-live="polite"
      aria-label="Consentement relatif aux cookies"
      className="fixed bottom-0 inset-x-0 z-50 p-4 sm:p-6 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-2xl transition-all animate-in fade-in slide-in-from-bottom-4 duration-300"
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-start space-x-3 text-left">
          <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700 flex-shrink-0 mt-0.5 border border-emerald-100">
            <Cookie className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
              <span>Respect de votre vie privée et gestion des cookies</span>
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
            </h4>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed max-w-3xl">
              TurfJournal utilise des cookies techniques indispensables au bon fonctionnement du site, ainsi que des technologies d&apos;analyse d&apos;audience et de diffusion publicitaire conforme AdSense (Google). Vous pouvez accepter ou refuser ces dépôts à tout moment conformément au RGPD.
            </p>
            <div className="mt-1">
              <Link
                href="/politique-cookies"
                className="text-xs text-emerald-700 font-bold underline hover:text-emerald-800 transition-colors"
              >
                Consulter notre politique de cookies détaillée
              </Link>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3 w-full md:w-auto flex-shrink-0 justify-end">
          <button
            onClick={handleDecline}
            className="flex-1 md:flex-none px-4 py-2.5 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-colors"
          >
            Refuser
          </button>
          <button
            onClick={handleAccept}
            className="flex-1 md:flex-none px-5 py-2.5 rounded-xl text-xs font-black text-white bg-emerald-700 hover:bg-emerald-800 shadow-md shadow-emerald-700/20 transition-all hover:scale-[1.02]"
          >
            Tout Accepter
          </button>
        </div>
      </div>
    </div>
  );
}

