import React from 'react';
import Link from 'next/link';
import { ParticipantData } from '@/types/racing';

interface ParticipantTableProps {
  participants: ParticipantData[];
}

export default function ParticipantTable({ participants }: ParticipantTableProps) {
  const getShoeBadge = (shoes?: string) => {
    if (!shoes) return null;
    switch (shoes) {
      case 'D4':
        return (
          <span className="px-2 py-0.5 rounded-lg text-[11px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300" title="Déferré des 4 pieds (Vitesse maximale)">
            D4
          </span>
        );
      case 'DA':
        return (
          <span className="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-300" title="Déferré des antérieurs">
            DA
          </span>
        );
      case 'DP':
        return (
          <span className="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-purple-100 text-purple-800 border border-purple-300" title="Déferré des postérieurs">
            DP
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-lg text-[11px] font-medium text-slate-500 bg-slate-100 border border-slate-200" title="Ferré">
            Ferré
          </span>
        );
    }
  };

  return (
    <div className="card-modern overflow-hidden">
      {/* Table Header Bar */}
      <div className="p-4 sm:p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50">
        <div>
          <h3 className="text-lg font-black text-slate-900 flex items-center space-x-2">
            <span>Tableau des Partants Officiels</span>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-700 text-white text-xs font-black">
              {participants.length} chevaux
            </span>
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Cliquez sur un cheval ou un jockey pour consulter ses statistiques complètes et son palmarès.
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
            <span>D4 : Déferré 4</span>
          </span>
          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 border border-blue-200 font-bold">
            <span>DA/DP : Déferré 2</span>
          </span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100/70 text-slate-600 uppercase tracking-wider text-[11px] font-black border-b border-slate-200">
              <th className="py-3.5 px-3 text-center">N°</th>
              <th className="py-3.5 px-4">Cheval</th>
              <th className="py-3.5 px-2 text-center">Âge/Sexe</th>
              <th className="py-3.5 px-3">Jockey / Driver</th>
              <th className="py-3.5 px-3">Entraîneur</th>
              <th className="py-3.5 px-2 text-center">Corde</th>
              <th className="py-3.5 px-2 text-center">Poids</th>
              <th className="py-3.5 px-2 text-center">Ferrure</th>
              <th className="py-3.5 px-3">Musique récente</th>
              <th className="py-3.5 px-3 text-right">Cote Matin</th>
              <th className="py-3.5 px-4 text-right text-amber-700 font-black">En Direct</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200/80 bg-white">
            {participants.map((p) => {
              const horseSlug = p.horseId || `h-${p.horseNumber}`;
              const jockeySlug = p.jockeyName ? encodeURIComponent(p.jockeyName.toLowerCase().replace(/\s+/g, '-')) : 'jockey';
              const trainerSlug = p.trainerName ? encodeURIComponent(p.trainerName.toLowerCase().replace(/\s+/g, '-')) : 'entraineur';

              return (
                <tr
                  key={p.id}
                  className="hover:bg-slate-50 transition-colors group"
                >
                  {/* Number */}
                  <td className="py-3.5 px-3 text-center">
                    <span className="inline-flex items-center justify-center w-8 h-8 rounded-xl bg-slate-100 text-slate-900 border border-slate-200 font-black text-sm group-hover:bg-emerald-700 group-hover:text-white group-hover:border-emerald-700 transition-all shadow-xs">
                      {p.horseNumber}
                    </span>
                  </td>

                  {/* Horse */}
                  <td className="py-3.5 px-4">
                    <Link
                      href={`/chevaux/${horseSlug}`}
                      className="font-black text-slate-900 hover:text-emerald-700 transition-colors text-sm block"
                    >
                      {p.horseName}
                    </Link>
                    {(p.sire || p.dam) && (
                      <span className="text-[10px] text-slate-500 block truncate max-w-[170px]">
                        {p.sire} & {p.dam}
                      </span>
                    )}
                  </td>

                  {/* Age/Sex */}
                  <td className="py-3.5 px-2 text-center text-slate-600 font-medium">
                    {p.horseAge ? `${p.horseAge} ${p.horseSex || ''}` : '-'}
                  </td>

                  {/* Jockey */}
                  <td className="py-3.5 px-3">
                    {p.jockeyName ? (
                      <Link
                        href={`/jockeys/${jockeySlug}`}
                        className="text-slate-800 hover:text-emerald-700 transition-colors font-bold truncate block max-w-[130px]"
                      >
                        {p.jockeyName}
                      </Link>
                    ) : (
                      <span className="text-slate-400">-</span>
                    )}
                  </td>

                  {/* Trainer */}
                  <td className="py-3.5 px-3">
                    {p.trainerName ? (
                      <Link
                        href={`/entraineurs/${trainerSlug}`}
                        className="text-slate-600 hover:text-slate-900 transition-colors truncate block max-w-[120px]"
                      >
                        {p.trainerName}
                      </Link>
                    ) : (
                      <span className="text-slate-400">-</span>
                    )}
                  </td>

                  {/* Draw */}
                  <td className="py-3.5 px-2 text-center text-slate-800 font-bold font-mono">
                    {p.draw || '-'}
                  </td>

                  {/* Weight */}
                  <td className="py-3.5 px-2 text-center text-slate-700 font-mono">
                    {p.weight ? `${p.weight} kg` : '-'}
                  </td>

                  {/* Shoes */}
                  <td className="py-3.5 px-2 text-center">
                    {getShoeBadge(p.shoes)}
                  </td>

                  {/* Music */}
                  <td className="py-3.5 px-3">
                    <span className="font-mono text-[11px] text-slate-800 tracking-wider bg-slate-100 px-2 py-1 rounded-lg border border-slate-200 font-bold">
                      {p.music || 'Inédit'}
                    </span>
                  </td>

                  {/* Morning Odds */}
                  <td className="py-3.5 px-3 text-right font-medium text-slate-500 font-mono">
                    {p.oddsMorning ? p.oddsMorning.toFixed(1) : '-'}
                  </td>

                  {/* Current Odds in Amber */}
                  <td className="py-3.5 px-4 text-right font-black text-sm text-amber-700 font-mono">
                    {p.oddsCurrent ? p.oddsCurrent.toFixed(1) : p.oddsMorning ? p.oddsMorning.toFixed(1) : '-'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
