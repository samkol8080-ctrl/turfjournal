import React from 'react';
import Link from 'next/link';
import { Sparkles, Trophy, Clock, ArrowRight, ShieldCheck, Flame, Star } from 'lucide-react';
import { RaceData } from '@/types/racing';

interface QuinteSpecialProps {
  race: RaceData;
}

export default function QuinteSpecial({ race }: QuinteSpecialProps) {
  const topPicks = race.prediction?.topPicks || [];
  const topPick = topPicks[0];
  const secondPick = topPicks[1];
  const outsider = topPicks.find((p) => p.category === 'OUTSIDER') || topPicks[3];

  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '13:55';
    }
  };

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white shadow-xl p-6 sm:p-8">
      {/* Subtle ambient lighting */}
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-96 h-96 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 space-y-6">
        {/* Top Badges & Countdown */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2.5">
            <span className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider shadow-md">
              <Sparkles className="w-4 h-4" />
              <span>Quinté+ Événement du Jour</span>
            </span>
            <span className="px-3 py-1.5 rounded-full bg-white/15 text-white text-xs font-bold border border-white/20 backdrop-blur-md">
              {race.meetingCode} - Course {race.raceNumber}
            </span>
          </div>

          <div className="flex items-center space-x-2 text-xs font-black text-amber-300 bg-black/40 px-4 py-2 rounded-xl border border-white/10 backdrop-blur-md">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Départ à {formatTime(race.scheduledAt)}</span>
          </div>
        </div>

        {/* Title & Conditions */}
        <div>
          <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
            {race.name}
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100/90 mt-2 max-w-3xl leading-relaxed">
            <strong className="text-white">{race.hippodromeName}</strong> • {race.distance} m • {race.discipline.replace('_', ' ')} • Allocation : <strong className="text-amber-300">{race.purse?.toLocaleString('fr-FR')} €</strong>
          </p>
        </div>

        {/* Highlight Podium: 3 Main Choices in clean white cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Top 1 : Favori */}
          {topPick && (
            <div className="p-4 rounded-2xl bg-white text-slate-900 shadow-lg border-2 border-amber-400 relative overflow-hidden group">
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center space-x-1.5 text-xs font-black uppercase tracking-wider text-amber-700">
                  <Flame className="w-4 h-4 text-amber-600" />
                  <span>Le Favori Incontournable</span>
                </span>
                <span className="px-2 py-0.5 rounded-lg text-[10px] font-black bg-amber-100 text-amber-900 border border-amber-300">
                  {topPick.overallScore}/100
                </span>
              </div>
              <div className="flex items-center space-x-3.5 mt-1">
                <div className="w-12 h-12 rounded-xl bg-amber-400 text-slate-950 font-black text-xl flex items-center justify-center shadow-md">
                  {topPick.number}
                </div>
                <div>
                  <Link
                    href={`/chevaux/${encodeURIComponent(topPick.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                    className="text-base font-black text-slate-950 group-hover:text-emerald-700 hover:underline transition-colors block"
                  >
                    {topPick.horseName}
                  </Link>
                  <p className="text-xs text-slate-500 font-medium">
                    Driver :{' '}
                    <Link
                      href={`/jockeys/${encodeURIComponent(topPick.jockeyName.toLowerCase().replace(/\s+/g, '-'))}`}
                      className="hover:underline text-slate-700 font-semibold"
                    >
                      {topPick.jockeyName}
                    </Link>
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Top 2 : Base */}
          {secondPick && (
            <div className="p-4 rounded-2xl bg-white text-slate-900 shadow-lg border border-slate-200 group">
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center space-x-1.5 text-xs font-black uppercase tracking-wider text-emerald-700">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>La Base Solide</span>
                </span>
                <span className="px-2 py-0.5 rounded-lg text-[10px] font-black bg-emerald-50 text-emerald-800 border border-emerald-200">
                  {secondPick.overallScore}/100
                </span>
              </div>
              <div className="flex items-center space-x-3.5 mt-1">
                <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-800 font-black text-xl flex items-center justify-center border border-emerald-200">
                  {secondPick.number}
                </div>
                <div>
                  <Link
                    href={`/chevaux/${encodeURIComponent(secondPick.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                    className="text-base font-black text-slate-950 group-hover:text-emerald-700 hover:underline transition-colors block"
                  >
                    {secondPick.horseName}
                  </Link>
                  <p className="text-xs text-slate-500 font-medium">
                    Driver :{' '}
                    <Link
                      href={`/jockeys/${encodeURIComponent(secondPick.jockeyName.toLowerCase().replace(/\s+/g, '-'))}`}
                      className="hover:underline text-slate-700 font-semibold"
                    >
                      {secondPick.jockeyName}
                    </Link>
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Top 3 : Outsider */}
          {outsider && (
            <div className="p-4 rounded-2xl bg-white text-slate-900 shadow-lg border border-slate-200 group">
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center space-x-1.5 text-xs font-black uppercase tracking-wider text-teal-800">
                  <Trophy className="w-4 h-4 text-teal-600" />
                  <span>L&apos;Outsider Spéculatif</span>
                </span>
                <span className="px-2 py-0.5 rounded-lg text-[10px] font-black bg-teal-50 text-teal-900 border border-teal-200">
                  {outsider.overallScore}/100
                </span>
              </div>
              <div className="flex items-center space-x-3.5 mt-1">
                <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-800 font-black text-xl flex items-center justify-center border border-teal-200">
                  {outsider.number}
                </div>
                <div>
                  <Link
                    href={`/chevaux/${encodeURIComponent(outsider.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                    className="text-base font-black text-slate-950 group-hover:text-teal-700 hover:underline transition-colors block"
                  >
                    {outsider.horseName}
                  </Link>
                  <p className="text-xs text-slate-500 font-medium">
                    Driver :{' '}
                    <Link
                      href={`/jockeys/${encodeURIComponent(outsider.jockeyName.toLowerCase().replace(/\s+/g, '-'))}`}
                      className="hover:underline text-slate-700 font-semibold"
                    >
                      {outsider.jockeyName}
                    </Link>
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Visual Quick Selection: 8 Horses at a Glance */}
        <div className="p-4 rounded-2xl bg-black/25 border border-white/10 backdrop-blur-md space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-200 flex items-center space-x-1.5">
              <Star className="w-3.5 h-3.5 text-amber-300" />
              <span>La Sélection en 8 Chevaux de l&apos;Algorithme (Quinté / Multi / 2sur4)</span>
            </span>
            <span className="text-[11px] text-amber-300 font-bold">
              Indice de confiance : {'★'.repeat(Math.max(1, Math.min(5, Math.round(race.prediction?.confidenceScore || 4))))}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {topPicks.slice(0, 8).map((pick) => (
              <Link
                key={pick.number}
                href={`/chevaux/${encodeURIComponent(pick.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                className="flex items-center space-x-2 px-3 py-2 rounded-xl bg-white text-slate-950 shadow-sm border border-white/20 hover:scale-105 hover:border-emerald-400 transition-all cursor-pointer"
                title={`Consulter la fiche complète de ${pick.horseName}`}
              >
                <span className="w-7 h-7 rounded-lg bg-emerald-700 text-white font-black text-xs flex items-center justify-center">
                  {pick.number}
                </span>
                <span className="text-xs font-black text-slate-900 truncate max-w-[95px]">
                  {pick.horseName}
                </span>
              </Link>
            ))}
          </div>
        </div>

        {/* Big Action CTA */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
          <span className="text-xs text-emerald-100 font-medium">
            Analyse détaillée des performances, musique, base solide et tocard repéré.
          </span>

          <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
            <Link
              href="/pronostic-quinte-du-jour"
              className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-6 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-sm font-black shadow-lg shadow-amber-400/25 transition-all hover:scale-102"
            >
              <span>Pronostic Quinté du Jour</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/quinte-de-demain"
              className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-4 py-3 rounded-2xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold border border-white/20 transition-all"
            >
              <Clock className="w-3.5 h-3.5 text-amber-300" />
              <span>Quinté de Demain</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
