'use client';

import React, { useState } from 'react';
import { Calculator, Sparkles, Copy, Check, RotateCcw, Info, Trophy } from 'lucide-react';
import { ParticipantData } from '@/types/racing';

interface QuinteTicketGeneratorProps {
  participants?: ParticipantData[];
  defaultPicks?: number[];
  raceName?: string;
}

export default function QuinteTicketGenerator({
  participants = [],
  defaultPicks = [],
  raceName,
}: QuinteTicketGeneratorProps) {
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>(
    defaultPicks.length > 0 ? defaultPicks.slice(0, 5) : []
  );
  const [betType, setBetType] = useState<'QUINTE' | 'QUARTE' | 'TIERCE' | 'MULTI4' | 'MULTI5' | '2SUR4' | 'SIMPLE'>('QUINTE');
  const [copied, setCopied] = useState(false);

  // Toggle selection of a horse number
  const toggleNumber = (num: number) => {
    if (selectedNumbers.includes(num)) {
      setSelectedNumbers(selectedNumbers.filter((n) => n !== num));
    } else {
      if (selectedNumbers.length < 8) {
        setSelectedNumbers([...selectedNumbers, num]);
      }
    }
  };

  const handleReset = () => {
    setSelectedNumbers([]);
  };

  const handleCopy = () => {
    if (selectedNumbers.length === 0) return;
    const text = `Sélection ${betType} TurfJournal : ${selectedNumbers.join(' - ')}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Combinatorics calculator
  const factorial = (n: number): number => {
    if (n <= 1) return 1;
    let res = 1;
    for (let i = 2; i <= n; i++) res *= i;
    return res;
  };

  const combinations = (n: number, k: number): number => {
    if (k > n || k < 0) return 0;
    return Math.round(factorial(n) / (factorial(k) * factorial(n - k)));
  };

  // Cost and combinations calculation according to official PMU rules
  const getTicketSummary = () => {
    const count = selectedNumbers.length;
    let totalCombinations = 0;
    let basePrice = 2; // Prix unitaire de base en euros

    switch (betType) {
      case 'QUINTE':
        basePrice = 2;
        totalCombinations = count >= 5 ? combinations(count, 5) : 0;
        break;
      case 'QUARTE':
        basePrice = 1.5;
        totalCombinations = count >= 4 ? combinations(count, 4) : 0;
        break;
      case 'TIERCE':
        basePrice = 1;
        totalCombinations = count >= 3 ? combinations(count, 3) : 0;
        break;
      case 'MULTI4':
        basePrice = 3;
        totalCombinations = count >= 4 ? combinations(count, 4) : 0;
        break;
      case 'MULTI5':
        basePrice = 3;
        totalCombinations = count >= 5 ? combinations(count, 5) : 0;
        break;
      case '2SUR4':
        basePrice = 3;
        totalCombinations = count >= 2 ? combinations(count, 2) : 0;
        break;
      case 'SIMPLE':
        basePrice = 1.5;
        totalCombinations = count;
        break;
    }

    return {
      count,
      combinations: totalCombinations,
      basePrice,
      totalCost: totalCombinations * basePrice,
      isComplete:
        (betType === 'QUINTE' && count >= 5) ||
        (betType === 'QUARTE' && count >= 4) ||
        (betType === 'TIERCE' && count >= 3) ||
        (betType === 'MULTI4' && count >= 4) ||
        (betType === 'MULTI5' && count >= 5) ||
        (betType === '2SUR4' && count >= 2) ||
        (betType === 'SIMPLE' && count >= 1),
    };
  };

  const summary = getTicketSummary();

  // If no dynamic participants passed, generate numbers 1 to 16
  const availableHorses =
    participants.length > 0
      ? participants
      : Array.from({ length: 16 }, (_, i) => ({
          id: `p-${i + 1}`,
          horseNumber: i + 1,
          horseName: `Cheval N°${i + 1}`,
        }));

  return (
    <div className="card-modern p-5 sm:p-8 bg-white border border-slate-200/90 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 mb-2">
            <Calculator className="w-3.5 h-3.5" />
            <span>Simulateur &amp; Générateur de Ticket Turf</span>
          </div>
          <h3 className="text-lg sm:text-xl font-black text-slate-900">
            Composez votre Ticket {raceName ? `(${raceName})` : 'Quinté+'}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Sélectionnez vos numéros favoris, choisissez votre formule de pari et calculez instantanément le coût réel en euros.
          </p>
        </div>

        <button
          onClick={handleReset}
          className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer self-start sm:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Réinitialiser</span>
        </button>
      </div>

      {/* Bet Type Selector Pills */}
      <div>
        <label className="block text-xs font-bold text-slate-700 mb-2">
          1. Choisissez votre formule de pari :
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {[
            { id: 'QUINTE', label: 'Quinté+ (5 ch.)', base: '2€' },
            { id: 'QUARTE', label: 'Quarté+ (4 ch.)', base: '1,50€' },
            { id: 'TIERCE', label: 'Tiercé (3 ch.)', base: '1€' },
            { id: 'MULTI4', label: 'Multi en 4', base: '3€' },
            { id: 'MULTI5', label: 'Multi en 5', base: '3€' },
            { id: '2SUR4', label: '2 sur 4 (2 ch.)', base: '3€' },
            { id: 'SIMPLE', label: 'Simple Gagnant', base: '1,50€' },
          ].map((type) => (
            <button
              key={type.id}
              onClick={() => setBetType(type.id as any)}
              className={`p-2.5 rounded-xl text-center transition-all cursor-pointer border ${
                betType === type.id
                  ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              <span className="block font-black text-xs">{type.label}</span>
              <span className={`text-[10px] block mt-0.5 ${betType === type.id ? 'text-emerald-100' : 'text-slate-400'}`}>
                Mise base : {type.base}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Horse Selection Grid */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-bold text-slate-700">
            2. Cliquez sur vos chevaux ({selectedNumbers.length}/8 sélectionnés) :
          </label>
          <span className="text-[11px] text-slate-500">
            Minimum requis : {betType === 'QUINTE' ? 5 : betType === 'QUARTE' ? 4 : betType === 'TIERCE' ? 3 : betType === '2SUR4' ? 2 : 1} chevaux
          </span>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2.5">
          {availableHorses.map((h) => {
            const isSelected = selectedNumbers.includes(h.horseNumber);
            return (
              <button
                key={h.horseNumber}
                onClick={() => toggleNumber(h.horseNumber)}
                className={`p-3 rounded-2xl flex flex-col items-center justify-center transition-all cursor-pointer border ${
                  isSelected
                    ? 'bg-gradient-to-tr from-emerald-700 to-teal-600 text-white border-emerald-700 shadow-sm scale-102 ring-2 ring-emerald-500/30'
                    : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-200'
                }`}
              >
                <span className="text-base font-black font-mono">{h.horseNumber}</span>
                <span className="text-[10px] font-bold truncate max-w-[65px] mt-0.5">
                  {h.horseName}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Ticket Result Box */}
      <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 block">
              Votre Combinaison Sélectionnée
            </span>
            <div className="flex flex-wrap items-center gap-2 mt-1.5">
              {selectedNumbers.length === 0 ? (
                <span className="text-xs text-slate-400 italic">
                  Aucun numéro sélectionné. Cliquez sur les chevaux ci-dessus.
                </span>
              ) : (
                selectedNumbers.map((num, i) => (
                  <div
                    key={num}
                    className="flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-white border border-slate-300 shadow-2xs"
                  >
                    <span className="w-5 h-5 rounded-md bg-emerald-700 text-white font-black text-xs flex items-center justify-center font-mono">
                      {num}
                    </span>
                    <span className="text-xs font-bold text-slate-800">
                      {availableHorses.find((h) => h.horseNumber === num)?.horseName || `N°${num}`}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Action Copy */}
          {selectedNumbers.length > 0 && (
            <button
              onClick={handleCopy}
              className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold text-xs transition-all shadow-xs cursor-pointer self-start sm:self-auto"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-600" />}
              <span>{copied ? 'Combinaison copiée !' : 'Copier ma sélection'}</span>
            </button>
          )}
        </div>

        {/* Financial & Combinations Calculation Bar */}
        <div className="pt-4 border-t border-slate-200/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Formule</span>
            <strong className="text-sm font-black text-slate-900">{betType}</strong>
          </div>

          <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Combinaisons</span>
            <strong className="text-sm font-black text-slate-900 font-mono">
              {summary.combinations} pari(s)
            </strong>
          </div>

          <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Mise Unitaire</span>
            <strong className="text-sm font-black text-slate-900 font-mono">
              {summary.basePrice.toFixed(2)} €
            </strong>
          </div>

          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-emerald-800 block">Coût Total Ticket</span>
            <strong className="text-base font-black text-emerald-800 font-mono">
              {summary.totalCost.toFixed(2)} €
            </strong>
          </div>
        </div>

        {!summary.isComplete && selectedNumbers.length > 0 && (
          <div className="flex items-center space-x-2 text-xs text-amber-800 bg-amber-50 p-2.5 rounded-xl border border-amber-200">
            <Info className="w-4 h-4 flex-shrink-0 text-amber-600" />
            <span>
              Sélection incomplète : ajoutez encore des numéros pour valider la formule {betType}.
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
