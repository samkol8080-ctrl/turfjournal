import React from 'react';
import Link from 'next/link';
import { Clock, MapPin, Sparkles, ChevronRight, Award } from 'lucide-react';
import { RaceData } from '@/types/racing';

interface RaceCardProps {
  race: RaceData;
}

export default function RaceCard({ race }: RaceCardProps) {
  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '--:--';
    }
  };

  const getDisciplineLabel = (disc: string) => {
    switch (disc) {
      case 'TROT_ATTELE':
        return { label: 'Trot Attelé', color: 'bg-blue-50 text-blue-700 border-blue-200' };
      case 'TROT_MONTE':
        return { label: 'Trot Monté', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' };
      case 'PLAT':
        return { label: 'Plat Galop', color: 'bg-emerald-50 text-emerald-800 border-emerald-200' };
      case 'OBSTACLE_HAIES':
        return { label: 'Haies Obstacle', color: 'bg-amber-50 text-amber-800 border-amber-200' };
      case 'STEEPLE_CHASE':
        return { label: 'Steeple-Chase', color: 'bg-red-50 text-red-700 border-red-200' };
      default:
        return { label: 'Course', color: 'bg-slate-100 text-slate-700 border-slate-200' };
    }
  };

  const discInfo = getDisciplineLabel(race.discipline);

  return (
    <div className="card-modern p-5 flex flex-col justify-between group">
      <div>
        {/* Top Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <span className="px-3 py-1 rounded-xl bg-emerald-700 text-white text-xs font-black tracking-wider shadow-sm">
              {race.meetingCode} - C{race.raceNumber}
            </span>
            <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-lg border ${discInfo.color}`}>
              {discInfo.label}
            </span>
            {race.isQuinte && (
              <span className="flex items-center space-x-1 px-2.5 py-0.5 rounded-lg bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider shadow-sm">
                <Sparkles className="w-3 h-3" />
                <span>Quinté+</span>
              </span>
            )}
          </div>

          <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
            <Clock className="w-3.5 h-3.5 text-emerald-700" />
            <span>{formatTime(race.scheduledAt)}</span>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-base font-black text-slate-900 group-hover:text-emerald-700 transition-colors line-clamp-1 mb-2">
          {race.name}
        </h3>

        {/* Details snippet */}
        <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-500 mb-4">
          <span className="flex items-center space-x-1 text-slate-700 font-medium">
            <MapPin className="w-3 h-3 text-emerald-600" />
            <span>{race.hippodromeName}</span>
          </span>
          <span>•</span>
          <span className="font-mono text-slate-700">{race.distance} m</span>
          {race.purse && (
            <>
              <span>•</span>
              <span className="text-amber-700 font-black font-mono">{race.purse.toLocaleString('fr-FR')} €</span>
            </>
          )}
          <span>•</span>
          <span className="text-slate-600">{race.participants?.length || 0} partants</span>
        </div>

        {/* Top 3 Picks at a glance */}
        {race.prediction && race.prediction.topPicks.length > 0 && (
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 mb-4 text-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider flex items-center space-x-1">
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span>Top 3 Recommandé</span>
              </span>
              <span className="text-[10px] text-amber-700 font-bold">
                Confiance : {race.prediction.confidenceScore}/5 ★
              </span>
            </div>
            <div className="flex items-center space-x-2">
              {race.prediction.topPicks.slice(0, 3).map((pick) => (
                <Link
                  key={pick.number}
                  href={`/chevaux/${encodeURIComponent(pick.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                  className="flex items-center space-x-1.5 px-2 py-1 rounded-lg bg-white border border-slate-200 text-xs shadow-xs hover:border-emerald-500 hover:text-emerald-700 transition-colors"
                  title={`Fiche cheval ${pick.horseName}`}
                >
                  <span className="w-5 h-5 rounded-md bg-emerald-700 text-white font-black text-[10px] flex items-center justify-center">
                    {pick.number}
                  </span>
                  <span className="font-bold text-slate-900 hover:text-emerald-700 truncate max-w-[75px]">{pick.horseName}</span>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Arrival if verified */}
        {race.result && (
          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 mb-4 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-1.5 text-emerald-800 font-bold">
              <Award className="w-4 h-4 text-emerald-600" />
              <span>Arrivée officielle :</span>
              <strong className="text-slate-950 font-mono tracking-wider text-sm">{race.result.arrivalOrder}</strong>
            </div>
          </div>
        )}
      </div>

      {/* Action Button */}
      <Link
        href={`/pronostic/${race.slug}`}
        className="w-full flex items-center justify-center space-x-2 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-emerald-700 text-slate-800 hover:text-white text-xs font-black transition-all border border-slate-200/80 hover:border-emerald-700 group-hover:bg-emerald-700 group-hover:text-white shadow-xs"
      >
        <span>Partants & Pronostic</span>
        <ChevronRight className="w-3.5 h-3.5" />
      </Link>
    </div>
  );
}
