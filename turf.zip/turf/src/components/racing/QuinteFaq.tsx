'use client';

import React, { useState } from 'react';
import { HelpCircle, ChevronDown, Sparkles } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
}

interface QuinteFaqProps {
  items: FaqItem[];
  raceName?: string;
}

export default function QuinteFaq({ items, raceName }: QuinteFaqProps) {
  const [openIndexes, setOpenIndexes] = useState<number[]>([0, 1]); // Open first 2 by default

  const toggle = (idx: number) => {
    if (openIndexes.includes(idx)) {
      setOpenIndexes(openIndexes.filter((i) => i !== idx));
    } else {
      setOpenIndexes([...openIndexes, idx]);
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <section aria-labelledby="faq-quinte-heading" className="card-modern p-6 sm:p-8 space-y-6">
      <div className="flex items-center space-x-3 pb-4 border-b border-slate-200">
        <span className="p-2.5 rounded-xl bg-emerald-100 text-emerald-800">
          <HelpCircle className="w-5 h-5" />
        </span>
        <div>
          <h2 id="faq-quinte-heading" className="text-xl sm:text-2xl font-black text-slate-900">
            Questions Fréquentes sur le Quinté+ du Jour
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Tout ce qu&apos;il faut savoir pour parier intelligemment sur {raceName || 'la course événement'}.
          </p>
        </div>
      </div>

      <div className="space-y-3">
        {items.map((item, idx) => {
          const isOpen = openIndexes.includes(idx);
          return (
            <div
              key={idx}
              className="border border-slate-200/90 rounded-2xl overflow-hidden transition-colors bg-white hover:border-slate-300"
            >
              <button
                onClick={() => toggle(idx)}
                className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 font-bold text-slate-900 hover:text-emerald-800 transition-colors cursor-pointer"
                aria-expanded={isOpen}
              >
                <span className="text-sm sm:text-base font-black flex items-center space-x-2">
                  <span className="w-6 h-6 rounded-lg bg-emerald-50 text-emerald-800 text-xs font-black flex items-center justify-center shrink-0">
                    Q{idx + 1}
                  </span>
                  <span>{item.question}</span>
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-slate-400 shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180 text-emerald-700' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-4 pb-5 sm:px-5 sm:pb-5 pt-0 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 mt-1">
                  <p className="pt-3">{item.answer}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
