import React from 'react';
import Link from 'next/link';
import { Sparkles, ShieldAlert, AlertTriangle, Flame, ShieldCheck, Trophy, HelpCircle, Star } from 'lucide-react';
import { PredictionData } from '@/types/racing';

interface PredictionBoxProps {
  prediction?: PredictionData;
  raceName: string;
}

export default function PredictionBox({ prediction }: PredictionBoxProps) {
  if (!prediction || prediction.topPicks.length === 0) {
    return (
      <div className="card-modern p-8 text-center">
        <Sparkles className="w-8 h-8 text-slate-400 mx-auto mb-2" />
        <h4 className="text-sm font-bold text-slate-800">Analyse Statistique en Préparation</h4>
        <p className="text-xs text-slate-500 mt-1">
          Les coefficients algorithmiques sont calculés dès la confirmation des partants officiels.
        </p>
      </div>
    );
  }

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case 'FAVORI':
        return { label: 'Favori Incontournable', bg: 'bg-amber-100 text-amber-900 border border-amber-300', icon: Flame };
      case 'BASE':
        return { label: 'Base Solide', bg: 'bg-emerald-100 text-emerald-900 border border-emerald-300', icon: ShieldCheck };
      case 'OUTSIDER':
        return { label: 'Outsider Spéculatif', bg: 'bg-teal-100 text-teal-900 border border-teal-300', icon: Trophy };
      default:
        return { label: 'Tocard / Spéculatif', bg: 'bg-purple-100 text-purple-900 border border-purple-300', icon: HelpCircle };
    }
  };

  return (
    <div className="card-modern p-6 sm:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
              <Sparkles className="w-5 h-5" />
            </span>
            <h3 className="text-lg sm:text-xl font-black text-slate-900">
              Synthèse & Pronostic Statistique
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Classement mathématique basé sur la musique, la régularité, le déferrage et l&apos;historique.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs bg-slate-50 px-3.5 py-2 rounded-xl border border-slate-200">
          <span className="text-slate-500 font-medium">Indice de confiance :</span>
          {(() => {
            const score = Math.max(1, Math.min(5, Math.round(prediction.confidenceScore || 3)));
            return (
              <span className="text-amber-500 font-black tracking-wide">
                {'★'.repeat(score)}
                {'☆'.repeat(5 - score)} ({score}/5)
              </span>
            );
          })()}
        </div>
      </div>

      {/* Editorial Summary Box */}
      <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-700 leading-relaxed">
        <p>{prediction.summaryText}</p>
      </div>

      {/* Ranked Horses List */}
      <div className="space-y-4">
        <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center space-x-2">
          <Star className="w-4 h-4 text-amber-500" />
          <span>Sélection des Partants Retenus</span>
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {prediction.topPicks.map((pick) => {
            const catInfo = getCategoryBadge(pick.category);
            const CatIcon = catInfo.icon;

            return (
              <div
                key={pick.number}
                className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white font-black text-base flex items-center justify-center shadow-sm">
                        {pick.number}
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <Link
                            href={`/chevaux/${encodeURIComponent(pick.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                            className="text-sm font-black text-slate-900 hover:text-emerald-700 hover:underline transition-colors"
                          >
                            {pick.horseName}
                          </Link>
                          <span className="text-xs font-bold text-slate-500">#{pick.rank}</span>
                        </div>
                        <span className="text-xs text-slate-500">
                          Jockey :{' '}
                          <Link
                            href={`/jockeys/${encodeURIComponent(pick.jockeyName.toLowerCase().replace(/\s+/g, '-'))}`}
                            className="hover:underline text-slate-700 font-semibold"
                          >
                            {pick.jockeyName}
                          </Link>
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className={`inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-black ${catInfo.bg}`}>
                        <CatIcon className="w-3 h-3" />
                        <span>{catInfo.label}</span>
                      </span>
                      <span className="block font-mono font-black text-xs text-slate-900 mt-1">
                        {pick.overallScore}/100
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed mb-3">
                    {pick.comment}
                  </p>
                </div>

                {/* Factors preview */}
                <div className="grid grid-cols-4 gap-1.5 pt-3 border-t border-slate-100 text-[10px] text-center">
                  <div className="p-1.5 rounded-lg bg-slate-50">
                    <span className="text-slate-400 block">Forme</span>
                    <strong className="text-slate-800">{pick.factors.formScore}%</strong>
                  </div>
                  <div className="p-1.5 rounded-lg bg-slate-50">
                    <span className="text-slate-400 block">Entourage</span>
                    <strong className="text-slate-800">{pick.factors.jockeyScore}%</strong>
                  </div>
                  <div className="p-1.5 rounded-lg bg-slate-50">
                    <span className="text-slate-400 block">Distance</span>
                    <strong className="text-slate-800">{pick.factors.distanceAptitude}%</strong>
                  </div>
                  <div className="p-1.5 rounded-lg bg-slate-50">
                    <span className="text-slate-400 block">Régularité</span>
                    <strong className="text-slate-800">{pick.factors.regularityScore}%</strong>
                  </div>
                </div>

                {pick.missingDataWarning && (
                  <div className="mt-2.5 p-2 rounded-lg bg-amber-50 border border-amber-200 flex items-center space-x-2 text-[11px] text-amber-800">
                    <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 text-amber-600" />
                    <span>{pick.missingDataWarning}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Ethical Disclaimer */}
      <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-[11px] text-amber-900 flex items-start space-x-3">
        <ShieldAlert className="w-5 h-5 flex-shrink-0 text-amber-600 mt-0.5" />
        <div className="leading-relaxed">
          <strong>Avertissement Déontologique :</strong> Les analyses et calculs mathématiques sont délivrés à titre purement indicatif. Les courses hippiques comportent un aléa intrinsèque et aucune prédiction ne garantit de gain financier. Ne misez que des sommes modérées.
        </div>
      </div>
    </div>
  );
}
