import React from 'react';
import Link from 'next/link';
import { 
  Flame, 
  ShieldCheck, 
  HelpCircle, 
  Clock, 
  Sparkles, 
  Trophy, 
  CheckCircle2, 
  Compass, 
  TrendingUp, 
  Target,
  ArrowRight,
  Award
} from 'lucide-react';
import { RaceData } from '@/types/racing';
import { EditorialContent } from '@/lib/editorial-generator';

interface QuinteEditorialSectionProps {
  race: RaceData;
  editorial: EditorialContent;
}

export default function QuinteEditorialSection({ race, editorial }: QuinteEditorialSectionProps) {
  const isFinished = race.status === 'FINISHED' || Boolean(race.result?.arrivalOrder && race.result.arrivalOrder.length > 0);

  return (
    <section aria-labelledby="editorial-heading" className="space-y-8">
      {/* 1. Main Editorial Card (300 to 500 words) */}
      <div className="card-modern p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center space-x-2 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
              <Compass className="w-4 h-4" />
              <span>Analyse des Spécialistes TurfJournal</span>
            </div>
            <h2 id="editorial-heading" className="text-xl sm:text-2xl font-black text-slate-900">
              Analyse Détaillée du Quinté+ & Conditions de Course
            </h2>
          </div>

          <div className="flex items-center space-x-2 text-xs text-slate-500 font-semibold bg-slate-50 px-3.5 py-1.5 rounded-xl border border-slate-200 shrink-0">
            <Clock className="w-3.5 h-3.5 text-emerald-600" />
            <span>Mise à jour officielle continue</span>
          </div>
        </div>

        {/* Prose text optimized for Google bots & human bettors */}
        <div className="space-y-4 text-sm sm:text-base text-slate-700 leading-relaxed font-normal">
          <p>{editorial.raceIntro}</p>
          <p>{editorial.trackAnalysis}</p>
        </div>

        {/* 2. Structured Highlight Grid: Base Solide + Tocard du Jour + Dernière Minute */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 pt-2">
          {/* Base Solide */}
          {editorial.baseSolide && (
            <div className="p-5 rounded-2xl bg-emerald-50/70 border-2 border-emerald-300 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="flex items-center space-x-1.5 text-xs font-black uppercase tracking-wider text-emerald-900">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <span>Base Solide Quinté</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-emerald-200 text-emerald-900">
                    Incontournable
                  </span>
                </div>

                <div className="flex items-center space-x-3 my-2">
                  <div className="w-11 h-11 rounded-xl bg-emerald-700 text-white font-black text-lg flex items-center justify-center shadow-xs shrink-0">
                    {editorial.baseSolide.horseNumber}
                  </div>
                  <div>
                    <Link
                      href={`/chevaux/${encodeURIComponent(editorial.baseSolide.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                      className="text-base font-black text-slate-900 hover:text-emerald-700 hover:underline transition-colors block"
                    >
                      {editorial.baseSolide.horseName}
                    </Link>
                    <p className="text-xs text-slate-500">
                      Jockey / Driver :{' '}
                      <Link
                        href={`/jockeys/${encodeURIComponent(editorial.baseSolide.jockeyName.toLowerCase().replace(/\s+/g, '-'))}`}
                        className="hover:underline text-slate-700 font-semibold"
                      >
                        {editorial.baseSolide.jockeyName}
                      </Link>
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed pt-1">
                  {editorial.baseSolide.text}
                </p>
              </div>

              <div className="pt-2 border-t border-emerald-200/60 text-[11px] font-bold text-emerald-800 flex items-center justify-between">
                <span>Régularité maximale</span>
                <span>Priorité absolue</span>
              </div>
            </div>
          )}

          {/* Tocard du Jour */}
          {editorial.tocardDuJour && (
            <div className="p-5 rounded-2xl bg-amber-50/80 border-2 border-amber-300 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="flex items-center space-x-1.5 text-xs font-black uppercase tracking-wider text-amber-900">
                    <Flame className="w-4 h-4 text-amber-600" />
                    <span>Tocard du Jour Quinté</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-amber-200 text-amber-950">
                    Coup de Poker
                  </span>
                </div>

                <div className="flex items-center space-x-3 my-2">
                  <div className="w-11 h-11 rounded-xl bg-amber-500 text-slate-950 font-black text-lg flex items-center justify-center shadow-xs shrink-0">
                    {editorial.tocardDuJour.horseNumber}
                  </div>
                  <div>
                    <Link
                      href={`/chevaux/${encodeURIComponent(editorial.tocardDuJour.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                      className="text-base font-black text-slate-900 hover:text-amber-800 hover:underline transition-colors block"
                    >
                      {editorial.tocardDuJour.horseName}
                    </Link>
                    <p className="text-xs text-slate-500">
                      Jockey / Driver :{' '}
                      <Link
                        href={`/jockeys/${encodeURIComponent(editorial.tocardDuJour.jockeyName.toLowerCase().replace(/\s+/g, '-'))}`}
                        className="hover:underline text-slate-700 font-semibold"
                      >
                        {editorial.tocardDuJour.jockeyName}
                      </Link>
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed pt-1">
                  {editorial.tocardDuJour.text}
                </p>
              </div>

              <div className="pt-2 border-t border-amber-200/60 text-[11px] font-bold text-amber-900 flex items-center justify-between">
                <span>Spéculatif à grosse cote</span>
                <span>Pimente les rapports</span>
              </div>
            </div>
          )}

          {/* Dernière Minute */}
          {editorial.derniereMinute && (
            <div className="p-5 rounded-2xl bg-teal-50/80 border-2 border-teal-300 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="flex items-center space-x-1.5 text-xs font-black uppercase tracking-wider text-teal-900">
                    <Sparkles className="w-4 h-4 text-teal-600" />
                    <span>Dernière Minute Quinté</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-teal-200 text-teal-950">
                    09h15
                  </span>
                </div>

                <div className="flex items-center space-x-3 my-2">
                  <div className="w-11 h-11 rounded-xl bg-teal-700 text-white font-black text-lg flex items-center justify-center shadow-xs shrink-0">
                    {editorial.derniereMinute.horseNumber}
                  </div>
                  <div>
                    <Link
                      href={`/chevaux/${encodeURIComponent(editorial.derniereMinute.horseName.toLowerCase().replace(/\s+/g, '-'))}`}
                      className="text-base font-black text-slate-900 hover:text-teal-800 hover:underline transition-colors block"
                    >
                      {editorial.derniereMinute.horseName}
                    </Link>
                    <p className="text-xs text-slate-500">
                      Jockey / Driver :{' '}
                      <Link
                        href={`/jockeys/${encodeURIComponent(editorial.derniereMinute.jockeyName.toLowerCase().replace(/\s+/g, '-'))}`}
                        className="hover:underline text-slate-700 font-semibold"
                      >
                        {editorial.derniereMinute.jockeyName}
                      </Link>
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed pt-1">
                  {editorial.derniereMinute.text}
                </p>
              </div>

              <div className="pt-2 border-t border-teal-200/60 text-[11px] font-bold text-teal-900 flex items-center justify-between">
                <span>Bruits d&apos;écurie</span>
                <span>Signal fraîcheur</span>
              </div>
            </div>
          )}
        </div>

        {/* 3. Combinations & Ticket Recommendations */}
        <div className="pt-4 border-t border-slate-200 space-y-4">
          <div className="flex items-center space-x-2">
            <Target className="w-5 h-5 text-emerald-700" />
            <h3 className="text-lg font-black text-slate-900">
              Conseils de Jeux & Combinaisons Recommandées
            </h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            {editorial.tacticalAdvice}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            {/* Ticket 5 Chevaux */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-center">
              <span className="text-[11px] font-black text-slate-500 uppercase tracking-wider block">
                Ticket Unitaire Quinté (5 ch.)
              </span>
              <span className="text-lg font-mono font-black text-slate-900 mt-1 block">
                {editorial.gameRecommendations.singleTicket.join(' - ')}
              </span>
            </div>

            {/* Tiercé Recommandé */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-center">
              <span className="text-[11px] font-black text-emerald-800 uppercase tracking-wider block">
                Tiercé Ordre / Désordre
              </span>
              <span className="text-lg font-mono font-black text-emerald-700 mt-1 block">
                {editorial.gameRecommendations.tierce.join(' - ')}
              </span>
            </div>

            {/* Quarté Recommandé */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-center">
              <span className="text-[11px] font-black text-teal-800 uppercase tracking-wider block">
                Quarté+
              </span>
              <span className="text-lg font-mono font-black text-teal-700 mt-1 block">
                {editorial.gameRecommendations.quarte.join(' - ')}
              </span>
            </div>

            {/* Formule Champ Réduit */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-center">
              <span className="text-[11px] font-black text-amber-800 uppercase tracking-wider block">
                Champ Réduit (2 Bases + 5)
              </span>
              <span className="text-sm font-mono font-black text-slate-900 mt-1 block">
                [{editorial.gameRecommendations.champReduit.bases.join(' - ')}] X / {editorial.gameRecommendations.champReduit.associates.join(' - ')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Arrivée et Rapports Quinté du Jour (Post-Race Traffic Target) */}
      {isFinished && race.result && (
        <div id="arrivee-rapports" className="card-modern p-6 sm:p-8 space-y-6 border-2 border-emerald-500">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200">
            <div className="flex items-center space-x-3">
              <span className="p-2.5 rounded-xl bg-emerald-100 text-emerald-800">
                <Award className="w-6 h-6" />
              </span>
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                  Arrivée et Rapports Officiels du Quinté+
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Résultats homologués par le PMU pour le {race.name}.
                </p>
              </div>
            </div>

            <span className="px-3 py-1 rounded-xl bg-emerald-700 text-white font-black text-xs">
              Officiel
            </span>
          </div>

          <div className="space-y-4">
            <div>
              <span className="text-xs font-black text-slate-500 uppercase tracking-wider block mb-2">
                Combinaison Gagnante Quinté+ (Ordre d&apos;arrivée) :
              </span>
              <div className="flex flex-wrap items-center gap-2">
                {(typeof race.result.arrivalOrder === 'string'
                  ? race.result.arrivalOrder.split(/[\s-]+/).filter(Boolean)
                  : Array.isArray(race.result.arrivalOrder)
                  ? race.result.arrivalOrder
                  : []
                ).map((num: string | number, idx: number) => (
                  <div key={idx} className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-emerald-700 text-white shadow-xs">
                    <span className="text-[10px] font-bold opacity-75">#{idx + 1}</span>
                    <span className="text-lg font-black font-mono">{num}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Dividends */}
            {(race.result.reportQuinte || race.result.reportSimpleGagnant) && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                {race.result.reportSimpleGagnant && (
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[11px] text-slate-500 font-bold block">Simple Gagnant</span>
                    <span className="text-lg font-mono font-black text-slate-900">{race.result.reportSimpleGagnant} €</span>
                  </div>
                )}
                {race.result.reportSimplePlace && (
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[11px] text-slate-500 font-bold block">Simple Placé</span>
                    <span className="text-lg font-mono font-black text-slate-900">{race.result.reportSimplePlace} €</span>
                  </div>
                )}
                {race.result.reportQuinte && (
                  <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
                    <span className="text-[11px] text-emerald-800 font-bold block">Rapport Quinté+</span>
                    <span className="text-lg font-mono font-black text-emerald-700">{race.result.reportQuinte}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
