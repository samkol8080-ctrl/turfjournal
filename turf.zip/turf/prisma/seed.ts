import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('--- Initialisation du Seeding TurfJournal PostgreSQL ---');

  // 1. Categories
  await prisma.category.upsert({
    where: { slug: 'guides' },
    update: {},
    create: {
      name: 'Guides & Stratégies',
      slug: 'guides',
      description: 'Tutoriels méthodologiques et apprentissage pour les parieurs.',
    },
  });

  await prisma.category.upsert({
    where: { slug: 'actualites' },
    update: {},
    create: {
      name: 'Actualités Hippiques',
      slug: 'actualites',
      description: 'Toute l\'actualité des hippodromes et grands prix.',
    },
  });
  console.log('✓ Catégories créées');

  // 2. Hippodromes
  await prisma.hippodrome.upsert({
    where: { code: 'VINC' },
    update: {},
    create: {
      code: 'VINC',
      name: 'Hippodrome de Paris-Vincennes',
      city: 'Paris',
      country: 'France',
      surface: 'Cendrée',
      trackType: 'Grande Piste - Corde à gauche',
    },
  });

  await prisma.hippodrome.upsert({
    where: { code: 'CAGN' },
    update: {},
    create: {
      code: 'CAGN',
      name: 'Hippodrome de la Côte d\'Azur',
      city: 'Cagnes-sur-Mer',
      country: 'France',
      surface: 'Herbe & PSF',
      trackType: 'Corde à gauche',
    },
  });
  console.log('✓ Hippodromes créés');

  // 3. Ad Placements
  const placements = [
    { code: 'HOME_LEADERBOARD', name: 'Bannière Haute Accueil', format: 'horizontal', position: 'Header' },
    { code: 'RACE_INLINE_FEED', name: 'Pavé Course Détail', format: 'rectangle', position: 'In-Feed' },
    { code: 'ARTICLE_SIDEBAR', name: 'Rectangle Latéral Articles', format: 'rectangle', position: 'Sidebar' },
    { code: 'FOOTER_BANNER', name: 'Bannière Bas de Page', format: 'horizontal', position: 'Footer' },
  ];

  for (const p of placements) {
    await prisma.adPlacement.upsert({
      where: { code: p.code },
      update: {},
      create: {
        code: p.code,
        name: p.name,
        format: p.format,
        position: p.position,
        isEnabled: true,
      },
    });
  }
  console.log('✓ Emplacements AdSense créés');

  console.log('--- Seeding terminé avec succès ---');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
